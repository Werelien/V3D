/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#ifndef _SYS_H_GS_2011_
#define _SYS_H_GS_2011_
#ifdef __cplusplus
extern "C" {
#endif

typedef char SysC8;
typedef unsigned char SysU8;
typedef signed char SysS8;
typedef unsigned short SysU16;
typedef signed short SysS16;
typedef unsigned int SysU32;
typedef signed int SysS32;
typedef unsigned long long SysU64;
typedef signed long long SysS64;
typedef float SysF32;
typedef double SysF64;

enum {
  SYS_LOG_MAX_ID_2 = 8,
  SYS_LOG_MAX_ID = (1 << SYS_LOG_MAX_ID_2),
  SYS_LOG_ID_MASK = SYS_LOG_MAX_ID - 1,

  SYS_LOG_CONSOLE = -1,
  SYS_LOG_ODS = 0,
  SYS_LOG_MEM,
  SYS_LOG_AUDIO,
  SYS_LOG_USER_0,
  SYS_MAX_LOGS = SYS_LOG_MAX_ID
};

enum {
  SYSMEM_DEFAULT = (32 * 1024 * 1024),
  SYSAUDIO_DEFAULT_STEREO = (1 << 24),
  SYSAUDIO_DEFAULT_FMT = 16,
  SYSAUDIO_DEFAULT_FREQ = 44100,
  SYSSTATE_AUDIOON = 1,
  SYSSTATE_AUDIOOFF = -1,
  SYSSTATE_UDPON = 2,
  SYSSTATE_UDPOFF = -2,
  SYSTATE_TITLE = 3,
  SYSFRAME_QUIT = (1 << 0),
  SYSFRAME_PAUSE = (1 << 0),
  SYSFRAME_RESUME = (1 << 1),
  SYSFRAME_GL_CREATE = (1 << 2),
  SYSFRAME_GL_CHANGE = (1 << 3),
  SYSLOADSAVE_DEFAULTDIR = 0,
  SYSLOADSAVE_USERDIR = (1 << 1),
  SYS_MOUSEPAD_HIDE = (1 << 0),
  SYS_LAST
};

enum {

  SYS_RSHIFT = 128,
  SYS_LSHIFT,
  SYS_RCTRL,
  SYS_LCTRL,
  SYS_RALT,
  SYS_LALT,
  SYS_RMETA,
  SYS_LMETA,
  SYS_LSUPER,
  SYS_RSUPER,
  SYS_MODE,
  SYS_COMPOSE,
  SYS_INSERT,
  SYS_HOME,
  SYS_END,
  SYS_PAGEUP,
  SYS_PAGEDOWN,
  SYS_CLEAR,
  SYS_PAUSE,
  SYS_DELETE,
  SYS_UP,
  SYS_DOWN,
  SYS_RIGHT,
  SYS_LEFT,
  SYS_CAPSLOCK,
  SYS_BACKSPACE,
  SYS_TAB,
  SYS_ENTER,
  SYS_ESCAPE,
  SYS_F1,
  SYS_F2,
  SYS_F3,
  SYS_F4,
  SYS_F5,
  SYS_F6,
  SYS_F7,
  SYS_F8,
  SYS_F9,
  SYS_F10,
  SYS_F11,
  SYS_F12,

  SYS_KEYS_MAX = 256,
  SYS_KEYS_END

};

SysS32 SysKeyPressed(SysS32 KeyNgvAllowsRepeats);
extern const SysU8 *SysKey;
extern const SysU8 *SysKeyPreviousFrame;
extern SysS32 SysKeyBufferLen;
extern const SysU8 *SysKeyBuffer;
typedef struct {
  SysF64 X, Y, DX, DY, WX, WY;
  SysU64 State;
} SYSMOUSE;
extern const SYSMOUSE *SysMouse;

SysU32 SysState(SysS32 Cmd, void *Arg);
SysU32 SysUDPIP(SysC8 *IPDNSString);
SysU32 SysUDPBroadcastIP(void);
SysU32 SysUDPBind(SysU32 IPAddress, SysU16 Port);
SysU32 SysUDPSend(SysU32 IPAddress, SysU16 Port, void *Packet,
                  SysU32 PacketByteSize);
SysU32 SysUDPRecieve(SysU32 *IPAddress, SysU16 *Port, void *Packet,
                     SysU32 PacketByteSize, SysU32 *BytesRecieved);
SysF64 SysSec(void);
SysU64 SysRNG(void);
SysU64 SysPRNG(SysU64 Seed01, SysU64 Seed23, SysU64 Index01, SysS32 Rounds);
SysS32 SysLoad(SysU32 Flags, const SysC8 *FileName, SysU32 Offset, SysU32 Size,
               void *Buffer);
SysS32 SysSave(SysU32 Flags, const SysC8 *FileName, SysU32 Size, void *Buffer);
SysF32 SysAspectRatio(SysU32 *Width, SysU32 *Height);
SysS32 SysUserFrame(SysS32 Flags);
SysS32 SysUserAudio(SysU32 Flags, SysU32 AudioFreq, SysU8 *Stream, SysS32 Len);
SysS32 SysMusicOn(SysC8 *FileName, SysF32 FadeInS, SysS32 Loops);
SysS32 SysMusicPause(void);
SysS32 SysMusicVolume(SysF32 Volume);
SysS32 SysMusicResume(void);
SysS32 SysMusicOff(SysF32 FadeOut);
SysS32 SysMousePad(SysU64 Flags);

void SysKill(SysS32 n);
void SysWindowTitle(SysC8 *s);
void *SysDbgAlloc(SysU32 Bytes, const SysC8 *File, SysU32 Line);
void SysDbgFree(void *Mem, const SysC8 *File, SysU32 Line);

void SysLog(SysU64 LogID, const SysC8 *LogString, ...);

#define malloc SYS_MALLOC_NOT_ALLOWED
#define free SYS_FREE_NOT_ALLOWED

#ifdef SYS_DEBUG_ODS

#define SysNew(T, S) (T *)SysDbgAlloc(sizeof(T) * (S), __FILE__, __LINE__)
#define SysDelete(M) SysDbgFree(M, __FILE__, __LINE__)
#include <assert.h>
#define SysAssert(exp) assert(exp)
#define SysODS(...) SysLog(SYS_LOG_ODS, __VA_ARGS__);

#else

#define SysNew(T, S) (T *)SysDbgAlloc(sizeof(T) * (S), 0, 0)
#define SysDelete(M) SysDbgFree(M, 0, 0)
#define SysAssert(exp)

#define SysODS(...)
#endif

#ifdef __cplusplus
}
#endif
#endif
