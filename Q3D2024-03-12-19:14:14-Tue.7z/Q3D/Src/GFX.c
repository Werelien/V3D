/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "GFX.h"
#include "SYS.h"
#include <GLES3/gl3.h>

static GFX_MALLOC GFXAlloc = 0;
static GFX_FREE GFXDeAlloc = 0;
static GFX_FILELOAD GFXFileLoader = 0;
static GFX_FILESIZE GFXFileSizer = 0;

#ifdef GFX_DEBUG_ODS
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#define GFXAssert(exp) assert(exp)
#define GFXNew(T, S) (T *)GFXAlloc(sizeof(T) * (S), __FILE__, __LINE__)
#define GFXDelete(M) GFXDeAlloc((M), __FILE__, __LINE__)
#define GFXFileLoad(F, B, S) GFXFileLoader((F), (B), (S), __FILE__, __LINE__)
#define GFXFileSize(F) GFXFileSizer((F), __FILE__, __LINE__)
static FILE *odsf = 0;
void GFXODS(const char *DebugString, ...) {
  if (!odsf) {
    odsf = fopen("./Logs/GFXODS.Log", "w");
    GFXAssert(odsf);
  }
  va_list args;
  va_start(args, DebugString);
  vfprintf(odsf, DebugString, args);
  va_end(args);
  fflush(odsf);
}
#else
void GFXODS(const GFXC8 *v, ...){};
#define GFXAssert(exp)
#define GFXNew(T, S) (T *)GFXAlloc(sizeof(T) * (S), 0, 0)
#define GFXDelete(M) GFXDeAlloc((M), 0, 0)
#define GFXFileLoad(F, B, S) GFXFileLoader((F), (B), (S), 0, 0)
#define GFXFileSize(F) GFXFileSizer((F), 0, 0)
#endif

GFXU32 GFXErrorCheck(const char *Description) {
  GLenum error = glGetError();
  if (error == GL_NO_ERROR)
    return 0;

  GFXODS("%s", Description);

  const char *m;
  switch (error) {
  case GL_INVALID_ENUM:
    m = "Invalid Enum";
    break;
  case GL_INVALID_VALUE:
    m = "Invalid Value";
    break;
  case GL_INVALID_OPERATION:
    m = "Invalid Operation";
    break;
  case GL_INVALID_FRAMEBUFFER_OPERATION:
    m = "Invalid Framebuffer Operation";
    break;
  case GL_OUT_OF_MEMORY:
    m = "Out Of Memory";
    break;
  default:
    m = "Unknown OpenGL Error";
    break;
  }

  GFXODS(": %s\n", m);
  return 1;
}

GFXU32 GFXError(const char *Description) {
#ifdef SYS_DEBUG_ODS
  GFXU32 r = GFXErrorCheck(Description);
  GFXAssert(!r);
  return r;
#else
  return 0;
#endif
}

GFXF32 GFXLineWidthRange(GFXF32 *r) {
  glGetFloatv(GL_ALIASED_LINE_WIDTH_RANGE, r);
  return r[0];
}

GFXS32 GFXScreenShot(void *m, GFXU32 w, GFXU32 h) {
  glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, m);
  return w * h * 2;
}

enum {
  MaxVAVS = 16,
  MaxVTMS = 16,
  MaxVUAS = 32,
  MaxVTUS = 16,
  MaxFTUS = 16,
  MaxFUAS = 4
};
static GFXU32 ShadersActive = 0;
static struct VFUS {
  GFXS32 VAV[MaxVAVS], VTM[MaxVTMS], VUA[MaxVUAS], VTU[MaxVTUS], FTU[MaxFTUS],
      FUA[MaxFUAS];
} SU[GFX_MAXSHADERS];
static GFXU32 VShader[GFX_MAXSHADERS], FShader[GFX_MAXSHADERS],
    VFShader[GFX_MAXSHADERS];

static void ShaderLog(GFXU32 Shader) {
  GLint Status;
  glGetShaderiv(Shader, GL_COMPILE_STATUS, &Status);
  GLint Len;
  glGetShaderiv(Shader, GL_INFO_LOG_LENGTH, &Len);
  if (!Len)
    return;
  GFXC8 *InfoLog = GFXNew(GFXC8, (Len));
  glGetShaderInfoLog(Shader, Len, 0, InfoLog);
  GFXODS("ShaderLog(%x):%s\n", Shader, InfoLog);

  GFXDelete(InfoLog);
}

static void ProgramLog(GFXU32 Program) {
  GLint Status;
  glGetProgramiv(Program, GL_LINK_STATUS, &Status);
  GLint Len;
  glGetProgramiv(Program, GL_INFO_LOG_LENGTH, &Len);
  if (!Len)
    return;
  GFXC8 *InfoLog = GFXNew(GFXC8, (Len));
  glGetProgramInfoLog(Program, Len, 0, InfoLog);
  GFXODS("ProgramLog(%x):%s\n", Program, InfoLog);

  GFXDelete(InfoLog);
}

GFXU32 GFXWidth = 0, GFXHeight = 0;
static GFXS32 GFXVPX, GFXVPY, GFXVPW, GFXVPH;
void GFXViewPort(GFXS32 x, GFXS32 y, GFXS32 w, GFXS32 h) {
  GFXVPX = x;
  GFXVPY = y;
  GFXVPW = w;
  GFXVPH = h;
  glViewport(x, y, w, h);
}

void GFXClip(GFXS32 X, GFXS32 Y, GFXS32 Width, GFXS32 Height) {
  if (!(X | Y | Width | Height))
    glDisable(GL_SCISSOR_TEST);
  else {
    glEnable(GL_SCISSOR_TEST);
    glScissor(X, Y, Width, Height);
  }
}

GFXF32 GFXAspectRatio(GFXU32 *W, GFXU32 *H, GFXU32 ViewPort0Screen1) {
  if (ViewPort0Screen1) {
    GFXAssert(GFXWidth && GFXHeight);
    if (W)
      *W = GFXWidth;
    if (H)
      *H = GFXHeight;
    return ((GFXF32)(GFXWidth)) / ((GFXF32)(GFXHeight));
  } else {
    GFXAssert(GFXVPW && GFXVPH);
    if (W)
      *W = GFXVPW;
    if (H)
      *H = GFXVPH;
    return ((GFXF32)(GFXVPW)) / ((GFXF32)(GFXVPH));
  }
}

GFXU32 GFXCurrentShader;
GFXTEXH GFXDefaultTex;

void GFXTex(GFXU32 Stage, GFXTEXH TexHandle, GFXU64 Flags) {
  GFXU32 s = Stage & (GFXVTEXSTAGE - 1);
  glActiveTexture(GL_TEXTURE0 + Stage);
  if (TexHandle.ID == GFXTEX_NULL)
    glBindTexture(GL_TEXTURE_2D, (GLuint)GFXDefaultTex.ID);
  else
    glBindTexture(GL_TEXTURE_2D, (GLuint)TexHandle.ID);
  if (Flags & GFXTEX_FLAG_MIPMAP) {
    glGenerateMipmap(GL_TEXTURE_2D);
  }
  if (Stage & GFXVTEXSTAGE)
    glUniform1i(SU[GFXCurrentShader].VTU[s], Stage);
  else
    glUniform1i(SU[GFXCurrentShader].FTU[s], Stage);
  // glActiveTexture(GL_TEXTURE0 + 31);

  GFXError("GFXTex");
}

void GFXTexDestroy(GFXTEXH TexHandle) {
  if (TexHandle.ID != GFXTEX_NULL)
    glDeleteTextures(1, (const GLuint *)&TexHandle.ID);
}

static GFXS32 PowOf2(GFXS32 v) {
  GFXS32 n = 0;
  while ((1 << n) < v)
    n++;
  return n;
}

static GFXS32 IsPowerOf2(GFXS32 v) { return ((v & (v - 1)) == 0); }

static GFXU32 InternalTex[] = {GL_RGBA8,   GL_RGBA4,    GL_RGB5_A1,  GL_RGBA16F,
                               GL_RGBA32F, GL_RGBA16UI, GL_RGBA32UI, GL_R8};
static GFXU32 FmtTex[] = {GL_RGBA, GL_RGBA,         GL_RGBA,         GL_RGBA,
                          GL_RGBA, GL_RGBA_INTEGER, GL_RGBA_INTEGER, GL_RED};
static GFXU32 TypeTex[] = {GL_UNSIGNED_BYTE,
                           GL_UNSIGNED_SHORT_4_4_4_4,
                           GL_UNSIGNED_SHORT_5_5_5_1,
                           GL_HALF_FLOAT,
                           GL_FLOAT,
                           GL_UNSIGNED_SHORT,
                           GL_UNSIGNED_INT,
                           GL_UNSIGNED_BYTE};
GFXTEXH GFXTexCreate(GFXU32 Type, GFXU32 Width, GFXU32 Height, void *Data,
                     GFXU32 DataPitch, GFXU64 Flags) {

  GFXODS("GFX Tex Create: Type:%x W:%d H:%d Pitch:%d Flags:%x\n", Type, Width,
         Height, DataPitch, Flags);
  GLuint t;
  glGenTextures(1, &t);
  glBindTexture(GL_TEXTURE_2D, t);
  // GFXAssert(IsPowerOf2(Width));
  // GFXAssert(IsPowerOf2(Height));
  int nw = PowOf2(Width), nh = PowOf2(Height),
      nwh = (Flags & GFXTEX_FLAG_MIPMAP) ? ((nw < nh) ? nw : nh) + 1 : 1;

  glTexStorage2D(GL_TEXTURE_2D, nwh, InternalTex[Type], Width, Height);

  if (Flags & GFXTEX_FLAG_CLAMP) {
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    GFXODS("Tex:%dx%d %x Clamp\n", Width, Height, Flags);
  } else {
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    GFXODS("Tex:%dx%d %x Repeat\n", Width, Height, Flags);
  }

  if (Flags & GFXTEX_FLAG_LINEAR) {
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                    GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    GFXODS("Tex:%dx%d %x Linear\n", Width, Height, Flags);
  } else {
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                    GL_NEAREST_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    GFXODS("Tex:%dx%d %x Nearest\n", Width, Height, Flags);
  }
  GFXError("GFXTexCreate)");
  GFXTEXH h = {t, Flags, 0, 0};
  GFXTexUpdate(h, Type, 0, 0, Width, Height, Data, DataPitch, Flags);
  return h;
}

void GFXTexUpdate(GFXTEXH Texture, GFXU32 Type, GFXU32 OX, GFXU32 OY,
                  GFXU32 Width, GFXU32 Height, void *Data, GFXU32 DataPitch,
                  GFXU64 Flags) {
  if (!Data) {
    GFXODS("Warning: GFX Tex Update 0 Data: Type:%x Ox:%d OY:%d W:%d H:%d "
           "Pitch:%d Flags:%x\n",
           Type, OX, OY, Width, Height, DataPitch, Flags);
    return;
  }
  GLuint t = (GLuint)Texture.ID;
  glBindTexture(GL_TEXTURE_2D, t);

  glPixelStorei(GL_UNPACK_ROW_LENGTH, DataPitch);
  glTexSubImage2D(GL_TEXTURE_2D, 0, OX, OY, Width, Height, FmtTex[Type],
                  TypeTex[Type], Data);
  if (Flags & GFXTEX_FLAG_MIPMAP)
    glGenerateMipmap(GL_TEXTURE_2D);
  GFXError("GFXTexUpdate");
}

void GFXFrameBufferCreate(GFXU32 FBType, GFXTEXH *FBTex, GFXU32 Width,
                          GFXU32 Height, GFXU64 Flags) {
  GFXTEXH t = GFXTexCreate(FBType, Width, Height, 0, 0, Flags);

  GLint cf = 0;
  glGetIntegerv(GL_FRAMEBUFFER_BINDING, &cf);

  glGenFramebuffers(1, &t.FBFrameBuffer);
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, t.FBFrameBuffer);

  if (Flags & GFXTEX_FLAG_DEPTH) {
    glGenRenderbuffers(1, &t.FBDepthBuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, t.FBDepthBuffer);
    GFXError("GFXRenderBuffer");
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, Width, Height);
    GFXError("GFXFrameBufferStorage");
    glFramebufferRenderbuffer(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                              GL_RENDERBUFFER, t.FBDepthBuffer);
    GFXError("GFXFrameBufferRenderBuffer");
  }

  glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                         GL_TEXTURE_2D, t.ID, 0);
  GLenum DrawBuffers[1] = {GL_COLOR_ATTACHMENT0};
  glDrawBuffers(1, DrawBuffers);
  GFXError("GFXFrameBufferCreatetex2D");

  if (glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER) !=
      GL_FRAMEBUFFER_COMPLETE) {
    GFXError("GFXFrameBufferIncomplete");
  }

  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, cf);
  GFXError("GFXFrameBufferCreate");
  *FBTex = t;
}

void GFXFrameBufferDestroy(GFXTEXH *FBTex) {
  glDeleteTextures(1, &FBTex->ID);
  if (FBTex->Flags & GFXTEX_FLAG_DEPTH)
    glDeleteRenderbuffers(1, &FBTex->FBDepthBuffer);
  glDeleteFramebuffers(1, &FBTex->FBFrameBuffer);
  GFXError("GFXFrameBufferDestroy");
}

void GFXFrameBufferTarget(GFXTEXH *FBTex) {
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, FBTex->FBFrameBuffer);
  GFXError("GFXFrameBufferTarget");
}
GFXU32 GFXFrameBufferScreen = 0;
void GFXFrameBufferTargetScreen(void) {
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, GFXFrameBufferScreen);
  GFXError("GFXFrameBufferTarget");
}

void GFXRenderBegin(void) {}

void GFXRenderEnd(void) {}

void GFXLineWidth(GFXF32 W) { glLineWidth(W); }

static GFXS32 GFXGetUniformID(GFXU32 s, const GFXC8 *n, GFXU32 i) {
  GFXAssert(n[1] == 0);
  GFXC8 t[] = "X[0] ";
  t[0] = n[0];
  if (i < 10) {
    t[2] = '0' + i % 10;
    t[3] = ']';
    t[4] = 0;
  } else {
    t[2] = '0' + i / 10;
    t[3] = '0' + i % 10;
    t[4] = ']';
  }
  GFXS32 l = glGetUniformLocation(s, t);
  GFXODS("%s:%d ", t, l);
  // GFXAssert(l>=0);
  return l;
}

static GFXS32 GFXGetAttribID(GFXU32 s, const GFXC8 *n, GFXU32 i) {
  GFXAssert(n[1] == 0);
  GFXC8 t[] = "X0";
  t[0] = n[0];
  if (i < 10)
    t[1] = '0' + i;
  else
    t[1] = 'A' + i - 10;
  GFXS32 l = glGetAttribLocation(s, t);
  GFXODS("%s:%d ", t, l);
  // GFXAssert(l>=0);
  return l;
}

void GFXShaderCreate(GFXU32 s, const GFXC8 *VSource, const GFXC8 *FSource,
                     GFXU64 Flags) {
  GFXODS("\nShader:%d\n", s);
  GFXAssert(s < GFX_MAXSHADERS);
  GFXC8 *mv = 0, *mf = 0;

  if (Flags & GFXFLAG_LOAD) {
    GFXS32 s[2] = {GFXFileSize(VSource), GFXFileSize(FSource)};
    mv = GFXNew(GFXC8, (s[0] + 1));
    mf = GFXNew(GFXC8, (s[1] + 1));
    GFXFileLoad(VSource, mv, s[0]);
    GFXFileLoad(FSource, mf, s[1]);
    mv[s[0]] = 0;
    mf[s[1]] = 0;
  } else {
    mv = (GFXC8 *)VSource;
    mf = (GFXC8 *)FSource;
  }

  GFXAssert(!(ShadersActive & (1 << s)));

  GFXODS("\nShader:%d\n", s);

  GFXODS("Vertex Source Load...\n");
  GFXODS("%s\n", mv);

  GFXODS("Fragment Source Load...\n");
  GFXODS("%s\n", mf);

  GFXODS("Vertex...\n");
  VShader[s] = glCreateShader(GL_VERTEX_SHADER);
  GFXAssert(VShader[s]);
  glShaderSource(VShader[s], 1, (const char **)&mv, 0);
  glCompileShader(VShader[s]);

  GFXODS("Fragment...\n");
  FShader[s] = glCreateShader(GL_FRAGMENT_SHADER);
  GFXAssert(FShader[s]);
  glShaderSource(FShader[s], 1, (const char **)&mf, 0);
  glCompileShader(FShader[s]);

  VFShader[s] = glCreateProgram();
  glAttachShader(VFShader[s], VShader[s]);
  glAttachShader(VFShader[s], FShader[s]);
  glLinkProgram(VFShader[s]);

  for (GFXU32 i = 0; i < MaxVTMS; i++)
    SU[s].VTM[i] = GFXGetUniformID(VFShader[s], "M", i);
  GFXODS("\n");
  for (GFXU32 i = 0; i < MaxVUAS; i++)
    SU[s].VUA[i] = GFXGetUniformID(VFShader[s], "V", i);
  GFXODS("\n");
  for (GFXU32 i = 0; i < MaxVTUS; i++)
    SU[s].VTU[i] = GFXGetUniformID(VFShader[s], "S", i);
  GFXODS("\n");

  for (GFXU32 i = 0; i < MaxFTUS; i++)
    SU[s].FTU[i] = GFXGetUniformID(VFShader[s], "T", i);
  GFXODS("\n");
  for (GFXU32 i = 0; i < MaxFUAS; i++)
    SU[s].FUA[i] = GFXGetUniformID(VFShader[s], "F", i);
  GFXODS("\n");

  GFXODS("\n");
  for (GFXU32 i = 0; i < MaxVAVS; i++)
    SU[s].VAV[i] = GFXGetAttribID(VFShader[s], "A", i);

  GFXODS("\n");

  ShadersActive |= (1 << s);
  if (GFXErrorCheck("Shader Failed To Compile And Link:")) {
    ShaderLog(VShader[s]);
    ShaderLog(FShader[s]);
    ProgramLog(VFShader[s]);
    GFXAssert(0);
  }
  if (Flags & GFXFLAG_LOAD) {
    GFXDelete(mf);
    GFXDelete(mv);
  }
  GFXODS("\n");
}

void GFXShaderDestroy(GFXU32 s) {
  GFXAssert(s < GFX_MAXSHADERS);
  GFXAssert((ShadersActive & (1 << s)));
  glDeleteProgram(VFShader[s]);
  glDeleteShader(FShader[s]);
  glDeleteShader(VShader[s]);
  ShadersActive &= ~(1 << s);
}

void GFXOpen(GFXU32 W, GFXU32 H, GFX_MALLOC M, GFX_FREE F, GFX_FILELOAD L,
             GFX_FILESIZE S) {
  GFXAssert(M);
  GFXAssert(F);
  GFXAssert(L);
  GFXAssert(S);
  GFXAlloc = M;
  GFXDeAlloc = F;
  GFXFileLoader = L;
  GFXFileSizer = S;

  GFXWidth = W;
  GFXHeight = H;
  GFXODS("GFXOpen %dx%d\nBegin!\n", W, H);

  ShadersActive = 0;

  GFXODS("OpenGL Extensions:%s\n", (GFXC8 *)glGetString(GL_EXTENSIONS));
  GFXODS("OpenGL Vendor    :%s\n", (GFXC8 *)glGetString(GL_VENDOR));
  GFXODS("OpenGL Renderer  :%s\n", (GFXC8 *)glGetString(GL_RENDERER));
  GFXODS("OpenGL Version   :%s\n", (GFXC8 *)glGetString(GL_VERSION));
  GLint dat;
  glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, &dat);
  GFXODS("Max Vertex Attribs %d\n", dat);

  GFXU32 w, h;
  GFXAspectRatio(&w, &h, 1);
  GFXViewPort(0, 0, w, h);
  GFXClip(0, 0, 0, 0);

  GFXError("GFX Open");

  glEnable(GL_DITHER);
  glDisable(GL_CULL_FACE);
  glDisable(GL_BLEND);

  glEnable(GL_DEPTH_TEST);
  glClearDepthf(1);
  GFXZOptions(GFXFLAG_Z_WRITE_ON | GFXFLAG_Z_TEST_G);

  GFXCurrentShader = 0xffffffff;

  GFXU32 RGBA = 0xffffffff;
  GFXDefaultTex = GFXTexCreate(GFX_4XU8, 1, 1, &RGBA, 0, 0);

  glGetIntegerv(GL_FRAMEBUFFER_BINDING, (GLint *)&GFXFrameBufferScreen);

  GFXError("GFX Open End");
  GFXODS("GFXOpen End!\n");
}

void GFXShader(GFXU32 Shader) {
  if (GFXCurrentShader == Shader)
    return;
  glUseProgram(VFShader[Shader]);
  GFXCurrentShader = Shader;
}

void GFXShaderV4(GFXU32 Index, const GFXF32 *V4, GFXU32 NumberOf) {
  GFXAssert((Index & GFXFRAGV4) || (Index < MaxVUAS));
  GFXAssert((!(Index & GFXFRAGV4)) || ((Index & (~GFXFRAGV4)) < MaxFUAS));

  if (Index & GFXFRAGV4)
    glUniform4fv(SU[GFXCurrentShader].FUA[Index & (MaxFUAS - 1)], NumberOf, V4);
  else
    glUniform4fv(SU[GFXCurrentShader].VUA[Index], NumberOf, V4);
}

void GFXShaderM4(GFXU32 Index, const GFXF32 *M4, GFXU32 NumberOf) {
  GFXAssert(Index < MaxVTMS);

  glUniformMatrix4fv(SU[GFXCurrentShader].VTM[Index], NumberOf, GL_FALSE, M4);
}

void GFXClose(void) {}

void GFXClear(GFXU32 RGBA, GFXF32 Depth) {
  glClearColor(((RGBA >> 0) & 0xff) / 255.0f, ((RGBA >> 8) & 0xff) / 255.0f,
               ((RGBA >> 16) & 0xff) / 255.0f, ((RGBA >> 24) & 0xff) / 255.0f);
  glClearDepthf(Depth);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void GFXRGBAMask(GFXU32 RGBA) {
  glColorMask((RGBA & 0xff) ? 1 : 0, (RGBA & 0xff00) ? 1 : 0,
              (RGBA & 0xff0000) ? 1 : 0, (RGBA & 0xff000000) ? 1 : 0);
}

static GFXU32 GFXVBITranslateType[] = {GL_BYTE,
                                       GL_UNSIGNED_BYTE,
                                       GL_SHORT,
                                       GL_UNSIGNED_SHORT,
                                       GL_INT,
                                       GL_UNSIGNED_INT,
                                       GL_HALF_FLOAT,
                                       GL_FLOAT,
                                       GL_FIXED,
                                       GL_INT_2_10_10_10_REV,
                                       GL_UNSIGNED_INT_2_10_10_10_REV};
static GFXU32 GFXVBITranslateByteSize[] = {4 * 1, 4 * 1, 4 * 2, 4 * 2,
                                           4 * 4, 4 * 4, 4 * 2, 4 * 4,
                                           4 * 4, 4 * 1, 4 * 1};

void GFXBufferVertIndex(GFXBVI *BVI) {

  const GFXU32 t[3] = {GL_STATIC_DRAW, GL_DYNAMIC_DRAW, GL_STREAM_DRAW};

  if (BVI->Flags & GFX_BVI_UPDATE) {
    // GFXODS("Enter:\n");
    // CheckError();
    for (int i = 0; i < BVI->VN; i++)
      if (BVI->V[i].ByteLen) {
        GFXAssert(!(BVI->V[i].ByteOffset & 15));
        // GFXAssert(!(BVI->V[i].ByteLen & 15));
        GFXAssert(!(BVI->V[i].ByteLen & 7));
        // GFXAssert(!(BVI->V[i].ByteLen & 3));
        GFXAssert(BVI->V[i].ID);
        glBindBuffer(GL_ARRAY_BUFFER, BVI->V[i].ID);
        GFXAssert(BVI->V[i].Data);
        glBufferSubData(GL_ARRAY_BUFFER, BVI->V[i].ByteOffset,
                        BVI->V[i].ByteLen,
                        &((GFXU8 *)(BVI->V[i].Data))[BVI->V[i].ByteOffset]);
        // GFXODS("Buffer %d Fully Updated!\n", i);
      }
    // GFXODS("Leave:\n");
    // CheckError();
    return;
  }

  if (BVI->Flags & GFX_BVI_CREATE) {
    GFXODS("Enter Create GFXBVI:\n");
    glGenVertexArrays(1, &BVI->ID);
    GFXError("BVI Create");
    glBindVertexArray(BVI->ID);
    GFXError("BVI Create");
    int b = 0;
    for (int i = 0; i < BVI->VN; i++) {
      GFXAssert(!BVI->V[i].ID);
      GFXAssert(!(BVI->V[i].ByteStride & 3));
      glGenBuffers(1, &(BVI->V[i].ID));
      glBindBuffer(GL_ARRAY_BUFFER, BVI->V[i].ID);
      glBufferData(GL_ARRAY_BUFFER, BVI->V[i].ByteDataSize, BVI->V[i].Data,
                   t[BVI->V[i].SDS]);
      int s = BVI->V[i].ByteStride;
      GFXU64 bofs = 0;
      GFXODS("Buffer %d Creating...\n", i);
      for (int nv4 = 0; nv4 < BVI->V[i].NUV4; nv4++) {
        GFXODS("[%d.%d]: Byte Offset:%d Divisor:%d Stride:%d\n", i, nv4, bofs,
               BVI->V[i].InstDiv, s);
        GFXS32 VA = SU[GFXCurrentShader].VAV[b];
        if (VA < 0) {
          GFXODS(
              "BVI Warning: Argument:%d in vertex stride unused by shader.\n",
              b);
        } else {
          glEnableVertexAttribArray(VA);
          glVertexAttribPointer(
              VA, 4, GFXVBITranslateType[BVI->VType[b]],
              ((BVI->VNormalised & (1 << b)) ? GL_TRUE : GL_FALSE), s,
              (void *)(bofs));
          GFXError("BVI Create glVertexAttribPointer");
          glVertexAttribDivisor(VA, BVI->V[i].InstDiv);
          GFXError("BVI  glVertexAttribDivisor");
        }
        bofs += GFXVBITranslateByteSize[BVI->VType[b]];
        b++;
      }
      GFXODS("Buffer %d Created!\n", i);
    }
    if (BVI->I.NU16) {
      GFXAssert(!BVI->I.ID);
      GFXAssert((BVI->I.NU16 * sizeof(GFXU16)) == BVI->I.ByteDataSize);
      glGenBuffers(1, &(BVI->I.ID));
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, BVI->I.ID);
      GFXAssert(BVI->I.Data);
      glBufferData(GL_ELEMENT_ARRAY_BUFFER, BVI->I.ByteDataSize, BVI->I.Data,
                   t[BVI->I.SDS]);
      GFXODS("Leave Create GFXBVI:\n");
      GFXError("BVI Create");
    }
    return;
  }

  GFXAssert(0);
}

void GFXBufferVertIndexDestroy(GFXBVI *BVI) {
  for (int i = 0; i < BVI->VN; i++) {
    glDeleteBuffers(1, &BVI->V[i].ID);
    BVI->V[i].ID = 0;
  }
  if (BVI->I.NU16) {
    glDeleteBuffers(1, &BVI->I.ID);
    BVI->I.ID = 0;
  }
  glDeleteVertexArrays(1, &BVI->ID);
}

void GFXRender(GFXU32 PrimType, const GFXBVI *BVI, GFXS32 Instances) {

  glBindVertexArray(BVI->ID);
  if (BVI->I.NU16)
    glDrawElementsInstanced(PrimType, BVI->VC, GL_UNSIGNED_SHORT, 0, Instances);
  else
    glDrawArraysInstanced(PrimType, 0, BVI->VC, Instances);
}

void GFXZOptions(GFXU64 ZFlags) {
  if (ZFlags & GFXFLAG_Z_WRITE_OFF)
    glDepthMask(GL_FALSE);
  else
    glDepthMask(GL_TRUE);

  GFXU32 ztf = ZFlags & 0xff;
  if (ztf == GFXFLAG_Z_TEST_OFF)
    glDisable(GL_DEPTH_TEST);
  else {
    glEnable(GL_DEPTH_TEST);
    switch (ztf) {
    case GFXFLAG_Z_TEST_GE:
      glDepthFunc(GL_GEQUAL);
      break;
    case GFXFLAG_Z_TEST_G:
      glDepthFunc(GL_GREATER);
      break;
    case GFXFLAG_Z_TEST_LE:
      glDepthFunc(GL_LEQUAL);
      break;
    case GFXFLAG_Z_TEST_L:
      glDepthFunc(GL_LESS);
      break;
    case GFXFLAG_Z_TEST_ALWAYS:
      glDepthFunc(GL_ALWAYS);
      break;
    case GFXFLAG_Z_TEST_NEVER:
      glDepthFunc(GL_NEVER);
      break;
    default:
      GFXAssert(0);
      break;
    }
  }
}

static GFXU32 TranslateBlend[] = {GL_ZERO,
                                  GL_ONE,
                                  GL_SRC_COLOR,
                                  GL_ONE_MINUS_SRC_COLOR,
                                  GL_SRC_ALPHA,
                                  GL_ONE_MINUS_SRC_ALPHA,
                                  GL_BLEND_DST_ALPHA,
                                  GL_ONE_MINUS_DST_ALPHA,
                                  GL_DST_COLOR,
                                  GL_ONE_MINUS_DST_COLOR,
                                  GL_SRC_ALPHA_SATURATE,
                                  GL_CONSTANT_COLOR,
                                  GL_ONE_MINUS_CONSTANT_COLOR,
                                  GL_CONSTANT_ALPHA,
                                  GL_ONE_MINUS_CONSTANT_ALPHA};

void GFXBlend(GFXU32 BlendSrcRGB, GFXU32 BlendDstRGB, GFXU32 BlendSrcA,
              GFXU32 BlendDstA, GFXU32 ConstantRGBA) {

  glBlendColor(((ConstantRGBA >> 0) & 0xff) / 255.0f,
               ((ConstantRGBA >> 8) & 0xff) / 255.0f,
               ((ConstantRGBA >> 16) & 0xff) / 255.0f,
               ((ConstantRGBA >> 24) & 0xff) / 255.0f);
  if ((BlendSrcRGB != GFXBLEND_OFF) && (BlendDstRGB != GFXBLEND_OFF) &&
      (BlendSrcA != GFXBLEND_OFF) && (BlendDstA != GFXBLEND_OFF)) {
    glEnable(GL_BLEND);
    glBlendFuncSeparate(TranslateBlend[BlendSrcRGB],
                        TranslateBlend[BlendDstRGB], TranslateBlend[BlendSrcA],
                        TranslateBlend[BlendDstA]);
  } else {
    glDisable(GL_BLEND);
  }
}

void GFXCull(GFXU32 Mode) {

  switch (Mode) {
  case GFXCULL_NONE:
    glDisable(GL_CULL_FACE);
    break;
  case GFXCULL_CW:
    glEnable(GL_CULL_FACE);
    glFrontFace(GL_CW);
    break;
  case GFXCULL_CCW:
    glEnable(GL_CULL_FACE);
    glFrontFace(GL_CCW);
    break;
  }
}

static GFXU8 *TgaS;
static GFXS32 TgaRle, TgaR;
static GFXU32 TgaBytes(GFXS32 n) {
  GFXS32 i;
  static GFXU32 b;
  if (TgaR == 0) {
    TgaRle = *TgaS++;
    TgaR = (TgaRle & 0x7f) + 1;
    TgaRle &= 0x80;
    if (TgaRle) {
      b = 0;
      for (i = 0; i < n; i++) {
        b <<= 8;
        b |= *TgaS++;
      }
    }
  }
  if (TgaRle == 0) {
    b = 0;
    for (i = 0; i < n; i++) {
      b <<= 8;
      b |= *TgaS++;
    }
  }
  TgaR--;
  return b;
}

GFXTEXH GFXTGATexCreate(const GFXC8 *TGAF, GFXU64 Flags, void *Args) {
  GFXU8 *TGA = 0;
  if (Flags & GFXFLAG_LOAD) {
    GFXS32 s = GFXFileSize(TGAF);
    TGA = GFXNew(GFXU8, s);
    GFXFileLoad(TGAF, TGA, s);
  } else
    TGA = (GFXU8 *)TGAF;

  GFXU32 Type = TGA[2];
  GFXU32 PalSize = TGA[5] + (TGA[6] << 8);
  GFXU32 PalBPP = (TGA[7] >> 3);
  GFXS32 w = TGA[12] + (TGA[13] << 8);
  //  GFXAssert((w & (w - 1)));
  GFXS32 h = TGA[14] + (TGA[15] << 8);
  //  GFXAssert((h & (h - 1)));
  GFXU32 Bpp = TGA[16];

  GFXU8 *s = TGA + 18 + TGA[0];

  GFXU8 *RGBA = GFXNew(GFXU8, (((w * h) << 2)));

  GFXU8 *d = RGBA;

  GFXS32 fw = w << 2;

  if (Flags & GFXTGA_FLAGFLIPV)
    TGA[17] ^= (1 << 5);

  if (!(TGA[17] & (1 << 5))) {
    d += (h - 1) * fw;
    fw = -fw;
  }

  GFXS32 i, j;
  GFXU8 *Pal;

  GFXODS("TGA Type:%d\n", Type);
  TgaRle = 0;
  TgaR = 0;
  TgaS = s;
  switch (Type) {
  case 3:
    for (j = 0; j < h; j++) {
      for (i = 0; i < w; i++) {
        d[(i << 2) + 0] = s[0];
        d[(i << 2) + 1] = s[0];
        d[(i << 2) + 2] = s[0];
        d[(i << 2) + 3] = 0xff;
        s++;
      }
      d += fw;
    }
    break;
  case 1:
    Pal = s;
    s += PalSize * PalBPP;
    for (j = 0; j < h; j++) {
      for (i = 0; i < w; i++) {
        d[(i << 2) + 0] = Pal[s[0] * PalBPP + 2];
        d[(i << 2) + 1] = Pal[s[0] * PalBPP + 1];
        d[(i << 2) + 2] = Pal[s[0] * PalBPP + 0];
        d[(i << 2) + 3] = 0xff;
        s++;
      }
      d += fw;
    }
    break;
  case 2:
    switch (Bpp) {
    case 32:
      for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
          d[(i << 2) + 0] = s[2];
          d[(i << 2) + 1] = s[1];
          d[(i << 2) + 2] = s[0];
          d[(i << 2) + 3] = s[3];
          s += 4;
        }
        d += fw;
      }
      break;
    case 24:
      for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
          d[(i << 2) + 0] = s[2];
          d[(i << 2) + 1] = s[1];
          d[(i << 2) + 2] = s[0];
          d[(i << 2) + 3] = 0xff;
          s += 3;
        }
        d += fw;
      }
      break;
    case 16:
      for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
          GFXU16 *s16 = (GFXU16 *)s;
          d[(i << 2) + 0] = (((s16[0] >> 10) & 0x1f) << 3);
          d[(i << 2) + 1] = (((s16[0] >> 5) & 0x1f) << 3);
          d[(i << 2) + 2] = (((s16[0] >> 0) & 0x1f) << 3);
          d[(i << 2) + 3] = 0xff;
          s += 2;
        }
        d += fw;
      }
      break;
    default:
      while (1)
        ;
    }
    break;
  case (8 | 3):
    for (j = 0; j < h; j++) {
      for (i = 0; i < w; i++) {
        GFXU32 b = TgaBytes(1);
        d[(i << 2) + 0] = b;
        d[(i << 2) + 1] = b;
        d[(i << 2) + 2] = b;
        d[(i << 2) + 3] = 0xff;
      }
      d += fw;
    }
    break;
  case (8 | 1):
    Pal = s;
    TgaS += PalSize * PalBPP;
    for (j = 0; j < h; j++) {
      for (i = 0; i < w; i++) {
        GFXU32 b = TgaBytes(1) * PalBPP;
        d[(i << 2) + 0] = Pal[b + 2];
        d[(i << 2) + 1] = Pal[b + 1];
        d[(i << 2) + 2] = Pal[b + 0];
        d[(i << 2) + 3] = 0xff;
      }
      d += fw;
    }
    break;
  case (8 | 2):
    switch (Bpp) {
    case 32:
      for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
          GFXU32 b = TgaBytes(4);
          d[(i << 2) + 0] = ((b >> 8) & 0xff);
          d[(i << 2) + 1] = ((b >> 16) & 0xff);
          d[(i << 2) + 2] = ((b >> 24) & 0xff);
          d[(i << 2) + 3] = ((b >> 0) & 0xff);
        }
        d += fw;
      }
      break;
    case 24:
      for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
          GFXU32 b = TgaBytes(3);
          d[(i << 2) + 0] = ((b >> 0) & 0xff);
          d[(i << 2) + 1] = ((b >> 8) & 0xff);
          d[(i << 2) + 2] = ((b >> 16) & 0xff);
          d[(i << 2) + 3] = 0xff;
        }
        d += fw;
      }
      break;
    case 16:
      for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
          GFXU32 b = TgaBytes(2);
          d[(i << 2) + 0] = (((b >> 10) & 0x1f) << 3);
          d[(i << 2) + 1] = (((b >> 5) & 0x1f) << 3);
          d[(i << 2) + 2] = (((b >> 0) & 0x1f) << 3);
          d[(i << 2) + 3] = 0xff;
        }
        d += fw;
      }
      break;
    default:
      while (1)
        ;
    }
    break;
  default:
    while (1)
      ;
  }

  if (Flags & GFXTGA_INVERT) {
    for (GFXS32 i = 0; i < w * h; i++) {
      ((GFXU32 *)RGBA)[i] ^= 0xffffffff;
    }
  }

  if (Flags & GFXTGA_ALPHAGEN) {
    for (GFXS32 i = 0; i < w * h; i++) {
      GFXU32 r = RGBA[(i << 2) + 0], g = RGBA[(i << 2) + 1],
             b = RGBA[(i << 2) + 2];
      GFXU32 a = (r + g + b) / 3;
      RGBA[(i << 2) + 3] = a;
    }
  } else if (Flags & GFXTGA_ALPHAGENINV) {
    for (GFXS32 i = 0; i < w * h; i++) {
      GFXU32 r = RGBA[(i << 2) + 0], g = RGBA[(i << 2) + 1],
             b = RGBA[(i << 2) + 2];
      GFXU32 a = (r + g + b) / 3;
      RGBA[(i << 2) + 3] = a ^ 0xff;
    }
  }

  if (Flags & GFXTGA_TRANS0) {
    GFXU8 *s = RGBA;
    GFXU32 T0 = s[0] | (s[1] << 8) | (s[2] << 16);
    GFXODS("Trans0:%x\n", T0);
    for (GFXS32 i = 0; i < w * h; i++) {
      GFXU32 rgb = s[0] | (s[1] << 8) | (s[2] << 16);
      if (rgb == T0)
        s[3] = 0;
      else
        s[3] = 0xff;
      s += 4;
    }
  }

  if (Flags & GFXTGA_RGBA) {
    GFXU32 *s = (GFXU32 *)RGBA;
    for (GFXS32 i = 0; i < w * h; i++) {
      SysU32 c = s[i];
      if (c)
        c = (((GFXU32 *)Args)[0]);
      s[i] = c;
    }
  }

  if (Flags & GFXTGA_RGB) {
    GFXU32 *s = (GFXU32 *)RGBA;
    for (GFXS32 i = 0; i < w * h; i++) {
      SysU32 c = s[i];
      if (c)
        c = (c & 0xff000000) | (((GFXU32 *)Args)[0] & 0x00ffffff);
      s[i] = c;
    }
  }

  GFXU32 TexFmt = Flags & 7;
  GFXTEXH Tex;
  if (TexFmt == GFX_4XU8) {
    Tex = GFXTexCreate(GFX_4XU8, w, h, RGBA, 0, Flags);
  } else if (TexFmt == GFX_4XU4) {
    GFXU16 *d16 = (GFXU16 *)RGBA;
    GFXODS("Tex:4444RGBA\n");
    for (GFXS32 i = 0; i < w * h; i++) {
      GFXU32 r = RGBA[(i << 2) + 0] >> 4, g = RGBA[(i << 2) + 1] >> 4,
             b = RGBA[(i << 2) + 2] >> 4, a = RGBA[(i << 2) + 3] >> 4;
      d16[i] = (a << 0) | (b << 4) | (g << 8) | (r << 12);
    }
    Tex = GFXTexCreate(GFX_4XU4, w, h, d16, 0, Flags);
  } else {
    GFXAssert(TexFmt == GFX_3XU5U1);
    GFXU16 *d16 = (GFXU16 *)RGBA;
    GFXODS("Tex:5551RGBA\n");
    for (GFXS32 i = 0; i < w * h; i++) {
      GFXU32 r = RGBA[(i << 2) + 0] >> 3, g = RGBA[(i << 2) + 1] >> 3,
             b = RGBA[(i << 2) + 2] >> 3, a = RGBA[(i << 2) + 3] >> 7;
      d16[i] = (a << 0) | (b << 1) | (g << 6) | (r << 11);
    }
    Tex = GFXTexCreate(GFX_3XU5U1, w, h, d16, 0, Flags);
  }

  GFXDelete(RGBA);

  if (Flags & GFXFLAG_LOAD)
    GFXDelete(TGA);

  return Tex;
}
