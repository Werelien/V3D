
/*
RXMI Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "RXMI.h"
#include "SFX.h"
#include "SYS.h"
#include <memory.h>

#ifndef RXMI_LOG
#define RXMI_LOG -1
#endif
#include "math.h"
#include "stdio.h"
SysF64 RXMI_MIDINoteToHz(SysF64 MIDINote) {
  MIDINote = MIDINote < 0 ? 0 : MIDINote;
  MIDINote = MIDINote > 127 ? 127 : MIDINote;
  return 440.0 * pow(2, (MIDINote - 69.0) / 12.0);
}
RXMISTATUS RXMI = {0};
SysC8 RXMIDisplay[RXMI_MAX_LINES][RXMI_MAX_CHARS];
enum { FXMAX = 8 };
SysS32 FXChannel[FXMAX] = {[0 ...(FXMAX - 1)] = -1}, FXIndex = 0;
RXMINOTE FXN[FXMAX] = {[0 ...(FXMAX - 1)] = {.Note = -1}};
typedef SysU8 SEQPKT[4];
static int Seq(SEQPKT pkt);

enum { RXMI_MAXLAYOUTS = 4 };
static char *RXMI_LAYOUT[RXMI_MAXLAYOUTS] = {"WH", "WH90", "WH270", "DIA"};

const char *RXMINote[12] = {"C-", "C#", "D-", "D#", "E-", "F-",
                            "F#", "G-", "G#", "A-", "A#", "B-"};
SysS32 RXMI_Translate[256];
void RXMINormalise(void) {

  if (RXMI.NoteOffset < 0) {
    RXMI.NoteOffset = 11;
    RXMI.Octave--;
  }
  if (RXMI.NoteOffset > 11) {
    RXMI.NoteOffset = 0;
    RXMI.Octave++;
  }
  if (RXMI.Octave < 0) {
    RXMI.Octave = 10;
  }
  if (RXMI.Octave > 10) {
    RXMI.Octave = 0;
  }
  if (RXMI.Velocity < 0)
    RXMI.Velocity = 0;
  if (RXMI.Velocity > 1)
    RXMI.Velocity = 1;
  /*
  if (RXMI.PitchBend < -1)
    RXMI.PitchBend = -1;
  if (RXMI.PitchBend > 1)
    RXMI.PitchBend = 1;
    */
  if (RXMI.NotesOn <= 0) {
    RXMI.NotesOn = 0;
    RXMI.PitchBend = 0;
  }
  RXMI.Layout %= RXMI_MAXLAYOUTS;
}

SysS32 RXMIDisplayKeyboard(void) {
  SysAssert(RXMI.Flags);
  static RXMISTATUS lrxmi = {0};
  if ((RXMI.Octave == lrxmi.Octave) && (RXMI.NoteOffset == lrxmi.NoteOffset) &&
      (RXMI.Layout == lrxmi.Layout))
    return 4;
  lrxmi = RXMI;
  static int changes = 0;
  const char *kb[RXMI_MAXLAYOUTS][4] = {
      //
      {                                                            //
       "`15 117 219 321 423 525 627 729 831 933 035 -37 =39 B41",  //
       " T10 q12 w14 e16 r18 t20 y22 u24 i26 o28 p30 [32 ]34 R36", //
       "  C05 a07 s09 d11 f13 g15 h17 j19 k21 l23 ;25 '27 #29",    //
       "   \\00 z02 x04 c06 v08 b10 n12 m14 ,16 .18 /20"},         //
      {                                                            //
       "`15 117 219 321 423 525 627 729 831 933 035 -37 =39 B41",  //
       " T10 q12 w14 e16 r18 t20 y22 u24 i26 o28 p30 [32 ]34 R36", //
       "  C05 a07 s09 d11 f13 g15 h17 j19 k21 l23 ;25 '27 #29",    //
       "   \\00 z02 x04 c06 v08 b10 n12 m14 ,16 .18 /20"},         //
      {                                                            //
       "`15 117 219 321 423 525 627 729 831 933 035 -37 =39 B41",  //
       " T10 q12 w14 e16 r18 t20 y22 u24 i26 o28 p30 [32 ]34 R36", //
       "  C05 a07 s09 d11 f13 g15 h17 j19 k21 l23 ;25 '27 #29",    //
       "   \\00 z02 x04 c06 v08 b10 n12 m14 ,16 .18 /20"},         //
      {                                                            //
       "`10 111 213 315 417 518 620 722 823 925 027 -29 =30 B32",  //
       " T11 q12 w14 e16 r17 t19 y21 u23 i24 o26 p28 [29 ]31 R33", //
       "  C00 a01 s03 d05 f06 g08 h10 j11 k13 l15 ;17 '18 #20",    //
       "   \\00 z02 x04 c05 v07 b09 n11 m12 ,14 .16 /17"},         //
  };
  for (int i = 0; i < 256; i++)
    RXMI_Translate[i] = -1;
  for (int i = 0; i < 4; i++) {
    const char *s = kb[RXMI.Layout][i];
    char *d = RXMIDisplay[i];
    int n = 0, od = 0, j = 0;
    while (s[j]) {
      while (s[j] == ' ') {
        od += sprintf(&d[od], "  ");
        j++;
      }
      SysAssert(s[j]);
      int oc = s[j++];
      int c = oc;
      switch (c) {
      case 'B':
        c = SYS_BACKSPACE;
        break;
      case 'T':
        c = SYS_TAB;
        break;
      case 'R':
        c = SYS_RETURN;
        break;
      case 'C':
        c = SYS_CAPSLOCK;
        break;
      }
      int n = (s[j++] - '0');
      n = n * 10 + (s[j++] - '0');
      RXMI_Translate[c] = n;
      SysAssert(n >= 0);
      SysAssert(n < 100);
      n += RXMI.Octave * 12 + RXMI.NoteOffset;
      int ocn = n / 12 - 1;
      int ncn = n % 12;
      od += sprintf(&d[od], "[%c:%s%d]", oc, RXMINote[ncn], ocn);
    }
    od += sprintf(&d[od], "%c\n", (changes & 7) + '0');
    SysAssert(od < 256); //
  }
  changes++;
  return 4;
}

void RXMIDisplayStatus(void) {
  SysAssert(RXMI.Flags);
  int l = RXMIDisplayKeyboard();
  SysAssert(l < RXMI_MAX_LINES);
  char *d = RXMIDisplay[l];
  sprintf(d,
          "RXMI Status: Flags:%x Layout:%s Octave:%2d NoteOffset:%2d Midi:%s "
          "NotesOn:%d "
          "Pressed:%d Vel:%3.2f Bend:%3.2f U:%d D:%d L:%d R:%d",
          RXMI.Flags, RXMI_LAYOUT[RXMI.Layout], RXMI.Octave, RXMI.NoteOffset,
          RXMI.Midi ? "On" : "Off", RXMI.NotesOn, RXMI.KeysPressed,
          RXMI.Velocity, RXMI.PitchBend, RXMI.U, RXMI.D, RXMI.L, RXMI.R);
  for (int i = 0; i < RXMI_MAX_LINES; i++) {
    SysLog(RXMI_LOG, "%s\n", RXMIDisplay[i]);
  }
}

void RXMI_Close(void) {}

static void FXNoteOn(RXMINOTE r) {
  SysAssert(RXMI.Flags);
  if (r.Note < 0)
    return;
  RXMI.NotesOn++;
  if (RXMI.Midi) {
    SEQPKT pkt = {0x90, r.Note, 127 * RXMI.Velocity};
    Seq(pkt);
    return;
  } else {

    if (FXN[FXIndex].Note > 0) {
      FXChannel[FXIndex] = FXPlay(FXChannel[FXIndex], FXFadeOff, 7,
                                  -FXN[FXIndex].Frequency / 440, -1);
    }
    FXN[FXIndex] = r;
    FXChannel[FXIndex] =
        FXPlay(-1, FXStart, 7, -FXN[FXIndex].Frequency / 440, -1);
    SFXVol(FXChannel[FXIndex], RXMI.Velocity, RXMI.Velocity);
    FXIndex++;
    FXIndex &= (FXMAX - 1);
  }
}
static void NoteBend(SysF64 Bend) {
  SysAssert(RXMI.Flags);

  if (RXMI.Midi) {
    if (Bend > 1)
      Bend = 1;
    else if (Bend < -1)
      Bend = -1;
    int b = (Bend + 1) * 0.5f * ((1 << 14) - 1);
    int lsb = b & 0x7f, msb = (b >> 7) & 0x7f;
    printf("%d %x\n", b, b);
    SEQPKT pkt = {0xe0, lsb, msb};
    Seq(pkt);
    return;
  } else {
    SysF64 f;
    for (int i = 0; i < FXMAX; i++)
      if (FXN[i].Note > 0) {
        SysF64 n = FXN[i].Note + Bend * 2;
        f = RXMI_MIDINoteToHz(n);
        f = f * 32 * 1024 / 440;
        SFXFreq(FXChannel[i], f);
      }
  }
}

static void FXNoteOff(RXMINOTE r) {
  SysAssert(RXMI.Flags);
  if (r.Note < 0)
    return;
  if (RXMI.Midi) {
    SEQPKT pkt = {0x80, r.Note, 0};
    Seq(pkt);
    NoteBend(0);
  } else
    for (int i = 0; i < FXMAX; i++)
      if (FXN[i].Note == r.Note) {
        FXChannel[i] =
            FXPlay(FXChannel[i], FXFadeOff, 7, -FXN[i].Frequency / 440, -1);
        FXN[i].Note = -1;
      }
  RXMI.NotesOn--;
  if (RXMI.NotesOn <= 0) {
    RXMI.PitchBend = 0;
    RXMI.NotesOn = 0;
  }
}
void RXMI_WHMidiBend(SysF64 Bend, SysF64 Range) {
  RXMI.PitchBend += Bend * RXMI.UpdateDT;
  if ((Bend < 0) && (RXMI.PitchBend < Range))
    RXMI.PitchBend = Range;
  if ((Bend > 0) && (RXMI.PitchBend > Range))
    RXMI.PitchBend = Range;
  NoteBend(RXMI.PitchBend);
}
void RXMI_Update(void) {
  SysAssert(RXMI.Flags);
  RXMI.UpdateDT = SysSec() - RXMI.UpdateT;
  RXMI.UpdateT = SysSec();
  int shfd = (RXMI.LShf | RXMI.RShf);
  int altd = (RXMI.LAlt | RXMI.RAlt);
  int ctrd = (RXMI.LCtr | RXMI.RCtr);
  if (RXMI.NotesOn) {
    SysF64 d = ((1 + shfd * 5) * 0.5f) * 7 * (1 + ((RXMI.L) | (RXMI.R)) * 0.5f);
    if (RXMI.L) {
      RXMI_WHMidiBend(-d, -(0.5f + shfd * (3.5f - 0.5f)));
    } else if (RXMI.R) {
      RXMI_WHMidiBend(d, 0.5f + shfd * (3.5f - 0.5f));
    } else if (RXMI.U) {
      RXMI_WHMidiBend(d, 1 + shfd * (6 - 1));
    } else if (RXMI.D) {
      RXMI_WHMidiBend(-d, -(1 + shfd * (6 - 1)));
    } else if (RXMI.PitchBend) {
      SysF64 dir;
      if (RXMI.PitchBend >= 0)
        dir = -1;
      else
        dir = 1;
      RXMI_WHMidiBend(dir * d, 0);
    }
  } else {
    RXMI.PitchBend = 0;
    SysF64 t = 0.02f * RXMI.UpdateDT / 60.0f;
    if (RXMI.U) {
      RXMI.Velocity += 0.02f;
    } else if (RXMI.D) {
      RXMI.Velocity -= 0.02f;
    }
    if (RXMI.L) {
      RXMI.Velocity -= 0.01f;
    } else if (RXMI.R) {
      RXMI.Velocity += 0.01f;
    }
  }
  if (RXMI.Velocity != RXMI.LastVelocity) {
    RXMI.LastVelocity = RXMI.Velocity;
  }
  RXMINormalise();
  static SysU32 f = 0, ln = 0;
  if ((!(f & 15)) || (ln != RXMI.KeysPressed))
    RXMIDisplayStatus();
  f++;
  ln = RXMI.KeysPressed;
}

#include <memory.h>
void RXMI_Open(void) {
  if (!RXMI.Flags) {
    memset(&RXMI, 0, sizeof(RXMI));
    RXMI.Octave = 5;
    RXMI.NoteOffset = 0;
    RXMI.Velocity = 1;
    RXMI.PitchBend = 0;
    RXMI.Flags |= 1;
    RXMIDisplayKeyboard();
  }
}

void RXMI_WHMidiNote(SysS64 KeyboardCharacter, SysU64 Flag) {
  SysAssert(RXMI.Flags);
  int up = ((Flag & RXMI_FLGUP) != 0), down = !up, updown = down - up;
  int altd = (RXMI.LAlt | RXMI.RAlt) & down;
  int ctrd = (RXMI.LCtr | RXMI.RCtr) & down;
  int shfd = (RXMI.LShf | RXMI.RShf) & down;
  SysF64 Whammy = 12;
  RXMINOTE Note = {.Note = -1, .Timestamp = SysSec()};
  if (KeyboardCharacter < 0)
    return;
  RXMI.KeysPressed += updown;
  SysS32 n = -1;
  int chng = 0;
  switch (KeyboardCharacter) {
  case SYS_LALT:
    RXMI.LAlt = down;
    return;
  case SYS_RALT:
    RXMI.RAlt = down;
    return;
  case SYS_LCTRL:
    RXMI.LCtr = down;
    return;
  case SYS_RCTRL:
    RXMI.RCtr = down;
    return;
  case SYS_LSHIFT:
    RXMI.LShf = down;
    return;
  case SYS_RSHIFT:
    RXMI.RShf = down;
    return;
  case ' ':
    RXMI.Spc = down;
    return;
  case 'm':
    if (altd) {
      RXMI.Midi ^= 1;
      return;
    }
    break;
  case 'l':
    if (altd) {
      RXMI.Layout++;
      return;
    }
    break;
  case SYS_UP:
    RXMI.U = down;
    if (ctrd) {
      RXMI.Octave++;
      chng = 1;
      break;
    }
    break;
  case SYS_DOWN:
    RXMI.D = down;
    if (ctrd) {
      RXMI.Octave--;
      chng = 1;
      break;
    }
    break;
  case SYS_RIGHT:
    RXMI.R = down;
    if (ctrd) {
      RXMI.NoteOffset++;
      chng = 1;
      break;
    }
    break;
  case SYS_LEFT:
    RXMI.L = down;
    if (ctrd) {
      RXMI.NoteOffset--;
      chng = 1;
      break;
    }
    break;
  }
  if (chng) {
    return;
  }
  n = RXMI_Translate[KeyboardCharacter];
  if (n < 0)
    return;
  n += RXMI.Octave * 12 + RXMI.NoteOffset;
  Note.Note = n;
  Note.Frequency = RXMI_MIDINoteToHz(Note.Note);
  int ocn = n / 12;
  int ncn = n % 12;
  if (down)
    FXNoteOn(Note);
  else
    FXNoteOff(Note);
  return;
}
#include <alsa/asoundlib.h>
#include <unistd.h>
int Seq(SEQPKT pkt) {
  static snd_seq_event_t Event;
  static snd_seq_t *SeqH;
  static int MOPort;
  static snd_midi_event_t *EventParser;
  static snd_seq_event_t *MEvent;

  static int Status;
  static int init = 0;

  int res;

  if (!init) {
    init = 1;
    if ((Status = snd_seq_open(&SeqH, "default", SND_SEQ_OPEN_OUTPUT, 0)) < 0)
      return -1;
    snd_seq_set_client_name(SeqH, "RXMI");
    char portname[64] = "RXMI OUT";

    res = MOPort = snd_seq_create_simple_port(
        SeqH, portname, SND_SEQ_PORT_CAP_READ | SND_SEQ_PORT_CAP_SUBS_READ,
        SND_SEQ_PORT_TYPE_APPLICATION);

    if (res < 0) {
      SysAssert(0);
      Status = -1;
      snd_seq_close(SeqH);
      return -1;
    }
    res = snd_midi_event_new(3, &EventParser);
    if (res != 0) {
      SysAssert(0);
      Status = -1;

      snd_seq_close(SeqH);
      return -1;
    }
    snd_midi_event_init(EventParser);

    MEvent = &Event;
  }
  if (Status < 0) {
    SysAssert(0);
    return -1;
  }

  res = snd_midi_event_encode(EventParser, pkt, 3, MEvent);

  if (res < 0) {
    SysAssert(0);
  }

  snd_midi_event_reset_encode(EventParser);

  snd_seq_ev_set_subs(MEvent);
  snd_seq_ev_set_direct(MEvent);
  snd_seq_ev_set_source(MEvent, MOPort);

  snd_seq_event_output_direct(SeqH, MEvent);

  return 0;
}
