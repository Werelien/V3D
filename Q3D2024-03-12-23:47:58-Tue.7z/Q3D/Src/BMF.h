
/*
BMF Font Binary Format Reader
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
typedef char BMFC8;
typedef unsigned char BMFU8;
typedef signed char BMFS8;
typedef unsigned short BMFU16;
typedef signed short BMFS16;
typedef unsigned int BMFU32;
typedef signed int BMFS32;
typedef unsigned long long BMFU64;
typedef signed long long BMFS64;
typedef float BMFF32;
typedef double BMFF64;

typedef struct __attribute__((__packed__)) BMFHEADER {
  BMFC8 ID[3], Version;
} BMF_HEADER;

enum {
  BMF_BLOCK_TYPE_START = 1,
  BMF_BLOCK_TYPE_INFO = 1,
  BMF_BLOCK_TYPE_COMMON = 2,
  BMF_BLOCK_TYPE_PAGES = 3,
  BMF_BLOCK_TYPE_CHARS = 4,
  BMF_BLOCK_TYPE_KERNING = 5,
  BMF_BLOCK_TYPE_END,

  BMF_MAX_PAGES = 256,
  BMF_MAX_CHARS = 256
};

typedef struct __attribute__((__packed__)) BMF_BLOCK {
  BMFU8 Type;
  BMFU32 Bytes;
} BMF_BLOCK;

typedef struct __attribute__((__packed__)) BMF_INFO {
  BMFS16 FontSize;
  BMFU8
  Bits_SUIBFRRR; // 0:smooth1:unicode2:italic3:bold4:fixedH
  BMFU8 CharSet;
  BMFU16 StretchH;
  BMFU8 AA;
  BMFU8 PaddingUp;
  BMFU8 PaddingRight;
  BMFU8 PaddingDown;
  BMFU8 PaddingLeft;
  BMFU8 SpacingHoriz;
  BMFU8 SpacingVert;
  BMFU8 Outline;
  BMFC8 FontName[BMF_MAX_CHARS];
} BMF_INFO;

typedef struct __attribute__((__packed__)) BMF_COMMON {
  BMFU16 LineHeight;
  BMFU16 Base;
  BMFU16 SclW;
  BMFU16 SclH;
  BMFU16 Pages;
  BMFU8 Bits_RRRRRRRP; // 7:Packed
  BMFU8 AChannel;
  BMFU8 RChannel;
  BMFU8 GChannel;
  BMFU8 BChannel;
} BMF_COMMON;

typedef BMFC8 *BMF_PAGE;

typedef struct __attribute__((__packed__)) BMF_CHARS {
  BMFU32 ID;
  BMFU16 X;
  BMFU16 Y;
  BMFU16 Width;
  BMFU16 Height;
  BMFS16 XOffset;
  BMFS16 YOffset;
  BMFS16 XAdvance;
  BMFU8 Page;
  BMFU8 Channel;
} BMF_CHARS;

typedef struct __attribute__((__packed__)) BMF_KERNING {
  BMFU32 First;
  BMFU32 Second;
  BMFS16 Amount;
} BMF_KERNING;

typedef struct __attribute__((__packed__)) BMF {
  BMF_HEADER *Header;
  BMF_INFO *Info;
  BMF_COMMON *Common;
  BMF_CHARS *Char;
  BMF_KERNING *Kerning;
  BMF_PAGE Page[BMF_MAX_PAGES];
  BMFU32 Pages, Chars, Kernings;
} BMF;

BMF BMFParse(BMFC8 *BMFInMemory, BMFU32 BMFBytes, BMFU32 ToStdout);
