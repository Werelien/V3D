
#ifndef _RXMI_H_GS_2011_
#define _RXMI_H_GS_2011_
/*
RXMI Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "SYS.h"
enum { RXMI_MAX_LINES = 8, RXMI_MAX_CHARS = 256 };

typedef struct RXMINOTE {
  SysS32 Note;
  SysF64 Frequency;
  SysF64 Timestamp;
} RXMINOTE;

typedef struct RXMISTATUS {
  SysU32 Flags, Layout, Instrument, Channel;
  SysS32 Octave, NoteOffset;
  SysU8 LAlt, RAlt, LShf, RShf, LCtr, RCtr, Spc, U, D, L, R;
  SysS32 NotesOn, KeysPressed;
  SysF64 Velocity, LastVelocity, PitchBend, UpdateT, UpdateDT;
} RXMISTATUS;
void RXMI_Update(SysF64 TimeS);
void RXMI_Open(void);
void RXMI_Close(void);
extern RXMISTATUS RXMI;
extern SysC8 RXMIDisplay[RXMI_MAX_LINES][RXMI_MAX_CHARS];
#endif
