#include <SDL2/SDL_audio.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_video.h>
#ifdef __EMSCRIPTEN__
#include <SDL.h>
#include <emscripten.h>
#else
#include <SDL2/SDL.h>
#endif

#include "SYS.h"
#include <math.h>
#include <unistd.h>
static SysC8 *WDir;

static SysF64 SysStartSec = 0;

SysU32 SysAudioFreq = SYSAUDIO_FREQ, SysAudioFlags = SYSAUDIO_STEREO;
static SysS32 GLRGBAZD[6];
static SysS32 SYS_SCREEN_W = 1024, SYS_SCREEN_H = 768;

static SDL_AudioSpec AudioFmt;
static SDL_Window *SysMainWindow;
static SDL_GLContext SysMainContext;

static SysU64 XS128PS[2] = {0x2034f234a, 0xc345e342f3e5};
void SysRNGSeed(SysU64 Seed0, SysU64 Seed1) {
  XS128PS[0] = Seed0;
  XS128PS[1] = Seed1;
}

SysU64 SysRNG(void) {
  SysU64 x = XS128PS[0];
  SysU64 const y = XS128PS[1];
  XS128PS[0] = y;
  x ^= x << 23;
  XS128PS[1] = x ^ y ^ (x >> 17) ^ (y >> 26);
  return (XS128PS[1] + y);
}

static void UDPOpen(void) {}

SysU32 SysUDPBroadcastIP(void) { return 0; }

SysU32 SysUDPIP(SysC8 *IPDNSString) { return 0; }

SysU32 SysUDPSend(SysU32 IPAddress, SysU16 Port, void *Packet,
                  SysU32 PacketByteSize) {
  return 0;
}

SysU32 SysUDPBind(SysU32 IPAddress, SysU16 Port) { return 0; }

SysU32 SysUDPRecieve(SysU32 *IPAddress, SysU16 *Port, void *Packet,
                     SysU32 PacketByteSize, SysU32 *BytesRecieved) {
  return 0;
}

static void UDPClose(void) {}

SysF32 SysAspectRatio(SysU32 *Width, SysU32 *Height) {
  SDL_GL_GetDrawableSize(SysMainWindow, &SYS_SCREEN_W, &SYS_SCREEN_H);
  if (Width)
    *Width = SYS_SCREEN_W;
  if (Height)
    *Height = SYS_SCREEN_H;
  return (SysF32)SYS_SCREEN_W / (SysF32)SYS_SCREEN_H;
}

static SysS32 FlipAxis(SysS32 x) {
  x -= 0x4000;
  x = -x;
  x += 0x4000;
  return x;
}

const SysU8 *SysKeyState = 0;
static SysU32 SysPause = 0, SysActive = 0;
SysS32 SysPoll(void) {
  SysRNG();

  SysS32 QuitHit = 0;

  SDL_Event event;
  while (SDL_PollEvent(&event)) {

    switch (event.window.event) {
    case SDL_WINDOWEVENT_FOCUS_GAINED:
      SDL_PauseAudio(0);
      SysActive |= (1 << 1);
      break;
    case SDL_WINDOWEVENT_FOCUS_LOST:
      SDL_PauseAudio(1);
      SysActive |= (1 << 0);
      break;
    }

    SDL_MouseMotionEvent *pm = (SDL_MouseMotionEvent *)&event;
    SDL_MouseButtonEvent *pb = (SDL_MouseButtonEvent *)&event;

    switch (event.type) {
    case SDL_MOUSEBUTTONDOWN:
      if (pb->button & SDL_BUTTON(SDL_BUTTON_LEFT))
        SysUserInput(SYSINPUT_TOUCHON, 1,
                     FlipAxis((pb->y * 0x7fff) / SYS_SCREEN_H),
                     (pb->x * 0x7fff) / SYS_SCREEN_W, 0, 0x7fff);
      if (pb->button & SDL_BUTTON(SDL_BUTTON_MIDDLE))
        SysUserInput(SYSINPUT_ACCEL, SysSec(),
                     0x4000 - (pb->x * 0x7fff) / SYS_SCREEN_W,
                     0x4000 - (pb->y * 0x7fff) / SYS_SCREEN_H, 0, 0x7fff);
      break;
    case SDL_MOUSEBUTTONUP:
      if (pb->button == 1)
        SysUserInput(SYSINPUT_TOUCHOFF, 1, (pb->x * 0x7fff) / SYS_SCREEN_W,
                     (pb->y * 0x7fff) / SYS_SCREEN_H, 0, 0x7fff);
      break;
    case SDL_MOUSEMOTION:
      if (pm->state & SDL_BUTTON(SDL_BUTTON_LEFT))
        SysUserInput(SYSINPUT_TOUCHMOVE, 1,
                     FlipAxis((pm->y * 0x7fff) / SYS_SCREEN_H),
                     (pm->x * 0x7fff) / SYS_SCREEN_W, 0, 0x7fff);
      if (pm->state & SDL_BUTTON(SDL_BUTTON_MIDDLE))
        SysUserInput(SYSINPUT_ACCEL, SysSec(),
                     0x4000 - (pm->x * 0x7fff) / SYS_SCREEN_W,
                     0x4000 - (pm->y * 0x7fff) / SYS_SCREEN_H, 0, 0x7fff);
      break;
    case SDL_QUIT:
      QuitHit = 1;
      break;
    }
  }

  SysKeyState = SDL_GetKeyboardState(NULL);
  QuitHit |= (SysKeyState[SDL_SCANCODE_LALT] && SysKeyState[SDL_SCANCODE_Q]);
  QuitHit |= SysKeyState[SDL_SCANCODE_ESCAPE];
  static SysU32 Flags = 0;
  static SysS32 CurrentTurn = 0;

  SysS32 t = SysKeyState[SDL_SCANCODE_Q] - SysKeyState[SDL_SCANCODE_W];
  SysS32 f = SysKeyState[SDL_SCANCODE_A] - SysKeyState[SDL_SCANCODE_2];
  if ((t + (f << 8)) != CurrentTurn) {
    SysUserInput(SYSINPUT_ACCEL, SysSec(), 0xff, t * 0x30, f * 0x30, 0x7fff);
    CurrentTurn = (t + (f << 8));
  }

  if (SysPause == 0)
    if (SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 1;
  if (SysPause == 1)
    if (!SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 4 | 1;
  if (SysPause == (4 | 1))
    if (SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 2;
  if (SysPause == 2)
    if (!SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 4 | 2;

  if (SysKeyState[SDL_SCANCODE_O]) {
    if (!(Flags & 4))
      SysUserInput(SYSINPUT_TOUCHON, 1, 0x4000, 0x4000 - 0x2000, 0, 0x7fff);
    Flags |= 4;
  } else if (Flags & 4) {
    SysUserInput(SYSINPUT_TOUCHOFF, 1, 0x4000, 0x4000 - 0x2000, 0, 0x7fff);
    Flags &= ~4;
  }

  if (SysKeyState[SDL_SCANCODE_P]) {
    if (!(Flags & 8))
      SysUserInput(SYSINPUT_TOUCHON, 2, 0x4000, 0x4000 + 0x2000, 0, 0x7fff);
    Flags |= 8;
  } else if (Flags & 8) {
    SysUserInput(SYSINPUT_TOUCHOFF, 2, 0x4000, 0x4000 + 0x2000, 0, 0x7fff);
    Flags &= ~8;
  }

  if (SysKeyState[SDL_SCANCODE_F]) {
    if (!(Flags & 16))
      SysUserInput(SYSINPUT_TOUCHON, 1, 0x4000 + 0x2000, 0x4000, 0, 0x7fff);
    Flags |= 16;
  } else if (Flags & 16) {
    SysUserInput(SYSINPUT_TOUCHOFF, 1, 0x4000 + 0x2000, 0x4000, 0, 0x7fff);
    Flags &= ~16;
  }

  if (SysKeyState[SDL_SCANCODE_SPACE]) {
    if (!(Flags & 32))
      SysUserInput(SYSINPUT_TOUCHON, 1, 0x4000 - 0x2000, 0x4000, 0, 0x7fff);
    Flags |= 32;
  } else if (Flags & 32) {
    SysUserInput(SYSINPUT_TOUCHOFF, 1, 0x4000 - 0x2000, 0x4000, 0, 0x7fff);
    Flags &= ~32;
  }

  return QuitHit;
}

void SysWindowTitle(SysC8 *s) { SDL_SetWindowTitle(SysMainWindow, s); }

SysS32 SysSwap(void) {
  // SDL_GL_SwapBuffers( );
  SDL_GL_SwapWindow(SysMainWindow);
  return SysPoll();
}

void SysAudioCallBack(void *UserData, SysU8 *Stream, SysS32 Len) {
  SysUserAudio(SysAudioFlags, SysAudioFreq, Stream, Len);
}

void DisplayTimeSec(SysF64 t) {
  SysU32 s = fmod(t, 60);
  t /= 60;
  SysU32 m = fmod(t, 60);
  t /= 60;
  SysU32 h = fmod(t, 24);
  t /= 24;
  SysU32 d = t;
  SysODS("%d:%d:%d:%d", d, h, m, s);
}

static SysS32 SysOpened = 0;

void SysSDLExit(const char *msg) {
  printf("%s: %s\n", msg, SDL_GetError());
  SDL_Quit();
  exit(1);
}

void SysCheckSDLError(int line) {
  const char *error = SDL_GetError();
  if (*error != '\0') {
    printf("SDL Error: %s\n", error);
    if (line != -1)
      printf(" + line: %i\n", line);
    SDL_ClearError();
  }
}
static Mix_Music *Music=0;
SysS32 SysMusicOn(SysC8 *FileName, SysF32 FadeInS, SysS32 Loops) {
  if(Music) return 0;
  Mix_HaltMusic(); 
  Music = Mix_LoadMUS(FileName);
  SysAssert(Music);
  Mix_PlayMusic(Music, Loops);
  Mix_FadeInMusic(Music, Loops, FadeInS * 1000);
  SysODS("Music Playing %s \n",FileName);
  SysMusicResume();
  return 0;
}

SysS32 SysMusicVolume(SysF32 Volume)
{
  if(!Music) return 0;
  Mix_VolumeMusic(128*Volume);
  return 0; 
}

SysS32 SysMusicPause(void){
  if(!Music) return 0;
  Mix_PauseMusic();
  return 0;
  }

SysS32 SysMusicResume(void){
  if(!Music) return 0;
  Mix_ResumeMusic();
  return 0;
  }

SysS32 SysMusicOff(SysF32 FadeOut) {
  if(!Music) return 0;
  Mix_FadeOutMusic(FadeOut * 1000);
  Music=0;
  return 0;
}

void SysAudioMixerCallBack(SysS32 Channel, void *Stream, SysS32 Len,
                           void *UserData) {
  static SysU64 f=0;
  if(!f)
  {
    SysODS("Audio Callback: Frame Length %d Bytes  %f Frames/s\n",Len,SysAudioFreq/(Len/4.0f));
    f=1;
  }
  SysUserAudio(SysAudioFlags, SysAudioFreq, Stream, Len);
}

SysS32 SysOpen(SysS32 Flags) {
  SysStartSec = SysSec();
  SysODS("C Version:%d\n", __STDC_VERSION__);
  WDir = SDL_GetBasePath();
  SysODS("SDL Opening...%s\n", WDir);
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) <
      0) /* Initialize SDL's Video subsystem */
    SysSDLExit("Unable to initialize SDL"); /* Or die on error */

  int novd = SDL_GetNumVideoDrivers();

  SysODS("\n\nVideo Drivers:\n");
  for (int i = 0; i < novd; i++)
    SysODS("%d: %s\n", i, SDL_GetVideoDriver(i));
  SysODS("\n");
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);

  /* Create our window centered at 512x512 resolution */
#ifdef __EMSCRIPTEN__
  SysMainWindow = SDL_CreateWindow(
      "V3D", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SYS_SCREEN_W,
      SYS_SCREEN_H, SDL_WINDOW_OPENGL | SDL_WINDOW_FULLSCREEN);
#else
  SysMainWindow = SDL_CreateWindow(
      "V3D", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SYS_SCREEN_W,
      SYS_SCREEN_H,
      SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN);
#endif

  if (!SysMainWindow) /* Die if creation failed */
    SysSDLExit("Unable to create window");

  // #ifdef __EMSCRIPTEN__
  //   SDL_SetWindowFullscreen(SysMainWindow, SDL_WINDOW_FULLSCREEN_DESKTOP);
  // #endif

  // SDL_DisplayMode mode;
  SDL_GetWindowSize(SysMainWindow, &SYS_SCREEN_W, &SYS_SCREEN_H);
  SysODS("SysOpen: Window Screen Width:%d Window Screen Height:%d\n",
         SYS_SCREEN_W, SYS_SCREEN_H);
  SDL_GL_GetDrawableSize(SysMainWindow, &SYS_SCREEN_W, &SYS_SCREEN_H);
  SysODS("SysOpen:GL Drawable Screen Width:%d GL Drawable Screen Height:%d\n",
         SYS_SCREEN_W, SYS_SCREEN_H);
  // SYS_SCREEN_W = mode.w;
  // SYS_SCREEN_H = mode.h;

  SysCheckSDLError(__LINE__);

  /* Create our opengl context and attach it to our window */
  SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 0);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
  SysMainContext = SDL_GL_CreateContext(SysMainWindow);
  SysCheckSDLError(__LINE__);

  /* This makes our buffer swap syncronized with the monitor's vertical refresh
   */
  SDL_GL_SetSwapInterval(1);

  SDL_GL_GetAttribute(SDL_GL_RED_SIZE, &GLRGBAZD[0]);
  SDL_GL_GetAttribute(SDL_GL_GREEN_SIZE, &GLRGBAZD[1]);
  SDL_GL_GetAttribute(SDL_GL_BLUE_SIZE, &GLRGBAZD[2]);
  SDL_GL_GetAttribute(SDL_GL_ALPHA_SIZE, &GLRGBAZD[3]);
  SDL_GL_GetAttribute(SDL_GL_DEPTH_SIZE, &GLRGBAZD[4]);
  SDL_GL_GetAttribute(SDL_GL_DOUBLEBUFFER, &GLRGBAZD[5]);
  SysODS("Video Mode Set: W:%d H:%d RGBA:%d%d%d%d Z:%d DoubleBuffer:%d\n",
         SYS_SCREEN_W, SYS_SCREEN_H, GLRGBAZD[0], GLRGBAZD[1], GLRGBAZD[2],
         GLRGBAZD[3], GLRGBAZD[4], GLRGBAZD[5]);
  /*
    SDL_memset(&AudioFmt, 0, sizeof(AudioFmt));
    AudioFmt.freq = SysAudioFreq;
    AudioFmt.format = AUDIO_S16LSB;
    AudioFmt.channels = (SysAudioFlags & SYSAUDIO_STEREO) ? 2 : 1;
    AudioFmt.samples = SysAudioFreq / 30;
    AudioFmt.callback = SysAudioCallBack;
    AudioFmt.userdata = NULL;
    if (SDL_OpenAudio(&AudioFmt, NULL) != 0) {
      printf("Audio Error!\n");
      exit(1);
    }
    SysODS("Audio:%dHz %x %x %x\n", SysAudioFreq, AUDIO_S16LSB,
    SYSAUDIO_STEREO);
  */
  int Stereo=(SysAudioFlags & SYSAUDIO_STEREO) ? 2 : 1,FrameSize;
  FrameSize=SysAudioFreq/60;
  if(FrameSize<128) FrameSize=128;
  if (Mix_OpenAudio(SysAudioFreq, AUDIO_S16LSB,
                    Stereo,
                    FrameSize) == -1) {
    SysODS("Mix_OpenAudio: %s\n", Mix_GetError());
    SysSDLExit("Mix Audio Error");
    exit(2);
  }
  int numtimesopened, frequency, channels;
  Uint16 format;
  numtimesopened = Mix_QuerySpec(&frequency, &format, &channels);
  if (!numtimesopened) {
    SysODS("Mix_QuerySpec: %s\n", Mix_GetError());
    SysSDLExit("Mix Audio Query Error!");
    exit(2);
  } else {
    SysAssert(format==AUDIO_S16LSB);
    SysAssert(channels == Stereo);
    char *format_str = "Unknown";
    switch (format) {
    case AUDIO_U8:
      format_str = "U8";
      break;
    case AUDIO_S8:
      format_str = "S8";
      break;
    case AUDIO_U16LSB:
      format_str = "U16LSB";
      break;
    case AUDIO_S16LSB:
      format_str = "S16LSB";
      break;
    case AUDIO_U16MSB:
      format_str = "U16MSB";
      break;
    case AUDIO_S16MSB:
      format_str = "S16MSB";
      break;
    }
    SysODS("SDL Mixer: Opened=%d  Freq=%dHz  Fmt=%s  Channels=%d\n",
           numtimesopened, frequency, format_str, channels);
    SysAudioFreq = frequency;
  }
  int t = Mix_AllocateChannels(1);
  SysODS("SDL Mixer:%d Mixing Channel(s)\n", t);
  static SysU8 AudioMem[4 * 2 * 2 * 1024];
  // for(int i=0;i<sizeof(AudioMem);i++) AudioMem[i]=SysRNG()&0xff;
  static Mix_Chunk MixChunk = {0, AudioMem, sizeof(AudioMem), 128};
  int c = Mix_PlayChannel(-1, &MixChunk, -1);
  SysODS("Mixing on channel:%d\n", c);
  Mix_RegisterEffect(c, SysAudioMixerCallBack, 0, 0);

  UDPOpen();
  SysODS("Performance Counter:%d Frequency:%d(%f)\n",
         SDL_GetPerformanceCounter(), SDL_GetPerformanceFrequency(),
         SDL_GetPerformanceFrequency() / 1000000000.0f);
  SysODS("SysOpen RealTime:");
  DisplayTimeSec(SysSec());
  SysODS(" Monotonic:");
  DisplayTimeSec(SysSec());
  SysODS("\n");
  SysOpened = 1;
  return 0;
}

SysS32 SysClose(SysS32 Flags) {
  SysAssert(SysOpened);
  Mix_CloseAudio();
  UDPClose();
  SDL_GL_DeleteContext(SysMainContext);
  SDL_DestroyWindow(SysMainWindow);
  SDL_Quit();
  SysOpened = 0;
  return 0;
}

SysU32 SysState(SysS32 Cmd, void *Arg) {
  switch (Cmd) {
  case SYSSTATE_AUDIOOFF:
    SDL_PauseAudio(1);
    break;
  case SYSSTATE_AUDIOON:
    SDL_PauseAudio(0);
    break;
  case SYSSTATE_UDPON:
    break;
  }
  return 0;
}

#define SYSIO
SysS32 SysLoad(SysU32 Flags, const SysC8 *OFileName, SysU32 Offset, SysU32 Size,
               void *Buffer) {
#ifdef SYSIO

  FILE *f;
  SysS32 l;
  SysODS("Attempting to load %s... ", OFileName);
  SysC8 FileName[256];
#ifdef SYSLSDIR
  if (Flags == SYSLOADSAVE_USERDIR) {
    strcpy(FileName, "../");
    strcat(FileName, OFileName);
  } else
#endif
    strcpy(FileName, OFileName);

  f = fopen(FileName, "rb");
  if (f == NULL) {
    SysODS("Failed to open file %s!\n", FileName);
    return 0;
  }
  if (Size && Buffer) {
    fseek(f, Offset, SEEK_SET);
    l = fread(Buffer, 1, Size, f);
  } else {
    fseek(f, 0, SEEK_END);
    l = ftell(f);
  }
  fclose(f);
  SysODS("File %s successfully closed!\n", FileName);
  return l;
#else
  return 0;
#endif
}

SysS32 SysSave(SysU32 Flags, const SysC8 *OFileName, SysU32 Size,
               void *Buffer) {
#ifdef SYSIO
  SysC8 FileName[256];
#ifdef SYSLSDIR
  if (Flags == SYSLOADSAVE_USERDIR) {
    strcpy(FileName, "../");
    strcat(FileName, OFileName);
  } else if (!l)
    return;

#endif
  strcpy(FileName, OFileName);
  FILE *f = fopen(FileName, "wb");
  SysAssert(f);
  if (Size)
    fwrite(Buffer, sizeof(char), Size, f);
  fclose(f);
#endif
  return 0;
}

SysF64 SysSec(void) {
  SysF64 cf = (SysF64)(SDL_GetPerformanceCounter()) /
              (SysF64)(SDL_GetPerformanceFrequency());
  return cf - SysStartSec;
}

static SysS32 SysR = 0;
void SysLoop(void) {
  SysU32 s = 0;
  if (SysPause == (4 | 2)) {
    SDL_PauseAudio(0);
    s = SYSFRAME_RESUME;
    SysPause = 0;
  } else if (SysPause) {
    s = SYSFRAME_PAUSE;
    SDL_PauseAudio(1);
  }
  if (SysActive == 1)
    s = SYSFRAME_PAUSE;
  else if (SysActive) {
    s = SYSFRAME_RESUME;
    SysActive = 0;
  }
  SysR = SysUserFrame(s);
  if (SysSwap())
    SysR = SYSFRAME_QUIT;
}

int main(int argc, char *argv[]) {
  SysR = 0;
  SysOpen(0);
#ifdef __EMSCRIPTEN__
  emscripten_set_main_loop(SysLoop, 0, 1);
#else
  while (SysR != SYSFRAME_QUIT)
    SysLoop();
#endif
  SysClose(0);
  SysODS("Sys Finished\n");
  return 0;
}

/*
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

#undef malloc
#undef free

#define MAX_MEMORY_DEFAULT (32 * 1024 * 1024)

#ifdef SYS_MAX_MEMORY
#define MAX_MEMORY SYS_MAX_MEMORY
#else
#define MAX_MEMORY MAX_MEMORY_DEFAULT
#endif

static SysU8 Mem[MAX_MEMORY];
static SysU64 MemOffset = 0;

typedef struct SysAllocS {
  void *prev;
  SysU64 size;
  SysU8 data[];
} SysAllocS;

typedef struct SysAllocInfoS {
  SysAllocS *curr;
  SysS64 count, maxcount, size, maxsize;

} SysAllocInfoS;

static SysAllocInfoS SysAllocInfo = {0, 0, 0, 0, 0};

void *SysDbgAlloc(SysU32 Bytes, const SysC8 *File, SysU32 Line) {
  SysAssert(Bytes);
  SysAllocS *m = (SysAllocS *)&Mem[MemOffset];
  MemOffset += (Bytes + sizeof(SysAllocS));
  SysAssert(MemOffset < MAX_MEMORY);
  m->prev = SysAllocInfo.curr;
  m->size = Bytes;
  SysAllocInfo.curr = m;
  SysAllocInfo.count++;
  if (SysAllocInfo.count > SysAllocInfo.maxcount)
    SysAllocInfo.maxcount = SysAllocInfo.count;
  SysAllocInfo.size += Bytes;
  if (SysAllocInfo.size > SysAllocInfo.maxsize)
    SysAllocInfo.maxsize = SysAllocInfo.size;
  SysODS("SysAlloc: [%s:%d] Curr:%llx Bytes:%d Count:%d MaxCount:%d Size:%d "
         "MaxSize:%d\n",
         File, Line, SysAllocInfo.curr, Bytes, SysAllocInfo.count,
         SysAllocInfo.maxcount, SysAllocInfo.size, SysAllocInfo.maxsize);
  return &((SysU8 *)m)[sizeof(SysAllocS)];
}

void SysDbgFree(void *Mem, const SysC8 *File, SysU32 Line) {
  if (!Mem)
    return;
  SysAssert(SysAllocInfo.curr);
  SysAllocS *m = (SysAllocS *)(&((SysU8 *)Mem)[-sizeof(SysAllocS)]);
  SysAssert(SysAllocInfo.curr == m);
  SysAllocInfo.curr = (SysAllocS *)(m->prev);
  SysAllocInfo.count--;
  SysAllocInfo.size -= m->size;
  SysODS("SysFree: [%s:%d] Curr:%llx Bytes:%d Count:%d MaxCount:%d Size:%d "
         "MaxSize:%d\n",
         File, Line, SysAllocInfo.curr, m->size, SysAllocInfo.count,
         SysAllocInfo.maxcount, SysAllocInfo.size, SysAllocInfo.maxsize);
  MemOffset -= (m->size + sizeof(SysAllocS));
}

#ifdef SYS_DEBUG_ODS
void SysODS(const SysC8 *DebugString, ...) {
  va_list args;
  va_start(args, DebugString);
  printf("%f:  ", SysSec());
  vprintf(DebugString, args);
  fflush(stdout);
  va_end(args);
}

#include <stdlib.h>
void SysKill(SysS32 C) { exit(C); }

#else
void SysODS(const SysC8 *DebugString, ...){};
#endif
