emcc -O3 -s FULL_ES2=1 -s  USE_SDL=2 -s USE_SDL_MIXER=2 -sMIN_WEBGL_VERSION=2 -sINITIAL_MEMORY=67108864 --preload-file Assets GFX.c Implementation.c SFX.c SysSDL.c Q3D.c -o Q3DWeb/Q3D.html
