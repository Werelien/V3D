#ifndef _SYS_H_GS_2011_
#define _SYS_H_GS_2011_

typedef char SysC8;
typedef unsigned char SysU8;
typedef signed char SysS8;
typedef unsigned short SysU16;
typedef signed short SysS16;
typedef unsigned int SysU32;
typedef signed int SysS32;
typedef unsigned long long SysU64;
typedef signed long long SysS64;
typedef float SysF32;
typedef double SysF64;

enum {
  SYSINPUT_TOUCHON = 0x10000,
  SYSINPUT_TOUCHOFF = 0x10001,
  SYSINPUT_TOUCHMOVE = 0x10002,
  SYSINPUT_ACCEL = 0x20000,
  SYSSTATE_AUDIOON = 1,
  SYSSTATE_AUDIOOFF = -1,
  SYSSTATE_UDPON = 2,
  SYSSTATE_UDPOFF = -2,
  SYSTATE_TITLE = 3,
  SYSAUDIO_STEREO = (1 << 0),
  SYSAUDIO_FREQ = 44100,
  SYSFRAME_QUIT = (1 << 0),
  SYSFRAME_PAUSE = (1 << 0),
  SYSFRAME_RESUME = (1 << 1),
  SYSFRAME_GL_CREATE = (1 << 2),
  SYSFRAME_GL_CHANGE = (1 << 3),
  SYSLOADSAVE_DEFAULTDIR = 0,
  SYSLOADSAVE_USERDIR = (1 << 1),
  SYSTXTSTYLE_BOLD = 0,
  SYSTXTSTYLE_ITALIC,
  SYSTXTSTYLE_UNDERLINE,
  SYSTXTSTYLE_STRIKETHROUGH,
  SYSTXTSTYLE_NORMAL,
  SYS_LAST
};

SysU32 SysState(SysS32 Cmd, void *Arg);
SysU32 SysUDPIP(SysC8 *IPDNSString);
SysU32 SysUDPBroadcastIP(void);
SysU32 SysUDPSend(SysU32 IPAddress, SysU16 Port, void *Packet,
                  SysU32 PacketByteSize);
SysU32 SysUDPBind(SysU32 IPAddress, SysU16 Port);
SysU32 SysUDPRecieve(SysU32 *IPAddress, SysU16 *Port, void *Packet,
                     SysU32 PacketByteSize, SysU32 *BytesRecieved);
SysF64 SysSec(void);
void SysRNGSeed(SysU64 Seed0, SysU64 Seed1);
SysU64 SysRNG(void);
SysS32 SysLoad(SysU32 Flags, const SysC8 *FileName, SysU32 Offset, SysU32 Size,
               void *Buffer);
SysS32 SysSave(SysU32 Flags, const SysC8 *FileName, SysU32 Size, void *Buffer);
SysF32 SysAspectRatio(SysU32 *Width, SysU32 *Height);
SysS32 SysUserInput(SysU32 Flags, SysU32 ID, SysS32 X, SysS32 Y, SysS32 Z,
                    SysS32 Pressure);
SysS32 SysUserFrame(SysS32 Flags);

extern SysU32 SysAudioFreq,SysAudioFlags;
SysS32 SysUserAudio(SysU32 Flags, SysU32 AudioFreq, SysU8 *Stream, SysS32 Len);
SysS32 SysMusicOn(SysC8 *FileName, SysF32 FadeInS, SysS32 Loops);
SysS32 SysMusicPause(void);
SysS32 SysMusicVolume(SysF32 Volume);
SysS32 SysMusicResume(void);
SysS32 SysMusicOff(SysF32 FadeOut);

extern const SysU8 *SysKeyState;
void SysKill(SysS32 n);
void SysWindowTitle(SysC8 *s);
void *SysDbgAlloc(SysU32 Bytes, const SysC8 *File, SysU32 Line);
void SysDbgFree(void *Mem, const SysC8 *File, SysU32 Line);
void SysODS(const SysC8 *DebugString, ...);

#define malloc MALLOC_NOT_ALLOWED
#define free FREE_NOT_ALLOWED

#ifdef SYS_DEBUG_ODS

#define SysNew(T, S) (T *)SysDbgAlloc(sizeof(T) * (S), __FILE__, __LINE__)
#define SysDelete(M) SysDbgFree(M, __FILE__, __LINE__)
#include <assert.h>
#define SysAssert(exp) assert(exp)

#else

#define SysNew(T, S) (T *)SysDbgAlloc(sizeof(T) * (S), 0, 0)
#define SysDelete(M) SysDbgFree(M, 0, 0)
#define SysAssert(exp)

#endif

#endif
