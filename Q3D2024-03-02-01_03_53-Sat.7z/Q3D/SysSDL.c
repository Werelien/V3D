/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/

#include <SDL2/SDL_audio.h>
#include <SDL2/SDL_events.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_mouse.h>
#include <SDL2/SDL_scancode.h>
#include <SDL2/SDL_timer.h>
#include <SDL2/SDL_touch.h>
#include <SDL2/SDL_video.h>
#include <stdint.h>
#ifdef __EMSCRIPTEN__
#include <SDL.h>
#include <emscripten.h>
#else
#include <SDL2/SDL.h>
#endif

#include "SYS.h"
#include <math.h>
#include <unistd.h>
static SysC8 *WDir;

static SysF64 SysStartSec = 0;

SysU32 SysAudioFreq = SYSAUDIO_DEFAULT_FREQ,
       SysAudioFlags = SYSAUDIO_DEFAULT_STEREO | SYSAUDIO_DEFAULT_FMT;
static SysS32 GLRGBAZD[6];
static SysS32 SYS_SCREEN_W = 1024, SYS_SCREEN_H = 768;

static SDL_AudioSpec AudioFmt;
static SDL_Window *SysMainWindow;
static SDL_GLContext SysMainContext;

SysS64 KeyTranslate(SysU64 Scancode) {
  switch (Scancode) {
  case SDL_SCANCODE_CAPSLOCK:
    return SYS_CAPSLOCK;
  case SDL_SCANCODE_RSHIFT:
    return SYS_RSHIFT;
  case SDL_SCANCODE_LSHIFT:
    return SYS_LSHIFT;
  case SDL_SCANCODE_RCTRL:
    return SYS_RCTRL;
  case SDL_SCANCODE_LCTRL:
    return SYS_LCTRL;
  case SDL_SCANCODE_RALT:
    return SYS_RALT;
  case SDL_SCANCODE_LALT:
    return SYS_LALT;
  case SDL_SCANCODE_LGUI:
    return SYS_LSUPER;
  case SDL_SCANCODE_RGUI:
    return SYS_RSUPER;
  case SDL_SCANCODE_MODE:
    return SYS_MODE;
  case SDL_SCANCODE_UP:
    return SYS_UP;
  case SDL_SCANCODE_DOWN:
    return SYS_DOWN;
  case SDL_SCANCODE_RIGHT:
    return SYS_RIGHT;
  case SDL_SCANCODE_LEFT:
    return SYS_LEFT;
  case SDL_SCANCODE_INSERT:
    return SYS_INSERT;
  case SDL_SCANCODE_HOME:
    return SYS_HOME;
  case SDL_SCANCODE_END:
    return SYS_END;
  case SDL_SCANCODE_PAGEUP:
    return SYS_PAGEUP;
  case SDL_SCANCODE_PAGEDOWN:
    return SYS_PAGEDOWN;
  case SDL_SCANCODE_BACKSPACE:
    return SYS_BACKSPACE;
  case SDL_SCANCODE_TAB:
    return SYS_TAB;
  case SDL_SCANCODE_CLEAR:
    return SYS_CLEAR;
  case SDL_SCANCODE_RETURN:
    return SYS_RETURN;
  case SDL_SCANCODE_PAUSE:
    return SYS_PAUSE;
  case SDL_SCANCODE_ESCAPE:
    return SYS_ESCAPE;
  case SDL_SCANCODE_DELETE:
    return SYS_DELETE;
  case SDL_SCANCODE_F1:
    return SYS_F1;
  case SDL_SCANCODE_F2:
    return SYS_F2;
  case SDL_SCANCODE_F3:
    return SYS_F3;
  case SDL_SCANCODE_F4:
    return SYS_F4;
  case SDL_SCANCODE_F5:
    return SYS_F5;
  case SDL_SCANCODE_F6:
    return SYS_F6;
  case SDL_SCANCODE_F7:
    return SYS_F7;
  case SDL_SCANCODE_F8:
    return SYS_F8;
  case SDL_SCANCODE_F9:
    return SYS_F9;
  case SDL_SCANCODE_F10:
    return SYS_F10;
  case SDL_SCANCODE_F11:
    return SYS_F11;
  case SDL_SCANCODE_F12:
    return SYS_F12;
  };
  return -1;
}

static void XTEA(unsigned int num_rounds, uint32_t v[2],
                 uint32_t const key[4]) {
  unsigned int i;
  uint32_t v0 = v[0], v1 = v[1], sum = 0, delta = 0x9E3779B9;
  for (i = 0; i < num_rounds; i++) {
    v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]);
    sum += delta;
    v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum >> 11) & 3]);
  }
  v[0] = v0;
  v[1] = v1;
}

SysU64 SysPRNG(SysU64 Seed01, SysU64 Seed23, SysU64 Index, SysS32 Rounds) {
  SysU32 k[4] = {Seed01, Seed01 >> 32, Seed23, Seed23 >> 32};
  SysU32 v[2] = {Index, Index >> 32};

  XTEA(Rounds, v, k);
  SysU64 r;
  r = v[1];
  r <<= 32;
  r |= v[0];
  return r;
}

SysU64 SYSRNGSeed[2] = {0, 0};
SysU64 SysRNG(void) {
  static SysU64 v = 0;
  SYSRNGSeed[0] += SDL_GetPerformanceCounter();
  v = SysPRNG(SYSRNGSeed[0], SYSRNGSeed[1], v, 8);
  SYSRNGSeed[0] ^= v;
  SYSRNGSeed[1] += SYSRNGSeed[0];
  return SYSRNGSeed[0] ^ SYSRNGSeed[1];
}

static void UDPOpen(void) {}

SysU32 SysUDPBroadcastIP(void) { return 0; }

SysU32 SysUDPIP(SysC8 *IPDNSString) { return 0; }

SysU32 SysUDPSend(SysU32 IPAddress, SysU16 Port, void *Packet,
                  SysU32 PacketByteSize) {
  return 0;
}

SysU32 SysUDPBind(SysU32 IPAddress, SysU16 Port) { return 0; }

SysU32 SysUDPRecieve(SysU32 *IPAddress, SysU16 *Port, void *Packet,
                     SysU32 PacketByteSize, SysU32 *BytesRecieved) {
  return 0;
}

static void UDPClose(void) {}

SysF32 SysAspectRatio(SysU32 *Width, SysU32 *Height) {
  SDL_GL_GetDrawableSize(SysMainWindow, &SYS_SCREEN_W, &SYS_SCREEN_H);
  if (Width)
    *Width = SYS_SCREEN_W;
  if (Height)
    *Height = SYS_SCREEN_H;
  return (SysF32)SYS_SCREEN_W / (SysF32)SYS_SCREEN_H;
}

static SysS32 FlipAxis(SysS32 x) {
  x -= 0x4000;
  x = -x;
  x += 0x4000;
  return x;
}

static SysU32 SysPause = 0, SysActive = 0;
SysS32 SysPoll(void) {
  SysRNG();

  SysS32 QuitHit = 0;

  int x, y;

  SDL_Event event;
  while (SDL_PollEvent(&event)) {

    SysODS("Event: RNG:0x%llx\n", SysRNG());

    switch (event.window.event) {
    case SDL_WINDOWEVENT_FOCUS_GAINED:
      SDL_PauseAudio(0);
      SysActive |= (1 << 1);
      break;
    case SDL_WINDOWEVENT_FOCUS_LOST:
      SDL_PauseAudio(1);
      SysActive |= (1 << 0);
      break;
    }

    SDL_MouseMotionEvent *pm = (SDL_MouseMotionEvent *)&event;
    SDL_MouseButtonEvent *pb = (SDL_MouseButtonEvent *)&event;
    SDL_MouseWheelEvent *pw = (SDL_MouseWheelEvent *)&event;
    SDL_KeyboardEvent *pk = (SDL_KeyboardEvent *)&event;
    SDL_TouchFingerEvent *pt = (SDL_TouchFingerEvent *)&event;
    /*
    typedef struct SYSINPUT {
      SysU64 ID[2], B, M;
      SysF64 X, Y, WX, WY, DX, DY, P, R;
      SysF64 TimeStamp;
    } SYSINPUT;*/
    SYSINPUT Inp;
    SysS64 k, s, idk;

    switch (event.type) {
    case SDL_FINGERDOWN:
      Inp = (SYSINPUT){{SYSINPUT_TOUCHON, pt->fingerId},
                       0,
                       0,
                       0,
                       0,
                       pt->x,
                       pt->y,
                       pt->dx,
                       pt->dy,
                       pt->pressure,
                       0,
                       SysSec()};
      SysUserInput(Inp);
      break;
    case SDL_FINGERUP:
      Inp = (SYSINPUT){{SYSINPUT_TOUCHOFF, pt->fingerId},
                       0,
                       0,
                       0,
                       0,
                       pt->x,
                       pt->y,
                       pt->dx,
                       pt->dy,
                       pt->pressure,
                       0,
                       SysSec()};
      SysUserInput(Inp);
      break;
    case SDL_FINGERMOTION:
      Inp = (SYSINPUT){{SYSINPUT_TOUCHMOVE, pt->fingerId},
                       0,
                       0,
                       0,
                       0,
                       pt->x,
                       pt->y,
                       pt->dx,
                       pt->dy,
                       pt->pressure,
                       0,
                       SysSec()};
      SysUserInput(Inp);
      break;
    case SDL_KEYDOWN:
    case SDL_KEYUP:
      s = pk->keysym.scancode;
      k = pk->keysym.sym;
      if ((k < 32) || (k >= 128)) {
        k = KeyTranslate(s);
        SysODS("[Key Translate S:%d 0x%x K:%d 0x%x]\n", s, s, k, k);
        if (k < 0) {
          break;
        }
      }
      SysAssert(k < SYS_KEYS_MAX);
      if (event.type == SDL_KEYDOWN)
        idk = SYSINPUT_KEYON;
      else if (event.type == SDL_KEYUP)
        idk = SYSINPUT_KEYOFF;
      Inp = (SYSINPUT){{idk, 0}, k, 0, 0, 0, 0, 0, 0, 0, 0, 0, SysSec()};
      SysUserInput(Inp);
      break;

    case SDL_MOUSEBUTTONDOWN:
      Inp = (SYSINPUT){{SYSINPUT_MOUSEON, pb->which},
                       pb->button,
                       0,
                       0,
                       0,
                       pb->x,
                       pb->y,
                       0,
                       0,
                       0,
                       0,
                       SysSec()};
      SysUserInput(Inp);
      break;
    case SDL_MOUSEBUTTONUP:
      Inp = (SYSINPUT){{SYSINPUT_MOUSEOFF, pb->which},
                       pb->button,
                       pb->clicks,
                       0,
                       0,
                       pb->x,
                       pb->y,
                       0,
                       0,
                       0,
                       0,
                       SysSec()};
      SysUserInput(Inp);
      break;
    case SDL_MOUSEMOTION:
      Inp = (SYSINPUT){{SYSINPUT_MOUSEMOVE, pm->which},
                       pm->state,
                       0,
                       0,
                       0,
                       pm->x,
                       pm->y,
                       pm->xrel,
                       pm->yrel,
                       0,
                       0,
                       SysSec()};
      SysUserInput(Inp);
      break;
    case SDL_MOUSEWHEEL:
      Inp = (SYSINPUT){{SYSINPUT_MOUSEWHEEL, pw->which},
                       0,
                       0,
                       pw->x,
                       pw->y,
                       (pw->direction == SDL_MOUSEWHEEL_NORMAL) ? 1 : -1,
                       (pw->direction == SDL_MOUSEWHEEL_NORMAL) ? 1 : -1,
                       pw->preciseX,
                       pw->preciseY,
                       0,
                       0,
                       SysSec()};
      SysUserInput(Inp);
      break;
    case SDL_QUIT:
      QuitHit = 1;
      break;
    }
  }

  const SysU8 *SysKeyState = SDL_GetKeyboardState(NULL);
  QuitHit |= SysKeyState[SDL_SCANCODE_ESCAPE];
  if (SysPause == 0)
    if (SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 1;
  if (SysPause == 1)
    if (!SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 4 | 1;
  if (SysPause == (4 | 1))
    if (SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 2;
  if (SysPause == 2)
    if (!SysKeyState[SDL_SCANCODE_TAB])
      SysPause = 4 | 2;

  return QuitHit;
}

void SysWindowTitle(SysC8 *s) { SDL_SetWindowTitle(SysMainWindow, s); }

SysS32 SysSwap(void) {
  // SDL_GL_SwapBuffers( );
  SDL_GL_SwapWindow(SysMainWindow);
  return SysPoll();
}

void SysAudioCallBack(void *UserData, SysU8 *Stream, SysS32 Len) {
  SysUserAudio(SysAudioFlags, SysAudioFreq, Stream, Len);
}

void DisplayTimeSec(SysF64 t) {
  SysU32 s = fmod(t, 60);
  t /= 60;
  SysU32 m = fmod(t, 60);
  t /= 60;
  SysU32 h = fmod(t, 24);
  t /= 24;
  SysU32 d = t;
  SysODS("%d:%d:%d:%d", d, h, m, s);
}

static SysS32 SysOpened = 0;

void SysSDLExit(const char *msg) {
  printf("%s: %s\n", msg, SDL_GetError());
  SDL_Quit();
  exit(1);
}

void SysCheckSDLError(int line) {
  const char *error = SDL_GetError();
  if (*error != '\0') {
    printf("SDL Error: %s\n", error);
    if (line != -1)
      printf(" + line: %i\n", line);
    SDL_ClearError();
  }
}
static Mix_Music *Music = 0;
SysS32 SysMusicOn(SysC8 *FileName, SysF32 FadeInS, SysS32 Loops) {
  if (Music)
    return 0;
  Mix_HaltMusic();
  Music = Mix_LoadMUS(FileName);
  SysAssert(Music);
  Mix_PlayMusic(Music, Loops);
  Mix_FadeInMusic(Music, Loops, FadeInS * 1000);
  SysODS("Music Playing %s \n", FileName);
  SysMusicResume();
  return 0;
}

SysS32 SysMusicVolume(SysF32 Volume) {
  if (!Music)
    return 0;
  Mix_VolumeMusic(128 * Volume);
  return 0;
}

SysS32 SysMusicPause(void) {
  if (!Music)
    return 0;
  Mix_PauseMusic();
  return 0;
}

SysS32 SysMusicResume(void) {
  if (!Music)
    return 0;
  Mix_ResumeMusic();
  return 0;
}

SysS32 SysMusicOff(SysF32 FadeOut) {
  if (!Music)
    return 0;
  Mix_FadeOutMusic(FadeOut * 1000);
  Music = 0;
  return 0;
}

void SysAudioMixerCallBack(SysS32 Channel, void *Stream, SysS32 Len,
                           void *UserData) {
  static SysU64 f = 0;
  if (!f) {
    SysODS("Audio Callback: Frame Length %d Bytes  %f Frames/s\n", Len,
           SysAudioFreq / (Len / 4.0f));
    f = 1;
  }
  SysUserAudio(SysAudioFlags, SysAudioFreq, Stream, Len);
}

SysS32 SysOpen(SysS32 Flags) {
  SysStartSec = SysSec();
  SysODS("C Version:%d\n", __STDC_VERSION__);
  WDir = SDL_GetBasePath();
  SysODS("SDL Opening...%s\n", WDir);
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) <
      0) /* Initialize SDL's Video subsystem */
    SysSDLExit("Unable to initialize SDL"); /* Or die on error */

  int novd = SDL_GetNumVideoDrivers();

  SysODS("\n\nVideo Drivers:\n");
  for (int i = 0; i < novd; i++)
    SysODS("%d: %s\n", i, SDL_GetVideoDriver(i));
  SysODS("\n");
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);

  /* Create our window centered at 512x512 resolution */
#ifdef __EMSCRIPTEN__
  SysMainWindow = SDL_CreateWindow(
      "Q3D", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SYS_SCREEN_W,
      SYS_SCREEN_H, SDL_WINDOW_OPENGL | SDL_WINDOW_FULLSCREEN);
#else
  SysMainWindow = SDL_CreateWindow(
      "Q3D", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SYS_SCREEN_W,
      SYS_SCREEN_H,
      SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN);
#endif

  if (!SysMainWindow) /* Die if creation failed */
    SysSDLExit("Unable to create window");

  // #ifdef __EMSCRIPTEN__
  //   SDL_SetWindowFullscreen(SysMainWindow, SDL_WINDOW_FULLSCREEN_DESKTOP);
  // #endif

  // SDL_DisplayMode mode;
  SDL_GetWindowSize(SysMainWindow, &SYS_SCREEN_W, &SYS_SCREEN_H);
  SysODS("SysOpen: Window Screen Width:%d Window Screen Height:%d\n",
         SYS_SCREEN_W, SYS_SCREEN_H);
  SDL_GL_GetDrawableSize(SysMainWindow, &SYS_SCREEN_W, &SYS_SCREEN_H);
  SysODS("SysOpen:GL Drawable Screen Width:%d GL Drawable Screen Height:%d\n",
         SYS_SCREEN_W, SYS_SCREEN_H);
  // SYS_SCREEN_W = mode.w;
  // SYS_SCREEN_H = mode.h;

  SysCheckSDLError(__LINE__);

  /* Create our opengl context and attach it to our window */
  SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 0);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
  SysMainContext = SDL_GL_CreateContext(SysMainWindow);
  SysCheckSDLError(__LINE__);

  /* This makes our buffer swap syncronized with the monitor's vertical refresh
   */
  SDL_GL_SetSwapInterval(1);

  SDL_GL_GetAttribute(SDL_GL_RED_SIZE, &GLRGBAZD[0]);
  SDL_GL_GetAttribute(SDL_GL_GREEN_SIZE, &GLRGBAZD[1]);
  SDL_GL_GetAttribute(SDL_GL_BLUE_SIZE, &GLRGBAZD[2]);
  SDL_GL_GetAttribute(SDL_GL_ALPHA_SIZE, &GLRGBAZD[3]);
  SDL_GL_GetAttribute(SDL_GL_DEPTH_SIZE, &GLRGBAZD[4]);
  SDL_GL_GetAttribute(SDL_GL_DOUBLEBUFFER, &GLRGBAZD[5]);
  SysODS("Video Mode Set: W:%d H:%d RGBA:%d%d%d%d Z:%d DoubleBuffer:%d\n",
         SYS_SCREEN_W, SYS_SCREEN_H, GLRGBAZD[0], GLRGBAZD[1], GLRGBAZD[2],
         GLRGBAZD[3], GLRGBAZD[4], GLRGBAZD[5]);
  /*
    SDL_memset(&AudioFmt, 0, sizeof(AudioFmt));
    AudioFmt.freq = SysAudioFreq;
    AudioFmt.format = AUDIO_S16LSB;
    AudioFmt.channels = (SysAudioFlags & SYSAUDIO_STEREO) ? 2 : 1;
    AudioFmt.samples = SysAudioFreq / 30;
    AudioFmt.callback = SysAudioCallBack;
    AudioFmt.userdata = NULL;
    if (SDL_OpenAudio(&AudioFmt, NULL) != 0) {
      printf("Audio Error!\n");
      exit(1);
    }
    SysODS("Audio:%dHz %x %x %x\n", SysAudioFreq, AUDIO_S16LSB,
    SYSAUDIO_STEREO);
  */
  int Stereo = (SysAudioFlags & SYSAUDIO_DEFAULT_STEREO) ? 2 : 1, FrameSize;
  int BitFmt = ((SysAudioFlags & 0xff) == 16) ? AUDIO_S16LSB : 0;

  FrameSize = SysAudioFreq / 30;
  if (FrameSize < 128)
    FrameSize = 128;
  if (Mix_OpenAudio(SysAudioFreq, BitFmt, Stereo, FrameSize) == -1) {
    SysODS("Mix_OpenAudio: %s\n", Mix_GetError());
    SysSDLExit("Mix Audio Error");
    exit(2);
  }
  int numtimesopened, frequency, channels;
  Uint16 format;
  numtimesopened = Mix_QuerySpec(&frequency, &format, &channels);
  if (!numtimesopened) {
    SysODS("Mix_QuerySpec: %s\n", Mix_GetError());
    SysSDLExit("Mix Audio Query Error!");
    exit(2);
  } else {
    SysAssert(format == AUDIO_S16LSB);
    SysAssert(channels == Stereo);
    char *format_str = "Unknown";
    switch (format) {
    case AUDIO_U8:
      format_str = "U8";
      break;
    case AUDIO_S8:
      format_str = "S8";
      break;
    case AUDIO_U16LSB:
      format_str = "U16LSB";
      break;
    case AUDIO_S16LSB:
      format_str = "S16LSB";
      break;
    case AUDIO_U16MSB:
      format_str = "U16MSB";
      break;
    case AUDIO_S16MSB:
      format_str = "S16MSB";
      break;
    }
    SysODS("SDL Mixer: Opened=%d  Freq=%dHz  Fmt=%s  Channels=%d\n",
           numtimesopened, frequency, format_str, channels);
    SysAudioFreq = frequency;
  }
  int t = Mix_AllocateChannels(1);
  SysODS("SDL Mixer:%d Mixing Channel(s)\n", t);
  static SysU8 AudioMem[4 * 2 * 2 * 1024];
  // for(int i=0;i<sizeof(AudioMem);i++) AudioMem[i]=SysRNG()&0xff;
  static Mix_Chunk MixChunk = {0, AudioMem, sizeof(AudioMem), 128};
  int c = Mix_PlayChannel(-1, &MixChunk, -1);
  SysODS("Mixing on channel:%d\n", c);
  Mix_RegisterEffect(c, SysAudioMixerCallBack, 0, 0);

  UDPOpen();
  SysODS("Performance Counter:%d Frequency:%d(%f)\n",
         SDL_GetPerformanceCounter(), SDL_GetPerformanceFrequency(),
         SDL_GetPerformanceFrequency() / 1000000000.0f);
  SysODS("SysOpen RealTime:");
  DisplayTimeSec(SysSec());
  SysODS(" Monotonic:");
  DisplayTimeSec(SysSec());
  SysODS("\n");
  SysOpened = 1;
  return 0;
}

SysS32 SysClose(SysS32 Flags) {
  SysAssert(SysOpened);
  Mix_CloseAudio();
  UDPClose();
  SDL_GL_DeleteContext(SysMainContext);
  SDL_DestroyWindow(SysMainWindow);
  SDL_Quit();
  SysOpened = 0;
  return 0;
}

SysU32 SysState(SysS32 Cmd, void *Arg) {
  switch (Cmd) {
  case SYSSTATE_AUDIOOFF:
    SDL_PauseAudio(1);
    break;
  case SYSSTATE_AUDIOON:
    SDL_PauseAudio(0);
    break;
  case SYSSTATE_UDPON:
    break;
  }
  return 0;
}

#define SYSIO
SysS32 SysLoad(SysU32 Flags, const SysC8 *OFileName, SysU32 Offset, SysU32 Size,
               void *Buffer) {
#ifdef SYSIO

  FILE *f;
  SysS32 l;
  SysODS("Attempting to load %s... ", OFileName);
  SysC8 FileName[256];
#ifdef SYSLSDIR
  if (Flags == SYSLOADSAVE_USERDIR) {
    strcpy(FileName, "../");
    strcat(FileName, OFileName);
  } else
#endif
    strcpy(FileName, OFileName);

  f = fopen(FileName, "rb");
  if (f == NULL) {
    SysODS("Failed to open file %s!\n", FileName);
    return 0;
  }
  if (Size && Buffer) {
    fseek(f, Offset, SEEK_SET);
    l = fread(Buffer, 1, Size, f);
  } else {
    fseek(f, 0, SEEK_END);
    l = ftell(f);
  }
  fclose(f);
  SysODS("File %s successfully closed!\n", FileName);
  return l;
#else
  return 0;
#endif
}

SysS32 SysSave(SysU32 Flags, const SysC8 *OFileName, SysU32 Size,
               void *Buffer) {
#ifdef SYSIO
  SysC8 FileName[256];
#ifdef SYSLSDIR
  if (Flags == SYSLOADSAVE_USERDIR) {
    strcpy(FileName, "../");
    strcat(FileName, OFileName);
  } else if (!l)
    return;

#endif
  strcpy(FileName, OFileName);
  FILE *f = fopen(FileName, "wb");
  SysAssert(f);
  if (Size)
    fwrite(Buffer, sizeof(char), Size, f);
  fclose(f);
#endif
  return 0;
}

SysF64 SysSec(void) {
  SysF64 cf = (SysF64)(SDL_GetPerformanceCounter()) /
              (SysF64)(SDL_GetPerformanceFrequency());
  return cf - SysStartSec;
}

static SysS32 SysR = 0;
void SysLoop(void) {
  SysU32 s = 0;
  if (SysPause == (4 | 2)) {
    SDL_PauseAudio(0);
    s = SYSFRAME_RESUME;
    SysPause = 0;
  } else if (SysPause) {
    s = SYSFRAME_PAUSE;
    SDL_PauseAudio(1);
  }
  if (SysActive == 1)
    s = SYSFRAME_PAUSE;
  else if (SysActive) {
    s = SYSFRAME_RESUME;
    SysActive = 0;
  }
  SysR = SysUserFrame(s);
  if (SysSwap())
    SysR = SYSFRAME_QUIT;
}

int main(int argc, char *argv[]) {
  SysR = 0;
  SysOpen(0);
#ifdef __EMSCRIPTEN__
  emscripten_set_main_loop(SysLoop, 0, 1);
#else
  while (SysR != SYSFRAME_QUIT)
    SysLoop();
#endif
  SysClose(0);
  SysODS("Sys Finished\n");
  return 0;
}

/*
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

#undef malloc
#undef free

#ifdef SYS_MAX_MEMORY
#define MAX_MEMORY SYS_MAX_MEMORY
#else
#define MAX_MEMORY SYSMEM_DEFAULT
#endif

static SysU8 Mem[MAX_MEMORY];
static SysU64 MemOffset = 0;

typedef struct SysAllocS {
  void *prev;
  SysU64 size;
  SysU8 data[];
} SysAllocS;

typedef struct SysAllocInfoS {
  SysAllocS *curr;
  SysS64 count, maxcount, size, maxsize;

} SysAllocInfoS;

static SysAllocInfoS SysAllocInfo = {0, 0, 0, 0, 0};

void *SysDbgAlloc(SysU32 Bytes, const SysC8 *File, SysU32 Line) {
  SysAssert(Bytes);
  SysAllocS *m = (SysAllocS *)&Mem[MemOffset];
  MemOffset += (Bytes + sizeof(SysAllocS));
  SysAssert(MemOffset < MAX_MEMORY);
  m->prev = SysAllocInfo.curr;
  m->size = Bytes;
  SysAllocInfo.curr = m;
  SysAllocInfo.count++;
  if (SysAllocInfo.count > SysAllocInfo.maxcount)
    SysAllocInfo.maxcount = SysAllocInfo.count;
  SysAllocInfo.size += Bytes;
  if (SysAllocInfo.size > SysAllocInfo.maxsize)
    SysAllocInfo.maxsize = SysAllocInfo.size;
  SysLog(1,"SysAlloc: [%s:%d] Curr:%llx Bytes:%d Count:%d MaxCount:%d Size:%d "
         "MaxSize:%d\n",
         File, Line, SysAllocInfo.curr, Bytes, SysAllocInfo.count,
         SysAllocInfo.maxcount, SysAllocInfo.size, SysAllocInfo.maxsize);
  return &((SysU8 *)m)[sizeof(SysAllocS)];
}

void SysDbgFree(void *Mem, const SysC8 *File, SysU32 Line) {
  if (!Mem)
    return;
  SysAssert(SysAllocInfo.curr);
  SysAllocS *m = (SysAllocS *)(&((SysU8 *)Mem)[-sizeof(SysAllocS)]);
  SysAssert(SysAllocInfo.curr == m);
  SysAllocInfo.curr = (SysAllocS *)(m->prev);
  SysAllocInfo.count--;
  SysAllocInfo.size -= m->size;
  SysLog(1,"SysFree: [%s:%d] Curr:%llx Bytes:%d Count:%d MaxCount:%d Size:%d "
         "MaxSize:%d\n",
         File, Line, SysAllocInfo.curr, m->size, SysAllocInfo.count,
         SysAllocInfo.maxcount, SysAllocInfo.size, SysAllocInfo.maxsize);
  MemOffset -= (m->size + sizeof(SysAllocS));
}

static char *LogName[]={
  "./Logs/SYSODS.Log",
  "./Logs/SYSMem.Log",
  "./Logs/SYSAudio.Log"
};
static FILE *Log[SYS_LOG_MAX_ID] = {[0 ... SYS_LOG_MAX_ID - 1] = 0};
void SysLog(SysU64 LogID, const SysC8 *DebugString, ...) {
#ifndef SYS_DEBUG_ODS
  return;
#endif
  SysAssert(LogID< SYS_LOG_MAX_ID);
  if (!Log[LogID]) {
      char w[64],*f;
    if(LogID< SYS_LOG_USER_0)
      f=LogName[LogID];
    else
    {
      sprintf(w,"./Logs/SYSUser%x.Log",(int)LogID-SYS_LOG_USER_0);
      f=w;
    }
    //printf("%s\n",f);fflush(stdout);
    Log[LogID] = fopen(f, "w");
    SysAssert(Log[LogID]);
  }
  va_list args;
  va_start(args, DebugString);
  fprintf(Log[LogID],"%f:  ", SysSec());
  vfprintf(Log[LogID], DebugString, args);
  va_end(args);
  fflush(Log[LogID]);
}

#ifdef SYS_DEBUG_ODS
#include <stdlib.h>
void SysKill(SysS32 C) { exit(C); }

#else
#endif
