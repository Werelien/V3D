
/*
RXMI Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#define PROJ_DEBUG
#include "RXMI.h"
#include "SYS.h"
#ifdef PROJ_DEBUG
#include <assert.h>
#include <stdio.h>
#define RXAssert assert
#ifndef RXMI_LOG
#define RXMI_LOG -1
#endif
#define RXLog(...) SysLog(RXMI_LOG, __VA_ARGS__)
#else
#define RXAssert(exp)
#define RXLog(...)
#endif
#include <memory.h>

#include "math.h"
#include "stdio.h"
typedef U8 RFXSEQPKT[4];
S32 RFXSeq(RFXSEQPKT pkt);

F64 RXMI_MIDINoteToHz(F64 MIDINote) {
  MIDINote = MIDINote < 0 ? 0 : MIDINote;
  MIDINote = MIDINote > 127 ? 127 : MIDINote;
  return 440.0 * pow(2, (MIDINote - 69.0) / 12.0);
}
RXMISTATUS RXMI = {0};
C8 RXMIDisplay[RXMI_MAX_LINES][RXMI_MAX_CHARS];

enum { RXMI_MAXLAYOUTS = 4 };
static const char *RXMI_LAYOUT[RXMI_MAXLAYOUTS] = {"WH", "WH90", "WH270",
                                                   "DIA"};

const char *RXMINote[12] = {"C-", "C#", "D-", "D#", "E-", "F-",
                            "F#", "G-", "G#", "A-", "A#", "B-"};
S32 RXMI_Translate[256];
void RXMINormalise(void) {

  if (RXMI.NoteOffset < 0) {
    RXMI.NoteOffset = 11;
    RXMI.Octave--;
  }
  if (RXMI.NoteOffset > 11) {
    RXMI.NoteOffset = 0;
    RXMI.Octave++;
  }
  if (RXMI.Octave < 0) {
    RXMI.Octave = 10;
  }
  if (RXMI.Octave > 10) {
    RXMI.Octave = 0;
  }
  if (RXMI.Velocity < 0)
    RXMI.Velocity = 0;
  if (RXMI.Velocity > 1)
    RXMI.Velocity = 1;
  /*
  if (RXMI.PitchBend < -1)
    RXMI.PitchBend = -1;
  if (RXMI.PitchBend > 1)
    RXMI.PitchBend = 1;
    */
  if (RXMI.NotesOn <= 0) {
    RXMI.NotesOn = 0;
    RXMI.PitchBend = 0;
  }
  RXMI.Layout %= RXMI_MAXLAYOUTS;
  RXMI.Instrument &= 127;
  RXMI.Channel &= 15;
}

S32 RXMIDisplayKeyboard(void) {
  RXAssert(RXMI.Flags);
  static RXMISTATUS lrxmi = {0};
  if ((RXMI.Octave == lrxmi.Octave) && (RXMI.NoteOffset == lrxmi.NoteOffset) &&
      (RXMI.Layout == lrxmi.Layout))
    return 4;
  lrxmi = RXMI;
  static int changes = 0;
  const char *kb[RXMI_MAXLAYOUTS][4] = {
      //
      {                                                            //
       "`15 117 219 321 423 525 627 729 831 933 035 -37 =39 B41",  //
       " T10 q12 w14 e16 r18 t20 y22 u24 i26 o28 p30 [32 ]34 E36", //
       "  C05 a07 s09 d11 f13 g15 h17 j19 k21 l23 ;25 '27 #29",    //
       "   \\00 z02 x04 c06 v08 b10 n12 m14 ,16 .18 /20"},         //
      {                                                            //
       "`85 178 273 366 461 554 649 742 837 930 025 -18 =13 B06",  //
       " T76 q71 w64 e59 r52 t47 y40 u35 i28 o23 p16 [11 ]04 E-1", //
       "  C69 a62 s57 d50 f45 g38 h33 j26 k21 l14 ;09 '02 #-3",    //
       "   \\60 z55 x48 c43 v36 b31 n24 m19 ,12 .07 /00"},         //
      {                                                            //
       "`00 107 212 319 424 531 636 743 848 955 060 -67 =72 B79",  //
       " T02 q09 w14 e21 r26 t33 y38 u45 i50 o57 p62 [69 ]74 E81", //
       "  C04 a11 s16 d23 f28 g35 h40 j47 k52 l59 ;64 '71 #76",    //
       "   \\06 z13 x18 c25 v30 b37 n42 m49 ,54 .61 /66"},         //
      {                                                            //
       "`10 111 213 315 417 518 620 722 823 925 027 -29 =30 B32",  //
       " T11 q12 w14 e16 r17 t19 y21 u23 i24 o26 p28 [29 ]31 E33", //
       "  C00 a01 s03 d05 f06 g08 h10 j11 k13 l15 ;17 '18 #20",    //
       "   \\00 z02 x04 c05 v07 b09 n11 m12 ,14 .16 /17"},         //
  };
  for (int i = 0; i < 256; i++)
    RXMI_Translate[i] = -1;
  for (int i = 0; i < 4; i++) {
    const char *s = kb[RXMI.Layout][i];
    char *d = RXMIDisplay[i];
    int n = 0, od = 0, j = 0;
    while (s[j]) {
      while (s[j] == ' ') {
        od += sprintf(&d[od], "  ");
        j++;
      }
      RXAssert(s[j]);
      int oc = s[j++];
      int hc = s[j++], lc = s[j++], n = lc - '0';
      RXAssert(((hc >= '0') && (hc <= '9')) || (hc == '-'));
      RXAssert((lc >= '0') && (lc <= '9'));
      if (hc == '-')
        n = -n;
      else
        n += (hc - '0') * 10;
      RXMI_Translate[oc] = n;
      // RXAssert(n >= 0);
      RXAssert(n < 100);
      n += RXMI.Octave * 12 + RXMI.NoteOffset;
      int ocn = n / 12 - 1;
      int ncn = n % 12;
      od += sprintf(&d[od], "[%c:%s%d]", oc, RXMINote[ncn], ocn);
    }
    od += sprintf(&d[od], "%c\n", (changes & 7) + '0');
    RXAssert(od < 256); //
  }
  changes++;
  return 4;
}

void RXMIDisplayStatus(void) {
  RXAssert(RXMI.Flags);
  int l = RXMIDisplayKeyboard();
  RXAssert(l < RXMI_MAX_LINES);
  char *d = RXMIDisplay[l];
  sprintf(d,
          "RXMI Status: Flgs:%x Lay:%s Ins:%3d Ch:%3d KeyOct:%2d "
          "KeyNt:%2d"
          "NotesOn:%d "
          "Press:%d Vel:%3.2f Bend:%3.2f U:%d D:%d L:%d R:%d",
          RXMI.Flags, RXMI_LAYOUT[RXMI.Layout], RXMI.Instrument, RXMI.Channel,
          RXMI.Octave, RXMI.NoteOffset, RXMI.NotesOn, RXMI.KeysPressed,
          RXMI.Velocity, RXMI.PitchBend, RXMI.U, RXMI.D, RXMI.L, RXMI.R);
  for (int i = 0; i < RXMI_MAX_LINES; i++) {
    RXLog("%s\n", RXMIDisplay[i]);
  }
}

void RXMI_Close(void) {}
static void FXNoteOn(RXMINOTE r) {
  RXAssert(RXMI.Flags);
  if (r.Note < 0)
    return;
  RXMI.NotesOn++;
  RFXSEQPKT pkt = {(U8)(0x90 | RXMI.Channel), (U8)r.Note,
                   (U8)(127 * RXMI.Velocity)};
  RFXSeq(pkt);
}
static void NoteBend(F64 Bend) {
  RXAssert(RXMI.Flags);

  if (Bend > 1)
    Bend = 1;
  else if (Bend < -1)
    Bend = -1;
  U8 b = (Bend + 1) * 0.5f * ((1 << 14) - 1);
  U8 lsb = b & 0x7f, msb = (b >> 7) & 0x7f;
  RFXSEQPKT pkt = {0xe0, lsb, msb};
  RFXSeq(pkt);
  return;
}

static void FXNoteOff(RXMINOTE r) {
  RXAssert(RXMI.Flags);
  if (r.Note < 0)
    return;
  RFXSEQPKT pkt = {(U8)(0x80 | RXMI.Channel), (U8)r.Note, 0};
  RFXSeq(pkt);
  NoteBend(0);
  RXMI.NotesOn--;
  if (RXMI.NotesOn <= 0) {
    RXMI.PitchBend = 0;
    RXMI.NotesOn = 0;
  }
}
void RXMI_WHMidiBend(F64 Bend, F64 Range) {
  RXMI.PitchBend += Bend * RXMI.UpdateDT;
  if ((Bend < 0) && (RXMI.PitchBend < Range))
    RXMI.PitchBend = Range;
  if ((Bend > 0) && (RXMI.PitchBend > Range))
    RXMI.PitchBend = Range;
  NoteBend(RXMI.PitchBend);
}

void RXMI_WHMidiNoteUpdate(void) {
  RXAssert(RXMI.Flags);

  RXMI.LAlt = SysKey[SYS_LALT];
  RXMI.RAlt = SysKey[SYS_RALT];
  RXMI.LCtr = SysKey[SYS_LCTRL];
  RXMI.RCtr = SysKey[SYS_RCTRL];
  RXMI.LShf = SysKey[SYS_LSHIFT];
  RXMI.RShf = SysKey[SYS_RSHIFT];
  RXMI.Spc = SysKey[' '];
  RXMI.U = SysKey[SYS_UP];
  RXMI.D = SysKey[SYS_DOWN];
  RXMI.L = SysKey[SYS_LEFT];
  RXMI.R = SysKey[SYS_RIGHT];
  int altd = (RXMI.LAlt | RXMI.RAlt);
  int ctrd = (RXMI.LCtr | RXMI.RCtr);
  int shfd = (RXMI.LShf | RXMI.RShf);
  int chng = 0;

  char *s = "0123456789abcdefghijklmnopqrstuvwxyz\\,./;'#[]`-=CTEB";
  if (ctrd) {
    RXMI.Octave += SysKeyChange('U');
    RXMI.Octave -= SysKeyChange('D');
    RXMI.NoteOffset -= SysKeyChange('L');
    RXMI.NoteOffset += SysKeyChange('R');
  }
  if (altd)
    RXMI.Layout += SysKeyChange('l');
  for (int i = 0; s[i]; i++) {
    if (SysKey[s[i]] == SysLastKey[s[i]])
      continue;
    int o = (1 << 16);
    if ((s[i] >= 0) && (s[i] <= '9'))
      o = -'0';
    if ((s[i] >= 'a') && (s[i] <= 'f'))
      o = -'a' + 10;
    if (o < (1 << 16)) {
      if (SysKey[s[i]]) {
        if (shfd)
          RXMI.Channel = s[i] + o;
        if (ctrd)
          RXMI.Instrument = s[i] + o;
      }
    }
    S64 n = RXMI_Translate[s[i]];
    if (n >= 0) {
      n += RXMI.Octave * 12 + RXMI.NoteOffset;
      RXMINOTE Note = {.Note = -1, .Timestamp = SysSec()};
      Note.Note = n;
      Note.Frequency = RXMI_MIDINoteToHz(Note.Note);
      S64 ocn = n / 12;
      S64 ncn = n % 12;
      if (SysKey[s[i]])
        FXNoteOn(Note);
      else
        FXNoteOff(Note);
    }
  }
  return;
}

void RXMI_Update(F64 TimeS) {
  RXAssert(RXMI.Flags);
  RXMI.UpdateDT = TimeS - RXMI.UpdateT;
  RXMI.UpdateT = TimeS;
  int shfd = (RXMI.LShf | RXMI.RShf);
  int altd = (RXMI.LAlt | RXMI.RAlt);
  int ctrd = (RXMI.LCtr | RXMI.RCtr);
  RXMI_WHMidiNoteUpdate();
  RXMINormalise();
  if (RXMI.NotesOn) {
    F64 d = ((1 + shfd * 5) * 0.5f) * 7 * (1 + ((RXMI.L) | (RXMI.R)) * 0.5f);
    if (RXMI.L) {
      RXMI_WHMidiBend(-d, -(0.5f + shfd * (3.5f - 0.5f)));
    } else if (RXMI.R) {
      RXMI_WHMidiBend(d, 0.5f + shfd * (3.5f - 0.5f));
    } else if (RXMI.U) {
      RXMI_WHMidiBend(d, 1 + shfd * (6 - 1));
    } else if (RXMI.D) {
      RXMI_WHMidiBend(-d, -(1 + shfd * (6 - 1)));
    } else if (RXMI.PitchBend) {
      F64 dir;
      if (RXMI.PitchBend >= 0)
        dir = -1;
      else
        dir = 1;
      RXMI_WHMidiBend(dir * d, 0);
    }
  } else {
    RXMI.PitchBend = 0;
    F64 t = 0.02f * RXMI.UpdateDT / 60.0f;
    if (RXMI.U) {
      RXMI.Velocity += 0.02f;
    } else if (RXMI.D) {
      RXMI.Velocity -= 0.02f;
    }
    if (RXMI.L) {
      RXMI.Velocity -= 0.01f;
    } else if (RXMI.R) {
      RXMI.Velocity += 0.01f;
    }
  }
  if (RXMI.Velocity != RXMI.LastVelocity) {
    RXMI.LastVelocity = RXMI.Velocity;
  }
  RXMINormalise();
  static U32 f = 0, ln = 0;
  if ((!(f & 15)) || (ln != RXMI.KeysPressed))
    RXMIDisplayStatus();
  f++;
  ln = RXMI.KeysPressed;
}

#include <memory.h>
void RXMI_Open(void) {
  if (!RXMI.Flags) {
    memset(&RXMI, 0, sizeof(RXMI));
    RXMI.Octave = 5;
    RXMI.NoteOffset = 0;
    RXMI.Velocity = 1;
    RXMI.PitchBend = 0;
    RXMI.Flags |= 1;
    RXMIDisplayKeyboard();
  }
}

#include <alsa/asoundlib.h>
#include <unistd.h>
int RFXSeq(RFXSEQPKT pkt) {
  static snd_seq_event_t Event;
  static snd_seq_t *SeqH;
  static int MOPort;
  static snd_midi_event_t *EventParser;
  static snd_seq_event_t *MEvent;

  static int Status;
  static int init = 0;

  int res;

  if (!init) {
    init = 1;
    if ((Status = snd_seq_open(&SeqH, "default", SND_SEQ_OPEN_OUTPUT, 0)) < 0)
      return -1;
    snd_seq_set_client_name(SeqH, "RXMI");
    char portname[64] = "RXMI OUT";

    res = MOPort = snd_seq_create_simple_port(
        SeqH, portname, SND_SEQ_PORT_CAP_READ | SND_SEQ_PORT_CAP_SUBS_READ,
        SND_SEQ_PORT_TYPE_APPLICATION);

    if (res < 0) {
      RXAssert(0);
      Status = -1;
      snd_seq_close(SeqH);
      return -1;
    }
    res = snd_midi_event_new(3, &EventParser);
    if (res != 0) {
      RXAssert(0);
      Status = -1;

      snd_seq_close(SeqH);
      return -1;
    }
    snd_midi_event_init(EventParser);

    MEvent = &Event;
  }
  if (Status < 0) {
    RXAssert(0);
    return -1;
  }

  res = snd_midi_event_encode(EventParser, pkt, 3, MEvent);

  if (res < 0) {
    RXAssert(0);
  }

  snd_midi_event_reset_encode(EventParser);

  snd_seq_ev_set_subs(MEvent);
  snd_seq_ev_set_direct(MEvent);
  snd_seq_ev_set_source(MEvent, MOPort);

  snd_seq_event_output_direct(SeqH, MEvent);

  return 0;
}
