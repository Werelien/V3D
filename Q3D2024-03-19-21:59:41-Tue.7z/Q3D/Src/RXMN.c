/*
RXMN Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
const char *RXMN = // Reduced EXpressive Music Notation By G.S.2024
                   //  All numeric values are decimal floating point.
                   //  One or more spaces or \n is a seperator (where needed),
                   //  as well as used for readability. Registers are single
                   //  alphanumeric A-Za-z0-9=-_  in total 64 are usable, _ is
                   //  alway null (off). Commands are any characters in {} or
                   //  A-Z or a-z case sensitive. Sustain can be = hold  )bend
                   //  /slide ~vibrato   _ rest no sustain. [Begin measure(bar)
                   //  ]End Bar (Bars can be nested (stacked from time in bar
                   //  above) for arpeggios, chords or sub tracks  |continue to
                   //  next bar within begin end bars. Move down octave(s) , ;
                   //  1,2.  '` move up 1,2 octave(s), from key.
    //
    // Commands:
    //   Note n in bars offset n from key usually use 0-e with ,; '` from key.
    //   Ii Use Instrument 0-127 usually. I10 is usually percussion.
    //   Cc Channel c. Usually 0-15.
    //   #R ...# Define macro in R
    //   @R Play macro R
    //   AR Append macro R after every following note A_ turns off
    //   Bb Bend/Slide value semitones up or -ve down over sustained /(slide) or
    //       )(bend). Difference between slide and bend pre defined.
    //   Vv Velocity 1 full, behaviour of >1 and -ve user defined for example
    //       distortion over 1.
    //   &n  Chord, Add/subtract n to last played note as if key. A_ turn off.
    //   Tt Time t in seconds into playing track.
    //   Mv Time in seconds each Measure(bar) takes.
    //   Kn Key from (follows MIDI standard) note n.
    //   L  Last note, usually use with key for arps.
    //   ST (push) Save current time t in track.
    //   RT Restore (Pop) current time in track.
    //   Pv Pan value -1 - 1.
    //   Ot Offset t seconds, to adjust track time fractionally.
    //   {s d0 d1...} Raw user message eg for MIDI SysEx, Controller, ...
    //   t e Macros for numbers 10 and 11 used within bars for notes.
    //   l Last note played.

    "#V[Kl&7'&0 ;&0']#" // Macro 'V' for power chord  adds 0,7 & +-octaves to
                        // last note(s)   +_ later on stops it back to single
                        // notes
    "#A[Kl___4===7==='0===]#" // Macro 'A' power arp keyed to last note played.

    "M4 C7 I5 K45 T0 V.9"
    "[0=2=4=7=9=  '0@V_____ |,0= ,9=7=4=2=0@V=====]"
    "[0=3=5=7=t= '0=====| AV ,0= t= 7= 5= B.7 3/ A_ B2 0)))========]"
    // Measure(bar) each is 4 seconds, notes and sustains (ns) divide bar time
    // into all same 1/ns second long note length. [0--'0] notes and sustain
    // would play 1 second each over 4 second measure. Channel(Midi Channel 7)
    // Time set to 0 seconds to start  (PT can push time and RT restore it
    // between channels) P/T uses a LIFO stack.
    // Instrument 5
    // Key (Midi note 45)
    // Pentatonic major scale up single notes, ends on 1st measure on power
    // chord then descends similarly on 2nd measure.
    // Minore pentatonic version next 2 measures with bends at end of last
    // measure.
    // Strings of RXMN can be used flexibly for song writing within languages,
    // utilising functions to procedurally generate strings, append strings, ...
    // By using a fast compiler such as Tiny C Compiler or gcc with make -jn or
    // a scripting language with appropiate bindings such as Lua, editing whilst
    // playing on, for instance, fluid(Q)synth, checking result is fast.

    ;
