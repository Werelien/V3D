#!/bin/sh
rm Q3D
tcc -DSDL_DISABLE_IMMINTRIN_H -DSYS_RELEASE_ODS -DGFX_RELEASE_ODS  -Ofast -oQ3D GFX.c Implementation.c SFX.c SysSDL.c Q3D.c -lGL -lSDL2
ls -al Q3D
strip Q3D
echo "...Stripped..."
ls -al Q3D
