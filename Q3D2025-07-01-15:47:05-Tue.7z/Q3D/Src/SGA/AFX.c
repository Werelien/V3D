/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "AFX.h"
#include <math.h>

static SysU32 Active = 0;
SysU32 AFXActive(void) { return Active; }
static SysF64 MasterVol[2] = {1, 1};

SysU8 *MemCpy(SysU8 *d, const SysU8 *s, SysU32 l) {
  for (SysU32 i = 0; i < l; i++)
    d[i] = s[i];
  return d;
}

SysS32 MemRead(SysU8 *b, SysU32 l, const SysU8 *s, SysU32 sl, SysU32 *so) {
  if ((so[0] + l) > sl)
    l = sl - so[0];
  MemCpy(b, &s[so[0]], l);
  so[0] += l;
  return l;
}

SysS32 MemWrite(const SysU8 *b, SysU32 l, SysU8 *m, SysU32 ml, SysU32 *mo) {
  SysAssert((mo[0] + l) <= ml);
  MemCpy(&m[mo[0]], b, l);
  mo[0] += l;
  return l;
}

static struct AFXS {
  SysU32 Fmt;
  SysS32 AttackEnvelopeLen, ReleaseEnvelopeLen;
  void *Sam;
  const SysF64 *AttackEnvelope, *ReleaseEnvelope;
  SysF64 Freq, Vol[2], PlayForSecs, LenSecs, AttackSecs, ReleaseSecs;
  SysS64 End, LoopsCurrent, LoopRange, LoopRangeMask;
  SysF64 CurrentOffset;
} Ch[AFXMaxChannels];

SysS32 AFXFirstFreeChannel(SysU32 Mask) {
  SysU32 na = (~Active) & Mask;
  if (!na)
    return -1;

  SysU32 i = 0, a = Active | (~Mask);
  while (na) {
    if (na & 1)
      return i;
    na >>= 1;
    i++;
  }
  return -1;
}

SysS32 AFXSetCurrentOffset(SysS32 Channel, SysS32 Offset) {
  Ch[Channel].CurrentOffset = Offset;
  return 0;
}

SysS32 AFXGetCurrentOffset(SysS32 Channel) {
  return Ch[Channel].CurrentOffset;
  return 0;
}
SysS32 AFXSam(SysS32 Channel, SysF64 Freq, SysU32 SamFmt, void *SamMem,
              SysS32 SamEnd, SysF64 PlayForSeconds) {
  SysAssert(SamFmt == AFXFmtS16);
  AFXDeActivate(Channel);
  SysF64 LengthInSeconds = ((SysF64)(SamEnd)) / Freq;
  if (PlayForSeconds < 0) {
    PlayForSeconds = -PlayForSeconds * ((SysF64)(SamEnd)) / Freq;
  }
  SysS64 r = SamEnd;
  SysAssert(!(r & (r - 1)));
  Ch[Channel].Fmt = SamFmt;
  AFXFreq(Channel, Freq);
  Ch[Channel].Sam = SamMem;
  Ch[Channel].End = SamEnd;
  Ch[Channel].PlayForSecs = PlayForSeconds;
  Ch[Channel].LenSecs = LengthInSeconds;
  Ch[Channel].LoopRange = r;
  Ch[Channel].LoopsCurrent = 0;
  Ch[Channel].LoopRangeMask = r - 1;
  Ch[Channel].ReleaseEnvelope = 0;
  Ch[Channel].AttackEnvelope = 0;
  Ch[Channel].AttackEnvelopeLen = 0;
  Ch[Channel].ReleaseEnvelopeLen = 0;
  Ch[Channel].AttackSecs = 0;
  Ch[Channel].ReleaseSecs = 0;

  return 0;
}

SysS32 AFXFreq(SysS32 Channel, SysF64 FreqSamplesPerSecond) {
  Ch[Channel].Freq = FreqSamplesPerSecond;
  return 0;
}

SysS32 AFXVol(SysS32 Channel, SysF64 Left, SysF64 Right) {
  Ch[Channel].Vol[0] = Left;
  Ch[Channel].Vol[1] = Right;
  return 0;
}

SysS32 AFXMasterVol(SysF64 Left, SysF64 Right) {
  MasterVol[0] = Left;
  MasterVol[1] = Right;
  return 0;
}

SysF64 VolumeOf(const SysF64 *Envelope, SysS32 Len, SysF64 LenS, SysF64 TimeS) {
  if (!Len)
    return -1;
  SysAssert(Envelope);
  SysAssert(Len >= 2);
  SysS32 l2 = (Len << 1);
  if (TimeS >= LenS)
    return Envelope[l2 - 2 + 1];
  if (TimeS <= 0)
    return Envelope[0];
  SysF64 t = TimeS / LenS;
  for (int i = 0; i < (l2 - 2); i += 2) {
    if (t <= Envelope[i + 2]) {
      SysF64 dv = Envelope[i + 2 + 1] - Envelope[i + 1],
             dt = Envelope[i + 2] - Envelope[i];
      SysF64 v = Envelope[i + 1] + (t - Envelope[i]) * dv / dt;
      return v;
    }
  }
  return Envelope[l2 - 2 + 1];
}

SysS32 EnvelopeCheck(const SysF64 *m, SysU32 l, SysF64 S) {
  if (S <= 0) {
    SysAssert(!l);
    return 0;
  }
  if (l < 2)
    return -1;
  SysF64 lt = m[0];
  if (lt != 0)
    return -1;
  for (int i = 1; i < l; i++) {
    SysF64 ct = m[(i << 1)];
    if (ct <= lt)
      return -1;
    lt = ct;
  }
  if (lt != 1)
    return -1;
  return 0;
}

SysS32 AFXAttack(SysS32 Channel, const SysF64 *Envelope, SysS32 EnvelopeLength,
                 SysF64 Seconds) {
  Ch[Channel].AttackEnvelope = Envelope;
  Ch[Channel].AttackEnvelopeLen = EnvelopeLength;
  Ch[Channel].AttackSecs = Seconds;
  SysAssert((!Seconds) || (!EnvelopeCheck(Envelope, EnvelopeLength, Seconds)));
  return 0;
}
SysS32 AFXRelease(SysS32 Channel, const SysF64 *Envelope, SysS32 EnvelopeLength,
                  SysF64 Seconds) {
  Ch[Channel].ReleaseEnvelope = Envelope;
  Ch[Channel].ReleaseEnvelopeLen = EnvelopeLength;
  Ch[Channel].ReleaseSecs = Seconds;
  SysAssert((!Seconds) || (!EnvelopeCheck(Envelope, EnvelopeLength, Seconds)));
  return 0;
}
SysS32 AFXActivate(SysS32 Channel) {
  Ch[Channel].CurrentOffset = 0;
  Active |= (1 << Channel);
  return 0;
}

SysS32 AFXDeActivate(SysS32 Channel) {

  Active &= ~(1 << Channel);
  return 0;
}

SysS32 AFXLoadWav(const SysC8 *FileName, SysS16 *SamMem) {
  SysAssert(SamMem);

  SysS32 l = SysLoad(0, FileName, 0, 0, 0);
  l -= 44;
  SysLoad(0, FileName, 44, l, SamMem);
  return l / 2;
}

SysS32 AFXMix(SysF64 *MixBuffer, SysS32 MixBufferLen, SysU32 Freq, SysS32 c,
              SysS16 *Sam) {

  static SysU64 Counter = 0;
  static SysF64 maxt = 0, t = 0;
  SysU64 r = Ch[c].LoopRange, m = Ch[c].LoopRangeMask;
  SysF64 CurrentFadeV = 1;

  t = SysSec();

  SysF64 period = Ch[c].Freq / Freq;
  do {
    SysF64 TimePlayed = Ch[c].CurrentOffset / Ch[c].Freq;
    SysF64 TimeLeft = Ch[c].PlayForSecs - TimePlayed;

    SysS64 LenToEnd = MixBufferLen;
    if (TimeLeft <= 0) {
      if (Ch[c].ReleaseEnvelopeLen <= 0)
        return 1;
      if ((-TimeLeft) >= Ch[c].ReleaseSecs)
        return 1;
      CurrentFadeV = VolumeOf(Ch[c].ReleaseEnvelope, Ch[c].ReleaseEnvelopeLen,
                              Ch[c].ReleaseSecs, (SysF64)(-TimeLeft));
      SysODS("Fade:RS:%f TP:%fS TL:%fS CF:%f\n", Ch[c].ReleaseSecs, TimePlayed,
             TimeLeft, CurrentFadeV);
      for (int i = 0; i < Ch[c].ReleaseEnvelopeLen; i++)
        SysODS("%d: %fS\n", Ch[c].ReleaseEnvelope[i]);
      if (CurrentFadeV < 0)
        return 1;
      LenToEnd = -TimeLeft * Freq;
      if (LenToEnd <= 0)
        return 1;
      if (LenToEnd > MixBufferLen)
        LenToEnd = MixBufferLen;
      // = TimeLeft * SysAudioFreq+32;
    } else if (Ch[c].AttackEnvelopeLen > 0) {
      CurrentFadeV = VolumeOf(Ch[c].AttackEnvelope, Ch[c].AttackEnvelopeLen,
                              Ch[c].AttackSecs, TimePlayed);
      SysODS("Fade:AS:%f TP:%fS TL:%fS CF:%f\n", Ch[c].AttackSecs, TimePlayed,
             TimeLeft, CurrentFadeV);
      for (int i = 0; i < Ch[c].AttackEnvelopeLen; i++)
        SysODS("%d: %fS\n", Ch[c].AttackEnvelope[i]);
      if (CurrentFadeV < 0)
        CurrentFadeV = 1;
    }

    SysU64 ranges = 0, offset, rm, shft = 20, mshft = (1 << shft),
           prd = period * mshft;
    SysF64 of = fmod(Ch[c].CurrentOffset, r), base = Ch[c].CurrentOffset - of;
    rm = (m << shft) | (mshft - 1);
    offset = of * mshft;
    SysF64 vl = Ch[c].Vol[0] * CurrentFadeV;
    SysF64 vr = Ch[c].Vol[1] * CurrentFadeV;
    for (SysS32 i = 0; i < LenToEnd; i++) {
      SysU64 oi = (offset & rm);
      SysU16 oii = oi >> shft;
      SysAssert((oii >= 0) && (oii < Ch[c].End));
      SysF64 s = Sam[oii];
      SysF64 l = s * vl;
      SysF64 r = s * vr;
      MixBuffer[(i << 1) + 0] += l;
      MixBuffer[(i << 1) + 1] += r;
      offset += prd;
    }

    Ch[c].CurrentOffset = offset;
    Ch[c].CurrentOffset /= mshft;
    Ch[c].CurrentOffset += base;

    MixBufferLen -= LenToEnd;
  } while (MixBufferLen > 0);
  t = SysSec() - t;
  if (t > maxt)
    maxt = t;
  Counter++;
#ifdef SYS_DEBUG_ODS
  // if (~(Counter & 1023))
  SysODS("AFXMix: CHM:%x CH:%d T:%fS Max:%f\n", Active, c, t, maxt);
#endif
  SysAssert(!MixBufferLen);
  return 0;
}

enum { MAX_MIX_BUFFER_LEN = 8 * 1024 * 2 };
static SysU32 MixBufferLen = MAX_MIX_BUFFER_LEN;
static SysF64 MixBuffer[MAX_MIX_BUFFER_LEN];
SysS32 SysUserAudio(SysU32 AudioFlags, SysU32 AudioFreq, SysU8 *Stream,
                    SysS32 Len) {
  // static SysU32 l=0;
  // SysU32 m=SysMs(),d=m-l;
  // if(!d) d=1;
  // SysODS("%d %d %x %d %d %d
  // %d\n",AudioFlags,AudioFreq,Stream,(Len*14)/4,d,1000/d,(Len*1000)/(d*4));
  // l=m;

  if (!Active) {
    for (SysS32 i = 0; i < (Len >> 2); i++)
      ((SysU32 *)Stream)[i] = 0;
    return 0;
  }

  SysU32 BufferLen = (Len >> 2);
  SysAssert(MixBufferLen >= BufferLen);

  for (SysU32 i = 0; i < (BufferLen << 1); i++)
    MixBuffer[i] = 0;

  SysU32 i = 0, a = Active;
  while (a) {
    if (a & 1) {
      SysS32 Finished;
      Finished =
          AFXMix(MixBuffer, BufferLen, AudioFreq, i, (SysS16 *)(Ch[i].Sam));
      if (Finished) {
        AFXDeActivate(i);
      }
    }
    a >>= 1;
    i++;
  }
  SysS16 *b = (SysS16 *)Stream;

  for (SysU32 i = 0; i < BufferLen; i++) {
    SysF64 l = MixBuffer[(i << 1) + 0] * MasterVol[0];
    SysF64 r = MixBuffer[(i << 1) + 1] * MasterVol[1];
    if (l < -0x8000)
      l = -0x8000;
    else if (l > 0x7fff)
      l = 0x7fff;
    if (r < -0x8000)
      r = -0x8000;
    else if (r > 0x7fff)
      r = 0x7fff;
    b[(i << 1) + 0] = l;
    b[(i << 1) + 1] = r;
  }

  // SysODS("%08x %08x %08x\n",Active,FadeOn,FadeOff);
  return 0;
}

SysF64 AFXEnvADSR(SysF64 a, SysF64 d, SysF64 s, SysF64 r, SysF64 t) {
  if (t < a)
    return t / a;
  t -= a;
  if (t < d)
    return 1 + (t / d) * (s - 1);
  t -= d;
  SysF64 h = (1 - (a + d + r));
  if (t < h)
    return s;
  t -= h;
  if (t < r)
    return (1 - t / r) * s;
  return 0;
}

SysF64 AFXModSine(SysF64 f, SysF64 t) {
  const SysF64 pi2 = acosf(-1) * 2;
  return sinf(t * f * pi2);
}

SysF64 AFXModSquare(SysF64 f, SysF64 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return -1;
  else
    return 1;
}

SysF64 AFXModPulse(SysF64 f, SysF64 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return 0;
  else
    return 1;
}

SysF64 AFXModTri(SysF64 f, SysF64 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return (-1 + 2 * (t / 0.5f));
  else
    return (1 - 2 * ((t - 0.5f) / 0.5f));
}

SysF64 AFXModSaw(SysF64 f, SysF64 t) {
  t = fmodf(f * t, 1);
  return (-1 + 2 * t);
}

SysF64 AFXModOne(SysF64 f, SysF64 t) { return 1; }

SysU32 Hash(SysU32 Index) { return SysRNG(); };
SysF64 AFXNoise(SysU32 s, SysF64 x) {
  SysAssert(x >= 0);
  SysS32 xi[2] = {(SysS32)x, (SysS32)(x + 1)};
  x -= xi[0];
  SysU32 h[2] = {Hash((s << 16) + xi[0]) & 0xffff,
                 Hash((s << 16) + xi[1]) & 0xffff};
  SysF64 l[2] = {-1.0f + h[0] * 2.0f / 0xffff, -1.0f + h[1] * 2.0f / 0xffff};
  return l[0] + (1 - x) * (l[1] - l[0]);
}

SysF64 AFXModNoise(const SysF64 f, SysF64 t) { return AFXNoise(0, t * f); }

SysF64 AFXFToRC(SysF64 f) { return 1.0f / (2.0f * acosf(-1) * f); }

SysF64 AFXHighPassFilter(SysF64 RC, SysF64 s, SysF64 t) {
  static SysF64 LastO = 0, LastS = 0, LastT = 0;
  SysF64 o;
  if (t <= 0)
    o = s;
  else {
    SysF64 dt = t - LastT, ds = s - LastS;
    SysF64 a = RC / (RC + dt);
    o = a * (LastO + ds);
  }
  LastO = o;
  LastS = s;
  LastT = t;
  return o;
}

SysF64 AFXLowPassFilter(SysF64 RC, SysF64 s, SysF64 t) {
  static SysF64 LastO = 0, LastT = 0;
  SysF64 o;
  if (t <= 0)
    o = s;
  else {
    SysF64 dt = t - LastT;
    SysF64 a = dt / (RC + dt);
    o = LastO + a * (s - LastO);
  }
  LastO = o;
  LastT = t;
  return o;
}

SysF64 TestFX(SysF64 t) {
  const SysF64 RC = AFXFToRC(8000);
  SysF64 o = AFXModSine(800, t);
  o = AFXHighPassFilter(RC, o, t);
  return o;
}

SysS32 AFXSyn(SysU32 Flags, AFXSynFn Fn, SysF64 *Sam, SysS32 Samples,
              SysS16 *Sam16) {
  SysAssert(Sam);

  if (!(Flags & AFXSynAdd))
    for (SysS32 i = 0; i < Samples; i++)
      Sam[i] = 0;

  for (SysS32 i = 0; i < Samples; i++) {
    Sam[i] += Fn(((SysF64)i) / Samples);
  }

  if (Flags & AFXSynClip) {
    for (SysS32 i = 0; i < Samples; i++)
      if (Sam[i] > 1)
        Sam[i] = 1;
      else if (Sam[i] < -1)
        Sam[i] = -1;
  }

  if (Flags & AFXSynFit) {
    SysF64 m[2] = {0, 0};
    for (SysS32 i = 0; i < Samples; i++)
      if (Sam[i] > m[1])
        m[1] = Sam[i];
      else if (Sam[i] < m[0])
        m[0] = Sam[i];
    for (SysS32 i = 0; i < Samples; i++)
      Sam[i] = -1 + 2 * ((Sam[i] - m[0]) / (m[1] - m[0]));
  }

  if (Flags & AFXSyn2S16) {
    SysAssert(Sam16);
    for (SysS32 i = 0; i < Samples; i++)
      Sam16[i] = 0x7fff * Sam[i];
  }

  return 0;
}

void Limit(SysF64 *v, SysF64 *o, SysF64 l);
AFX3DS AFX3DListener = {0, 0, 0, 0};
SysS32 AFX3D(SysU32 Flags, SysS32 Channel, AFX3DS *Source, SysF64 Volume) {
  if (Channel < 0)
    return Channel;
  /*
SysAssert(Source);
SysAssert(Source->Pos);
SysAssert(AFX3DListener.Pos);
SysF64 v[3];
V3Copy(v, Source->Pos);
if (Flags & AFX3DWrap)
Limit(v, AFX3DListener.Pos, AFX3DListener.Radius);
V3Sub(v, v, AFX3DListener.Pos);
SysF64 d = V3Len(v);
d = 1 - d / Source->Radius;
d = d * d * d;
d = d * Volume;
if (d < 0)
d = 0;
else if (d > 1)
d = 1;
AFXVol(Channel, d, d);
*/
  return Channel;
}

SysF64 ThrustFX2(SysF64 t) {
  SysF64 ft = t, bf = 880 * 8;
  return (AFXModNoise(bf, ft) * 0.7f + AFXModNoise(bf * 1.5f, ft) * 0.3f) *
         AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.1f, t) * 0.5f;
}

SysF64 ThrustFX(SysF64 t) {
  SysF64 w = AFXModSine(500, t) * AFXModNoise(1000, t);
  return w;
}

SysF64 LaserFX(SysF64 t) {
  return AFXModSaw(220 * (1 + AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.9f, t)), t) *
         AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.1f, t);
}

SysF64 UFOFX(SysF64 t) {
  return AFXModTri(50 * (1 + 2 * AFXEnvADSR(0.5f, 0.0f, 1.0f, 0.5f, t)), t);
}

SysF64 BumpFX(SysF64 t) {
  SysF64 f = 100;
  return AFXModNoise(3 * f, t) * AFXModSquare(f, t);
}

SysF64 ExplosionFX(SysF64 t) {
  SysF64 f = 100;
  return AFXModNoise(3 * f, t) * AFXModTri(f, t);
}

SysF64 HyperFX(SysF64 t) {
  SysF64 af;
  af = 0.6f + 0.4f * AFXModSine(20, t);
  return AFXModSine(110, af * t) * AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.9f, t);
}

SysF64 BonusFX(SysF64 t) {
  SysF64 p = fmod(t * 8, 1);
  if (p < 0.5f)
    p = 1;
  else
    p = 0;
  return AFXModSine(440 * 8, t) * p;
}

SysF64 TriFX(SysF64 t) { return AFXModTri(1, t); }

SysS32 FXPlay(SysS32 Channel, SysU32 State, SysS32 Effect, SysF64 Freq,
              SysU32 ChannelMask) {
  // if(Effect!=FXThrust) return -1;// else Effect=FXBump;
  enum { FXSamples = 16 * 1024, f = FXSamples };
  static const struct AFXS {
    AFXSynFn Function;
    SysF64 Freq;
    SysS32 SamLen;
    SysF64 Secs;
    SysU32 Flags;
    SysF64 AttackS, ReleaseS;
    SysS32 EnvelopeLen;
    SysF64 AttackEnveLope[3 * 2], ReleaseEnvelope[3 * 2];
  } Patch[FXMax] = {
      {ThrustFX,
       f * 1.0f,
       FXSamples,
       3,
       (AFXSynClip | AFXSyn2S16),
       2,
       2,
       3,
       {0, 0, 0.5f, 0.5f, 1, 1},
       {0, 1, 0.5f, 0.5f, 1, 0}},

      {LaserFX, f, FXSamples, 1, (AFXSynClip | AFXSyn2S16), AFXNoAttack,
       AFXNoRelease, 0},

      {UFOFX,
       f * 3,
       FXSamples,
       7,
       (AFXSynClip | AFXSyn2S16),
       5,
       2,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {ExplosionFX,
       f,
       FXSamples,
       1,
       (AFXSynClip | AFXSyn2S16),
       1,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {HyperFX,
       f / 3.0f,
       FXSamples,
       3,
       (AFXSynClip | AFXSyn2S16),
       0,
       0,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {BonusFX,
       f / 2.0f,
       FXSamples,
       2,
       (AFXSynClip | AFXSyn2S16),
       1,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {BumpFX,
       f,
       FXSamples,
       1,
       (AFXSynClip | AFXSyn2S16),
       1,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {TriFX,
       f,
       FXSamples,
       3600,
       (AFXSynClip | AFXSyn2S16),
       0.01f,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
  };
  static SysS16 Sam[FXMax][FXSamples];
  static SysU32 Flags = 0;

  if (!Flags) {
    SysF64 *Work = SysNew(SysF64, FXSamples);
    for (SysU32 i = 0; i < FXMax; i++) {
      AFXSyn(Patch[i].Flags, Patch[i].Function, Work, Patch[i].SamLen, Sam[i]);
    }
    SysDelete(Work);
    Flags = 1;
  }

  SysAssert((Effect >= 0) && (Effect < FXMax));
  int c = Channel;
  if (State == FXStart) {
    if (c >= 0)
      if (Active & (1 << c))
        return -1;
    c = AFXFirstFreeChannel(ChannelMask);

    if (c < 0)
      return 0;
    SysF64 fxf = Patch[Effect].Freq;
    if (Freq < 0)
      fxf = -fxf * Freq;
    else
      fxf = Freq;
    AFXSam(c, fxf, AFXFmtS16, Sam[Effect], Patch[Effect].SamLen,
           Patch[Effect].Secs);
    AFXAttack(c, &Patch[Effect].AttackEnveLope[0], Patch[Effect].EnvelopeLen,
              Patch[Effect].AttackS);
    AFXRelease(c, &Patch[Effect].ReleaseEnvelope[0], Patch[Effect].EnvelopeLen,
               Patch[Effect].ReleaseS);
    AFXVol(c, 1, 1);
    AFXActivate(c);
    return c;
  }

  if (c < 0)
    return c;

  SysAssert(c < 32);

  if (State == FXFadeOff) {
    AFXDeActivate(c);
    c = -1;
    return c;
  }

  if (State == FXFinish) {
    AFXDeActivate(c);
    c = -1;
    c = -1;
    return c;
  }

  if (State == FXOff) {
    AFXDeActivate(c);
    c = -1;
    return c;
  }

  return -1;
}
