
#ifndef _RXMI_H_GS_2011_
#define _RXMI_H_GS_2011_
/*
RXMI Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "SYS.h"
enum { RXMI_FLGUP = (1 << 0) };

void RXMIDisplayKeyboard(void);
void RXMI_WHMidiNote(SysS64 KeyboardCharacter, SysU64 Flag);

#ifndef RXMI_NOIMPLEMENTATION
#include "math.h"
typedef struct RXMISTATUS {
  SysU64 Flags;
  SysS32 Octave, NoteOffset;
} RXMISTATUS;
static RXMISTATUS RXMI = {0};
typedef struct RXMINOTE {
  SysS32 Note;
  SysF64 Frequency;
  SysF64 Timestamp;
} RXMINOTE;

#ifndef RXMI_LOG
#define RXMI_LOG -1
#endif
SysF64 RXMI_MIDINoteToHz(SysU8 MIDINote) {

  MIDINote = MIDINote > 127 ? 127 : MIDINote;
  return 440.0 * pow(2, (MIDINote - 69.0) / 12.0);
}

const char *RXMINote[12] = {"C-", "C#", "D-", "D#", "E-", "F-",
                            "F#", "G-", "G#", "A-", "A#", "B-"};

SysS32 RXMI_Translate[256] = {
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 29, -1, -1,
    -1, 27, -1, -1, -1, -1, 16, 37, 18, 20, 35, 17, 19, 21, 23, 25, 27, 29, 31,
    33, -1, 25, -1, 39, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 32, 0,  34, -1,
    -1, 15, 7,  10, 6,  11, 16, 13, 15, 17, 26, 19, 21, 23, 14, 12, 28, 30, 12,
    18, 9,  20, 24, 8,  14, 4,  22, 2,  -1, -1, -1, -1, -1, 5,  -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 41, 10,
    -1, 36, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1};

#include "SFX.h"
static RXMISTATUS RS = {0};
static SysS32 FXChannel = -1, Note = -1;
// #define MIDI_ON
typedef int SEQPKT[4];
static int Seq(SEQPKT pkt);
static void NoteOn(RXMINOTE r) {
#ifdef MIDI_ON
  SEQPKT pkt = {0x90, r.Note, 127};
  Seq(pkt);
  return;
#endif

  if ((r.Note >= 0)) {
    if (Note > 0) {
      FXChannel = FXPlay(FXChannel, FXFadeOff, 7, -1, -1);
    }
    Note = r.Note;
    FXChannel = FXPlay(-1, FXStart, 7, -r.Frequency / 440, -1);
  }
}
static void NoteOff(RXMINOTE r) {
#ifdef MIDI_ON
  SEQPKT pkt = {0x80, r.Note, 0};
  Seq(pkt);
  return;
#endif
  if ((r.Note >= 0) && (Note == r.Note)) {
    FXChannel = FXPlay(FXChannel, FXFadeOff, 7, -1, -1);
    Note = -1;
  }
}

void RXMI_WHMidiNote(SysS64 KeyboardCharacter, SysU64 Flag) {

  RXMISTATUS *Status = &RXMI;
  int up = Flag & RXMI_FLGUP;
  RXMINOTE Note = {.Note = -1, .Timestamp = SysSec()};
  if (KeyboardCharacter < 0)
    return;
  SysS32 n = -1;
  if (!Status->Flags) {
    Status->Octave = 5;
    Status->NoteOffset = 0;
    Status->Flags |= 1;
  }
  int chng = 0;
  switch (KeyboardCharacter) {
  case SYS_UP:
    if (!up)
      Status->Octave++;
    chng = 1;
    break;
  case SYS_DOWN:
    if (!up)
      Status->Octave--;
    chng = 1;
    break;
  case SYS_RIGHT:
    if (!up)
      Status->NoteOffset++;
    chng = 1;
    break;
  case SYS_LEFT:
    if (!up)
      Status->NoteOffset--;
    chng = 1;
    break;
  }
  if (Status->NoteOffset < 0) {
    Status->NoteOffset = 11;
    Status->Octave--;
  }
  if (Status->NoteOffset > 11) {
    Status->NoteOffset = 0;
    Status->Octave++;
  }
  if (Status->Octave < 0) {
    Status->Octave = 10;
  }
  if (Status->Octave > 10) {
    Status->Octave = 0;
  }
  if (chng) {
    if (!up) {
      RXMIDisplayKeyboard();
    }
    return;
  }
  n = RXMI_Translate[KeyboardCharacter];
  if (n < 0)
    return;
  n += Status->Octave * 12 + Status->NoteOffset;
  Note.Note = n;
  Note.Frequency = RXMI_MIDINoteToHz(Note.Note);
  int ocn = n / 12;
  int ncn = n % 12;
  if (!up) {
    SysLog(RXMI_LOG, "[%d:%s%d] %fHz\n", n, RXMINote[ncn], ocn, Note.Frequency);
  }
  if (!up)
    NoteOn(Note);
  else
    NoteOff(Note);
  return;
}
void RXMIDisplayKeyboard(void) {
  RXMISTATUS *Status = &RXMI;
  SysAssert(Status->Flags);
  SysLog(RXMI_LOG, "Octave:%d Note:(%d)\n", Status->Octave, Status->NoteOffset);
  const char *kb[4] = {
      "` 1 2 3 4 5 6 7 8 9 0 - = B", "T q w e r t y u i o p [ ] R",
      "C a s d f g h j k l ; ' # ", "\\ z x c v b n m , . /   "};
  for (int i = 0; i < 4; i++) {
    const char *s = kb[i];
    int n = 0;
    if (~i & 1)
      SysLog(RXMI_LOG, "   ");
    for (int j = 0; s[j]; j++) {
      if (s[j] != ' ') {
        int c = s[j];
        switch (c) {
        case 'B':
          c = SYS_BACKSPACE;
          break;
        case 'T':
          c = SYS_TAB;
          break;
        case 'R':
          c = SYS_RETURN;
          break;
        case 'C':
          c = SYS_CAPSLOCK;
          break;
        }
        n = RXMI_Translate[c];
        if (n >= 0) {
          n += Status->Octave * 12 + Status->NoteOffset;
          int ocn = n / 12;
          int ncn = n % 12;
          SysLog(RXMI_LOG, "[%c:%s%d]", s[j], RXMINote[ncn], ocn);
        }
      } else
        SysLog(RXMI_LOG, " ");
    }
    SysLog(RXMI_LOG, "\n");
  }
}

#include <alsa/asoundlib.h>
#include <unistd.h>
int Seq(SEQPKT pkt) {
  static snd_seq_event_t event;
  static unsigned char midimsg[3];
  static snd_seq_t *seq_handle;
  static int midi_out_port;
  static snd_midi_event_t *eventparser;
  static snd_seq_event_t *midi_event;

  static int status;
  static int mode = SND_RAWMIDI_NONBLOCK;
  static snd_rawmidi_t *midiout = NULL;
  static const char *portname = "hw:1,0,0";
  static int init = 0;

  int res;

  if (!init) {
    init = 1;
    if ((status =
             snd_seq_open(&seq_handle, "default", SND_SEQ_OPEN_OUTPUT, 0)) < 0)
      return -1;
    snd_seq_set_client_name(seq_handle, "RXMI");
    char portname[64] = "RXMI OUT";

    res = midi_out_port = snd_seq_create_simple_port(
        seq_handle, portname,
        SND_SEQ_PORT_CAP_READ | SND_SEQ_PORT_CAP_SUBS_READ,
        SND_SEQ_PORT_TYPE_APPLICATION);

    if (res < 0) {
      printf("udp2midi: Error creating MIDI port!\n");
      status = -1;
      snd_seq_close(seq_handle);
      return -1;
    }
    res = snd_midi_event_new(3, &eventparser);
    if (res != 0) {
      printf("udp2midi: Error making midi event parser!\n");
      status = -1;

      snd_seq_close(seq_handle);
      return -1;
    }
    snd_midi_event_init(eventparser);

    midi_event = &event;
  }
  if (status < 0) {
    printf("Problem opening MIDI output!\n");
    return -1;
  }

  midimsg[0] = pkt[0];
  midimsg[1] = pkt[1];
  midimsg[2] = pkt[2];
  printf("udp2midi: Sending event: 0x%x 0x%x 0x%x\n", midimsg[0], midimsg[1],
         midimsg[2]);

  res = snd_midi_event_encode(eventparser, midimsg, 3, midi_event);

  if (res < 0) {
    printf("Error encoding midi event!\n");
  }

  snd_midi_event_reset_encode(eventparser);

  if (midi_event->type == SND_SEQ_EVENT_NOTEON) {
    printf("udp2midi: Note on: %d, channel %d\n", midi_event->data.note.note,
           midi_event->data.control.channel);
  } else if (midi_event->type == SND_SEQ_EVENT_NOTEOFF) {
    printf("udp2midi: Note off: %d, channel %d\n", midi_event->data.note.note,
           midi_event->data.control.channel);
  }

  snd_seq_ev_set_subs(midi_event);
  snd_seq_ev_set_direct(midi_event);
  snd_seq_ev_set_source(midi_event, midi_out_port);

  snd_seq_event_output_direct(seq_handle, midi_event);

  return 0;
}

#endif
#endif
