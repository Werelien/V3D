#!/bin/bash
cd ../../Build/
make -j 8 config=release
cp -r ../Dev/Src/Shaders ../Final/Assets
cp Release/V3D ../Final/
