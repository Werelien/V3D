#!/bin/bash
cd ../..
cp -r Dev/Src/Shaders Final/Assets/Shaders
cd Final
emcc -v -O3 -s INITIAL_MEMORY=32MB -s MAXIMUM_MEMORY=64MB -s ALLOW_MEMORY_GROWTH=1 -s MIN_WEBGL_VERSION=2 -s MAX_WEBGL_VERSION=2 -s FULL_ES3=1 -s USE_SDL=2 -s USE_SDL_TTF=2 ../Dev/Src/V3D.c ../Dev/Src/GFX.c ../Dev/Src/Implementation.c ../Dev/Src/SysSDL.c -o V3D.html --preload-file Assets
