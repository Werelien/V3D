#!/bin/bash
source ./DebugUpdate.sh
cd ../Final
File="../Logs/Debug.Log"
./V3D >$File
