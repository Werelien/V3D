#!/bin/bash
source ./ReleaseUpdate.sh
cd ../Final
File="../Logs/Release.Log"
./V3D >$File
