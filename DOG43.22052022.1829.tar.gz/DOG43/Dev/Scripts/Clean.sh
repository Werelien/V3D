#!/bin/bash
cd ../../Build
make config=debug clean
make config=release clean
rm -f -r ../Final/Assets/Shaders
rm -f ../Final/V3D*
rm -f ../Logs/*
