
/*
RFXMI Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "RFX.h"
#include "SFX.h"
#include <assert.h>

#define RFXAssert assert

RFXF64 RSinFX(RFXF64 t) { return SFXModSine(1, t); }
RFXF64 RPulseFX(RFXF64 t) { return SFXModPulse(1, t); }
RFXF64 RSquareFX(RFXF64 t) { return SFXModSquare(1, t); }
RFXF64 RTriFX(RFXF64 t) { return SFXModTri(1, t); }
RFXF64 RSawFX(RFXF64 t) { return SFXModSaw(1, t); }
RFXF64 RNoiseFX(RFXF64 t) {
  t *= 1000;
  return SFXModNoise(1, t) + SFXModNoise(2, t) * 0.5f +
         SFXModNoise(4, t) * 0.25f + SFXModNoise(8, t) * 0.125f +
         SFXModNoise(16, t) * 0.125f * 0.5f + 0;
}
enum { RFXSamples = 1024 };
typedef struct {
  SFXSynFn Function;
  RFXF64 AttackS, ReleaseS;
  RFXS32 EnvelopeLen;
  RFXF64 AttackEnveLope[3 * 2], ReleaseEnvelope[3 * 2];
} PatchS;

static const PatchS Patch[RFXMaxFX] = {
    {RSinFX, 0.01f, 1, 2, {0, 0, 1, 1}, {0, 1, 1, 0}},
    {RPulseFX, 0.01f, 1, 2, {0, 0, 1, 1}, {0, 1, 1, 0}},
    {RSquareFX, 0.01f, 1, 2, {0, 0, 1, 1}, {0, 1, 1, 0}},
    {RTriFX, 0.01f, 1, 2, {0, 0, 1, 1}, {0, 1, 1, 0}},
    {RSawFX, 0.01f, 1, 2, {0, 0, 1, 1}, {0, 1, 1, 0}},
    {RNoiseFX, 0.01f, 1, 2, {0, 0, 1, 1}, {0, 1, 1, 0}},
};
RFXS32 RFXFreq(RFXS32 Channel, RFXF64 Freq) {
  return SFXFreq(Channel, Freq * RFXSamples);
}
RFXS32 RFXVol(RFXS32 Channel, RFXF64 Left, RFXF64 Right) {
  return SFXVol(Channel, Left, Right);
}

RFXS32 RFXPlay(RFXS32 Channel, RFXU32 State, RFXS32 Effect, RFXF64 Freq,
               RFXU32 ChannelMask) {
  static RFXS16 Sam[RFXMaxChannels][RFXSamples];
  static RFXU32 Flags = 0;

  if (!Flags) {
    RFXAssert((sizeof(Patch) / sizeof(PatchS)) == RFXMaxFX);
    RFXF64 Work[RFXSamples];
    for (RFXU32 i = 0; i < RFXMaxFX; i++) {
      SFXSyn((SFXSynClip | SFXSyn2S16), Patch[i].Function, Work, RFXSamples,
             Sam[i]);
    }
    Flags = 1;
  }

  RFXAssert((Effect >= 0) && (Effect < RFXMaxFX));
  int c = Channel;
  if (State == RFXStart) {
    if (c >= 0)
      if (SFXActive() & (1 << c))
        return -1;
    c = SFXFirstFreeChannel(ChannelMask);

    if (c < 0)
      return 0;
    RFXF64 fxf = Freq * RFXSamples;
    SFXSam(c, fxf, SFXFmtS16, Sam[Effect], RFXSamples, 24 * 3600);
    SFXAttack(c, &Patch[Effect].AttackEnveLope[0], Patch[Effect].EnvelopeLen,
              Patch[Effect].AttackS);
    SFXRelease(c, &Patch[Effect].ReleaseEnvelope[0], Patch[Effect].EnvelopeLen,
               Patch[Effect].ReleaseS);
    SFXVol(c, 1, 1);
    SFXActivate(c);
    return c;
  }

  if (c < 0)
    return c;

  RFXAssert(c < 32);

  if (State == RFXFadeOff) {
    SFXDeActivate(c);
    c = -1;
    return c;
  }

  if (State == RFXFinish) {
    SFXDeActivate(c);
    c = -1;
    return c;
  }

  if (State == RFXOff) {
    SFXDeActivate(c);
    c = -1;
    return c;
  }

  return -1;
}
#include <alsa/asoundlib.h>
#include <unistd.h>
int RFXSeq(RFXSEQPKT pkt) {
  static snd_seq_event_t Event;
  static snd_seq_t *SeqH;
  static int MOPort;
  static snd_midi_event_t *EventParser;
  static snd_seq_event_t *MEvent;

  static int Status;
  static int init = 0;

  int res;

  if (!init) {
    init = 1;
    if ((Status = snd_seq_open(&SeqH, "default", SND_SEQ_OPEN_OUTPUT, 0)) < 0)
      return -1;
    snd_seq_set_client_name(SeqH, "RXMI");
    char portname[64] = "RXMI OUT";

    res = MOPort = snd_seq_create_simple_port(
        SeqH, portname, SND_SEQ_PORT_CAP_READ | SND_SEQ_PORT_CAP_SUBS_READ,
        SND_SEQ_PORT_TYPE_APPLICATION);

    if (res < 0) {
      RFXAssert(0);
      Status = -1;
      snd_seq_close(SeqH);
      return -1;
    }
    res = snd_midi_event_new(3, &EventParser);
    if (res != 0) {
      RFXAssert(0);
      Status = -1;

      snd_seq_close(SeqH);
      return -1;
    }
    snd_midi_event_init(EventParser);

    MEvent = &Event;
  }
  if (Status < 0) {
    RFXAssert(0);
    return -1;
  }

  res = snd_midi_event_encode(EventParser, pkt, 3, MEvent);

  if (res < 0) {
    RFXAssert(0);
  }

  snd_midi_event_reset_encode(EventParser);

  snd_seq_ev_set_subs(MEvent);
  snd_seq_ev_set_direct(MEvent);
  snd_seq_ev_set_source(MEvent, MOPort);

  snd_seq_event_output_direct(SeqH, MEvent);

  return 0;
}
