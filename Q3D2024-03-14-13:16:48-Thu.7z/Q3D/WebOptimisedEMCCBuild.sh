#!/bin/sh
rm Web/*
make -j8 --makefile=emakefile
ls -al Web



