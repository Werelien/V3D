#!/bin/sh
tcc -DBMF_CREATE_CLI -Ofast -o./X/BMF ./Src/BMF.c
ls -al ./X/BMF
strip ./X/BMF
echo "...Stripped..."
ls -al ./X/BMF
