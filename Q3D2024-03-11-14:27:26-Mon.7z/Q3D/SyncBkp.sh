#!/bin/sh
rm Xctbl
rm Web/*
rm Logs/*
rm X/*
D=$(date +"%Y-%m-%d-%T-%a")
rsync -rbvu --backup-dir=Q3DBkp$D ~/Q3D ~/Bkp
tar -cJvf ../Bkp$D.tar.xz ../Bkp
