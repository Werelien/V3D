/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#ifndef _SFX_H_GS_2011_
#define _SFX_H_GS_2011_
#include "SYS.h"

enum {
  SFXMaxChannels = 32,
  SFXFmtS16 = 0,
  SFXNoAttack = 0,
  SFXNoRelease = 0,
  SFXNoLoopStart = -1,
  SFXEnd
};
SysS32 SFXSam(SysS32 Channel, SysF32 FreqSamplesPerSecond, SysU32 SamFmt,
              void *SamMem, SysS32 SamEnd,
              SysF64 PlaySecondsNgvIsNumberOfTimesToPlay);
SysS32 SFXSetCurrentOffset(SysS32 Channel, SysS32 Offset);
SysS32 SFXGetCurrentOffset(SysS32 Channel);
SysS32 SFXFreq(SysS32 Channel, SysF32 FreqSamplesPerSecond);
SysS32 SFXVol(SysS32 Channel, SysF32 Left, SysF32 Right);
SysS32 SFXMasterVol(SysF32 Left, SysF32 Right);
SysS32 SFXActivate(SysS32 Channel);
SysS32 SFXAttack(SysS32 Channel, const SysF32 *Envelope, SysS32 EnvelopeLength,
                 SysF32 Seconds);
SysS32 SFXRelease(SysS32 Channel, const SysF32 *Envelope, SysS32 EnvelopeLength,
                  SysF32 Seconds);
SysS32 SFXDeActivate(SysS32 Channel);
SysS32 SFXFirstFreeChannel(SysU32 Mask);

SysS32 SFXLoadWav(const SysC8 *FileName, SysS16 *SamMem);

SysF32 SFXEnvADSR(SysF32 a, SysF32 d, SysF32 s, SysF32 r, SysF32 t);
SysF32 SFXModSine(SysF32 f, SysF32 t);
SysF32 SFXModPulse(SysF32 f, SysF32 t);
SysF32 SFXModSquare(SysF32 f, SysF32 t);
SysF32 SFXModTri(SysF32 f, SysF32 t);
SysF32 SFXModSaw(SysF32 f, SysF32 t);
SysF32 SFXModNoise(SysF32 f, SysF32 t);
SysF32 SFXModOne(SysF32 f, SysF32 t);
SysF32 SFXFToRC(SysF32 f);
SysF32 SFXHighPassFilter(SysF32 RC, SysF32 s, SysF32 t);
SysF32 SFXLowPassFilter(SysF32 RC, SysF32 s, SysF32 t);

enum {
  SFXSynAdd = (1 << 8),
  SFXSynClip = (1 << 9),
  SFXSynFit = (1 << 10),
  SFXSyn2S16 = (1 << 11),
  SFXSynEnd
};
typedef SysF32 (*SFXSynFn)(SysF32 t);
SysS32 SFXSyn(SysU32 Flags, SFXSynFn Fn, SysF32 *Sam, SysS32 Samples,
              SysS16 *Sam16);

typedef struct SFX3DS {
  SysF32 *Pos, *Vel, *Up, Radius;
} SFX3DS;
extern SFX3DS SFX3DListener;
enum { SFX3DWrap = (1 << 0), SFX3DEnd };
SysS32 SFX3D(SysU32 Flags, SysS32 Channel, SFX3DS *Source, SysF32 Volume);

enum {
  FXOff,
  FXStart,
  FXFinish,
  FXFadeOff,
  FXThrust = 0,
  FXLaser,
  FXMAN,
  FXExplosion,
  FXHyper,
  FXBonus,
  FXBump,
  FXTest,
  FXMax
};
SysS32 FXPlay(SysS32 ID, SysU32 State, SysS32 Effect, SysU32 ChannelMask);
#endif
