#!/bin/sh
make -j8 --makefile=emakefile
ls -al Q3DWeb



