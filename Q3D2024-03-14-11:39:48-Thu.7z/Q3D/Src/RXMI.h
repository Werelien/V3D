
#ifndef _RXMI_H_GS_2011_
#define _RXMI_H_GS_2011_
/*
RXMI Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
typedef char RXC8;
typedef unsigned char RXU8;
typedef signed char RXS8;
typedef unsigned short RXU16;
typedef signed short RXS16;
typedef unsigned int RXU32;
typedef signed int RXS32;
typedef unsigned long long RXU64;
typedef signed long long RXS64;
typedef float RXF32;
typedef double RXF64;
enum {
  RX_CAPSLOCK = 128,
  RX_RSHIFT,
  RX_LSHIFT,
  RX_RCTRL,
  RX_LCTRL,
  RX_RALT,
  RX_LALT,
  RX_RMETA,
  RX_LMETA,
  RX_LSUPER,
  RX_RSUPER,
  RX_MODE,
  RX_COMPOSE,
  RX_UP,
  RX_DOWN,
  RX_RIGHT,
  RX_LEFT,
  RX_INSERT,
  RX_HOME,
  RX_END,
  RX_PAGEUP,
  RX_PAGEDOWN,
  RX_BACKSPACE,
  RX_TAB,
  RX_CLEAR,
  RX_RETURN,
  RX_PAUSE,
  RX_ESCAPE,
  RX_DELETE,
  RX_F1,
  RX_F2,
  RX_F3,
  RX_F4,
  RX_F5,
  RX_F6,
  RX_F7,
  RX_F8,
  RX_F9,
  RX_F10,
  RX_F11,
  RX_F12,

  RX_KEYS_MAX = 256,
  RX_KEYS_END

};
enum { RXMI_FLGUP = (1 << 0), RXMI_MAX_LINES = 8, RXMI_MAX_CHARS = 256 };

typedef struct RXMINOTE {
  RXS32 Note;
  RXF64 Frequency;
  RXF64 Timestamp;
} RXMINOTE;

typedef struct RXMISTATUS {
  RXU32 Flags, Layout, Instrument, Chord;
  RXS32 Octave, NoteOffset;
  RXU8 LAlt, RAlt, LShf, RShf, LCtr, RCtr, Spc, U, D, L, R, Midi;
  RXS32 NotesOn, KeysPressed;
  RXF64 Velocity, LastVelocity, PitchBend, UpdateT, UpdateDT;
} RXMISTATUS;
void RXMI_WHMidiNote(RXS64 KeyboardCharacter, RXU64 Flags, RXF64 TimeS);
void RXMI_Update(RXF64 TimeS);
void RXMI_Open(void);
void RXMI_Close(void);
extern RXMISTATUS RXMI;
extern RXC8 RXMIDisplay[RXMI_MAX_LINES][RXMI_MAX_CHARS];
#endif
