#!/bin/sh
make clean;time make -j9 CC=tcc;./X/Xctbl
