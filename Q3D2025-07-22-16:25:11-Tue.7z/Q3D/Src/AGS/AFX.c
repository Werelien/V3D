/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "AFX.h"
#include "SYS.h"
#include <math.h>

static AFXU32 Active = 0;
AFXU32 AFXActive(void) { return Active; }
static AFXF64 MasterVol[2] = {1, 1};

AFXU8 *MemCpy(AFXU8 *d, const AFXU8 *s, AFXU32 l) {
  for (AFXU32 i = 0; i < l; i++)
    d[i] = s[i];
  return d;
}

AFXS32 MemRead(AFXU8 *b, AFXU32 l, const AFXU8 *s, AFXU32 sl, AFXU32 *so) {
  if ((so[0] + l) > sl)
    l = sl - so[0];
  MemCpy(b, &s[so[0]], l);
  so[0] += l;
  return l;
}

AFXS32 MemWrite(const AFXU8 *b, AFXU32 l, AFXU8 *m, AFXU32 ml, AFXU32 *mo) {
  SysAssert((mo[0] + l) <= ml);
  MemCpy(&m[mo[0]], b, l);
  mo[0] += l;
  return l;
}

static struct AFXS {
  AFXU32 Fmt;
  AFXS32 AttackEnvelopeLen, ReleaseEnvelopeLen;
  void *Sam;
  const AFXF64 *AttackEnvelope, *ReleaseEnvelope;
  AFXF64 Freq, Vol[2], PlayForSecs, LenSecs, AttackSecs, ReleaseSecs;
  AFXS64 End, LoopsCurrent, LoopRange, LoopRangeMask;
  AFXF64 CurrentOffset;
} Ch[AFXMaxChannels];

AFXS32 AFXFirstFreeChannel(AFXU32 Mask) {
  AFXU32 na = (~Active) & Mask;
  if (!na)
    return -1;

  AFXU32 i = 0, a = Active | (~Mask);
  while (na) {
    if (na & 1)
      return i;
    na >>= 1;
    i++;
  }
  return -1;
}

AFXS32 AFXSetCurrentOffset(AFXS32 Channel, AFXS32 Offset) {
  Ch[Channel].CurrentOffset = Offset;
  return 0;
}

AFXS32 AFXGetCurrentOffset(AFXS32 Channel) {
  return Ch[Channel].CurrentOffset;
  return 0;
}
AFXS32 AFXSam(AFXS32 Channel, AFXF64 Freq, AFXU32 SamFmt, void *SamMem,
              AFXS32 SamEnd, AFXF64 PlayForSeconds) {
  SysAssert(SamFmt == AFXFmtS16);
  AFXDeActivate(Channel);
  AFXF64 LengthInSeconds = ((AFXF64)(SamEnd)) / Freq;
  if (PlayForSeconds < 0) {
    PlayForSeconds = -PlayForSeconds * ((AFXF64)(SamEnd)) / Freq;
  }
  AFXS64 r = SamEnd;
  SysAssert(!(r & (r - 1)));
  Ch[Channel].Fmt = SamFmt;
  AFXFreq(Channel, Freq);
  Ch[Channel].Sam = SamMem;
  Ch[Channel].End = SamEnd;
  Ch[Channel].PlayForSecs = PlayForSeconds;
  Ch[Channel].LenSecs = LengthInSeconds;
  Ch[Channel].LoopRange = r;
  Ch[Channel].LoopsCurrent = 0;
  Ch[Channel].LoopRangeMask = r - 1;
  Ch[Channel].ReleaseEnvelope = 0;
  Ch[Channel].AttackEnvelope = 0;
  Ch[Channel].AttackEnvelopeLen = 0;
  Ch[Channel].ReleaseEnvelopeLen = 0;
  Ch[Channel].AttackSecs = 0;
  Ch[Channel].ReleaseSecs = 0;

  return 0;
}

AFXS32 AFXFreq(AFXS32 Channel, AFXF64 FreqSamplesPerSecond) {
  Ch[Channel].Freq = FreqSamplesPerSecond;
  return 0;
}

AFXS32 AFXVol(AFXS32 Channel, AFXF64 Left, AFXF64 Right) {
  Ch[Channel].Vol[0] = Left;
  Ch[Channel].Vol[1] = Right;
  return 0;
}

AFXS32 AFXMasterVol(AFXF64 Left, AFXF64 Right) {
  MasterVol[0] = Left;
  MasterVol[1] = Right;
  return 0;
}

AFXF64 VolumeOf(const AFXF64 *Envelope, AFXS32 Len, AFXF64 LenS, AFXF64 TimeS) {
  if (!Len)
    return -1;
  SysAssert(Envelope);
  SysAssert(Len >= 2);
  AFXS32 l2 = (Len << 1);
  if (TimeS >= LenS)
    return Envelope[l2 - 2 + 1];
  if (TimeS <= 0)
    return Envelope[0];
  AFXF64 t = TimeS / LenS;
  for (int i = 0; i < (l2 - 2); i += 2) {
    if (t <= Envelope[i + 2]) {
      AFXF64 dv = Envelope[i + 2 + 1] - Envelope[i + 1],
             dt = Envelope[i + 2] - Envelope[i];
      AFXF64 v = Envelope[i + 1] + (t - Envelope[i]) * dv / dt;
      return v;
    }
  }
  return Envelope[l2 - 2 + 1];
}

AFXS32 EnvelopeCheck(const AFXF64 *m, AFXU32 l, AFXF64 S) {
  if (S <= 0) {
    SysAssert(!l);
    return 0;
  }
  if (l < 2)
    return -1;
  AFXF64 lt = m[0];
  if (lt != 0)
    return -1;
  for (int i = 1; i < l; i++) {
    AFXF64 ct = m[(i << 1)];
    if (ct <= lt)
      return -1;
    lt = ct;
  }
  if (lt != 1)
    return -1;
  return 0;
}

AFXS32 AFXAttack(AFXS32 Channel, const AFXF64 *Envelope, AFXS32 EnvelopeLength,
                 AFXF64 Seconds) {
  Ch[Channel].AttackEnvelope = Envelope;
  Ch[Channel].AttackEnvelopeLen = EnvelopeLength;
  Ch[Channel].AttackSecs = Seconds;
  SysAssert((!Seconds) || (!EnvelopeCheck(Envelope, EnvelopeLength, Seconds)));
  return 0;
}
AFXS32 AFXRelease(AFXS32 Channel, const AFXF64 *Envelope, AFXS32 EnvelopeLength,
                  AFXF64 Seconds) {
  Ch[Channel].ReleaseEnvelope = Envelope;
  Ch[Channel].ReleaseEnvelopeLen = EnvelopeLength;
  Ch[Channel].ReleaseSecs = Seconds;
  SysAssert((!Seconds) || (!EnvelopeCheck(Envelope, EnvelopeLength, Seconds)));
  return 0;
}
AFXS32 AFXActivate(AFXS32 Channel) {
  Ch[Channel].CurrentOffset = 0;
  Active |= (1 << Channel);
  return 0;
}

AFXS32 AFXDeActivate(AFXS32 Channel) {

  Active &= ~(1 << Channel);
  return 0;
}

AFXS32 AFXLoadWav(const AFXC8 *FileName, AFXS16 *SamMem) {
  SysAssert(SamMem);

  AFXS32 l = SysLoad(0, FileName, 0, 0, 0);
  l -= 44;
  SysLoad(0, FileName, 44, l, SamMem);
  return l / 2;
}

AFXS32 AFXMix(AFXF64 *MixBuffer, AFXS32 MixBufferLen, AFXU32 Freq, AFXS32 c,
              AFXS16 *Sam) {

  static AFXU64 Counter = 0;
  static AFXF64 maxt = 0, t = 0;
  AFXU64 r = Ch[c].LoopRange, m = Ch[c].LoopRangeMask;
  AFXF64 CurrentFadeV = 1;

  t = SysSec();

  AFXF64 period = Ch[c].Freq / Freq;
  do {
    AFXF64 TimePlayed = Ch[c].CurrentOffset / Ch[c].Freq;
    AFXF64 TimeLeft = Ch[c].PlayForSecs - TimePlayed;

    AFXS64 LenToEnd = MixBufferLen;
    if (TimeLeft <= 0) {
      if (Ch[c].ReleaseEnvelopeLen <= 0)
        return 1;
      if ((-TimeLeft) >= Ch[c].ReleaseSecs)
        return 1;
      CurrentFadeV = VolumeOf(Ch[c].ReleaseEnvelope, Ch[c].ReleaseEnvelopeLen,
                              Ch[c].ReleaseSecs, (AFXF64)(-TimeLeft));
      SysODS("Fade:RS:%f TP:%fS TL:%fS CF:%f\n", Ch[c].ReleaseSecs, TimePlayed,
             TimeLeft, CurrentFadeV);
      for (int i = 0; i < Ch[c].ReleaseEnvelopeLen; i++)
        SysODS("%d: %fS\n", Ch[c].ReleaseEnvelope[i]);
      if (CurrentFadeV < 0)
        return 1;
      LenToEnd = -TimeLeft * Freq;
      if (LenToEnd <= 0)
        return 1;
      if (LenToEnd > MixBufferLen)
        LenToEnd = MixBufferLen;
      // = TimeLeft * AFXAudioFreq+32;
    } else if (Ch[c].AttackEnvelopeLen > 0) {
      CurrentFadeV = VolumeOf(Ch[c].AttackEnvelope, Ch[c].AttackEnvelopeLen,
                              Ch[c].AttackSecs, TimePlayed);
      SysODS("Fade:AS:%f TP:%fS TL:%fS CF:%f\n", Ch[c].AttackSecs, TimePlayed,
             TimeLeft, CurrentFadeV);
      for (int i = 0; i < Ch[c].AttackEnvelopeLen; i++)
        SysODS("%d: %fS\n", Ch[c].AttackEnvelope[i]);
      if (CurrentFadeV < 0)
        CurrentFadeV = 1;
    }

    AFXU64 ranges = 0, offset, rm, shft = 20, mshft = (1 << shft),
           prd = period * mshft;
    AFXF64 of = fmod(Ch[c].CurrentOffset, r), base = Ch[c].CurrentOffset - of;
    rm = (m << shft) | (mshft - 1);
    offset = of * mshft;
    AFXF64 vl = Ch[c].Vol[0] * CurrentFadeV;
    AFXF64 vr = Ch[c].Vol[1] * CurrentFadeV;
    for (AFXS32 i = 0; i < LenToEnd; i++) {
      AFXU64 oi = (offset & rm);
      AFXU16 oii = oi >> shft;
      SysAssert((oii >= 0) && (oii < Ch[c].End));
      AFXF64 s = Sam[oii];
      AFXF64 l = s * vl;
      AFXF64 r = s * vr;
      MixBuffer[(i << 1) + 0] += l;
      MixBuffer[(i << 1) + 1] += r;
      offset += prd;
    }

    Ch[c].CurrentOffset = offset;
    Ch[c].CurrentOffset /= mshft;
    Ch[c].CurrentOffset += base;

    MixBufferLen -= LenToEnd;
  } while (MixBufferLen > 0);
  t = SysSec() - t;
  if (t > maxt)
    maxt = t;
  Counter++;
#ifdef SYS_DEBUG_ODS
  // if (~(Counter & 1023))
  SysODS("AFXMix: CHM:%x CH:%d T:%fS Max:%f\n", Active, c, t, maxt);
#endif
  SysAssert(!MixBufferLen);
  return 0;
}

enum { MAX_MIX_BUFFER_LEN = 8 * 1024 * 2 };
static AFXU32 MixBufferLen = MAX_MIX_BUFFER_LEN;
static AFXF64 MixBuffer[MAX_MIX_BUFFER_LEN];
AFXS32 SysUserAudio(AFXU32 AudioFlags, AFXU32 AudioFreq, AFXU8 *Stream,
                    AFXS32 Len) {
  // static AFXU32 l=0;
  // AFXU32 m=AFXMs(),d=m-l;
  // if(!d) d=1;
  // SysODS("%d %d %x %d %d %d
  // %d\n",AudioFlags,AudioFreq,Stream,(Len*14)/4,d,1000/d,(Len*1000)/(d*4));
  // l=m;

  if (!Active) {
    for (AFXS32 i = 0; i < (Len >> 2); i++)
      ((AFXU32 *)Stream)[i] = 0;
    return 0;
  }

  AFXU32 BufferLen = (Len >> 2);
  SysAssert(MixBufferLen >= BufferLen);

  for (AFXU32 i = 0; i < (BufferLen << 1); i++)
    MixBuffer[i] = 0;

  AFXU32 i = 0, a = Active;
  while (a) {
    if (a & 1) {
      AFXS32 Finished;
      Finished =
          AFXMix(MixBuffer, BufferLen, AudioFreq, i, (AFXS16 *)(Ch[i].Sam));
      if (Finished) {
        AFXDeActivate(i);
      }
    }
    a >>= 1;
    i++;
  }
  AFXS16 *b = (AFXS16 *)Stream;

  for (AFXU32 i = 0; i < BufferLen; i++) {
    AFXF64 l = MixBuffer[(i << 1) + 0] * MasterVol[0];
    AFXF64 r = MixBuffer[(i << 1) + 1] * MasterVol[1];
    if (l < -0x8000)
      l = -0x8000;
    else if (l > 0x7fff)
      l = 0x7fff;
    if (r < -0x8000)
      r = -0x8000;
    else if (r > 0x7fff)
      r = 0x7fff;
    b[(i << 1) + 0] = l;
    b[(i << 1) + 1] = r;
  }

  // SysODS("%08x %08x %08x\n",Active,FadeOn,FadeOff);
  return 0;
}

AFXF64 AFXEnvADSR(AFXF64 a, AFXF64 d, AFXF64 s, AFXF64 r, AFXF64 t) {
  if (t < a)
    return t / a;
  t -= a;
  if (t < d)
    return 1 + (t / d) * (s - 1);
  t -= d;
  AFXF64 h = (1 - (a + d + r));
  if (t < h)
    return s;
  t -= h;
  if (t < r)
    return (1 - t / r) * s;
  return 0;
}

AFXF64 AFXModSine(AFXF64 f, AFXF64 t) {
  const AFXF64 pi2 = acosf(-1) * 2;
  return sinf(t * f * pi2);
}

AFXF64 AFXModSquare(AFXF64 f, AFXF64 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return -1;
  else
    return 1;
}

AFXF64 AFXModPulse(AFXF64 f, AFXF64 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return 0;
  else
    return 1;
}

AFXF64 AFXModTri(AFXF64 f, AFXF64 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return (-1 + 2 * (t / 0.5f));
  else
    return (1 - 2 * ((t - 0.5f) / 0.5f));
}

AFXF64 AFXModSaw(AFXF64 f, AFXF64 t) {
  t = fmodf(f * t, 1);
  return (-1 + 2 * t);
}

AFXF64 AFXModOne(AFXF64 f, AFXF64 t) { return 1; }

AFXU32 Hash(AFXU32 Index) { return SysRNG(); };
AFXF64 AFXNoise(AFXU32 s, AFXF64 x) {
  SysAssert(x >= 0);
  AFXS32 xi[2] = {(AFXS32)x, (AFXS32)(x + 1)};
  x -= xi[0];
  AFXU32 h[2] = {Hash((s << 16) + xi[0]) & 0xffff,
                 Hash((s << 16) + xi[1]) & 0xffff};
  AFXF64 l[2] = {-1.0f + h[0] * 2.0f / 0xffff, -1.0f + h[1] * 2.0f / 0xffff};
  return l[0] + (1 - x) * (l[1] - l[0]);
}

AFXF64 AFXModNoise(const AFXF64 f, AFXF64 t) { return AFXNoise(0, t * f); }

AFXF64 AFXFToRC(AFXF64 f) { return 1.0f / (2.0f * acosf(-1) * f); }

AFXF64 AFXHighPassFilter(AFXF64 RC, AFXF64 s, AFXF64 t) {
  static AFXF64 LastO = 0, LastS = 0, LastT = 0;
  AFXF64 o;
  if (t <= 0)
    o = s;
  else {
    AFXF64 dt = t - LastT, ds = s - LastS;
    AFXF64 a = RC / (RC + dt);
    o = a * (LastO + ds);
  }
  LastO = o;
  LastS = s;
  LastT = t;
  return o;
}

AFXF64 AFXLowPassFilter(AFXF64 RC, AFXF64 s, AFXF64 t) {
  static AFXF64 LastO = 0, LastT = 0;
  AFXF64 o;
  if (t <= 0)
    o = s;
  else {
    AFXF64 dt = t - LastT;
    AFXF64 a = dt / (RC + dt);
    o = LastO + a * (s - LastO);
  }
  LastO = o;
  LastT = t;
  return o;
}

AFXF64 TestFX(AFXF64 t) {
  const AFXF64 RC = AFXFToRC(8000);
  AFXF64 o = AFXModSine(800, t);
  o = AFXHighPassFilter(RC, o, t);
  return o;
}

AFXS32 AFXSyn(AFXU32 Flags, AFXSynFn Fn, AFXF64 *Sam, AFXS32 Samples,
              AFXS16 *Sam16) {
  SysAssert(Sam);

  if (!(Flags & AFXSynAdd))
    for (AFXS32 i = 0; i < Samples; i++)
      Sam[i] = 0;

  for (AFXS32 i = 0; i < Samples; i++) {
    Sam[i] += Fn(((AFXF64)i) / Samples);
  }

  if (Flags & AFXSynClip) {
    for (AFXS32 i = 0; i < Samples; i++)
      if (Sam[i] > 1)
        Sam[i] = 1;
      else if (Sam[i] < -1)
        Sam[i] = -1;
  }

  if (Flags & AFXSynFit) {
    AFXF64 m[2] = {0, 0};
    for (AFXS32 i = 0; i < Samples; i++)
      if (Sam[i] > m[1])
        m[1] = Sam[i];
      else if (Sam[i] < m[0])
        m[0] = Sam[i];
    for (AFXS32 i = 0; i < Samples; i++)
      Sam[i] = -1 + 2 * ((Sam[i] - m[0]) / (m[1] - m[0]));
  }

  if (Flags & AFXSyn2S16) {
    SysAssert(Sam16);
    for (AFXS32 i = 0; i < Samples; i++)
      Sam16[i] = 0x7fff * Sam[i];
  }

  return 0;
}

void Limit(AFXF64 *v, AFXF64 *o, AFXF64 l);
AFX3DS AFX3DListener = {0, 0, 0, 0};
AFXS32 AFX3D(AFXU32 Flags, AFXS32 Channel, AFX3DS *Source, AFXF64 Volume) {
  if (Channel < 0)
    return Channel;
  /*
SysAssert(Source);
SysAssert(Source->Pos);
SysAssert(AFX3DListener.Pos);
AFXF64 v[3];
V3Copy(v, Source->Pos);
if (Flags & AFX3DWrap)
Limit(v, AFX3DListener.Pos, AFX3DListener.Radius);
V3Sub(v, v, AFX3DListener.Pos);
AFXF64 d = V3Len(v);
d = 1 - d / Source->Radius;
d = d * d * d;
d = d * Volume;
if (d < 0)
d = 0;
else if (d > 1)
d = 1;
AFXVol(Channel, d, d);
*/
  return Channel;
}

AFXF64 ThrustFX2(AFXF64 t) {
  AFXF64 ft = t, bf = 880 * 8;
  return (AFXModNoise(bf, ft) * 0.7f + AFXModNoise(bf * 1.5f, ft) * 0.3f) *
         AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.1f, t) * 0.5f;
}

AFXF64 ThrustFX(AFXF64 t) {
  AFXF64 w = AFXModSine(500, t) * AFXModNoise(1000, t);
  return w;
}

AFXF64 LaserFX(AFXF64 t) {
  return AFXModSaw(220 * (1 + AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.9f, t)), t) *
         AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.1f, t);
}

AFXF64 UFOFX(AFXF64 t) {
  return AFXModTri(50 * (1 + 2 * AFXEnvADSR(0.5f, 0.0f, 1.0f, 0.5f, t)), t);
}

AFXF64 BumpFX(AFXF64 t) {
  AFXF64 f = 100;
  return AFXModNoise(3 * f, t) * AFXModSquare(f, t);
}

AFXF64 ExplosionFX(AFXF64 t) {
  AFXF64 f = 100;
  return AFXModNoise(3 * f, t) * AFXModTri(f, t);
}

AFXF64 HyperFX(AFXF64 t) {
  AFXF64 af;
  af = 0.6f + 0.4f * AFXModSine(20, t);
  return AFXModSine(110, af * t) * AFXEnvADSR(0.1f, 0.0f, 1.0f, 0.9f, t);
}

AFXF64 BonusFX(AFXF64 t) {
  AFXF64 p = fmod(t * 8, 1);
  if (p < 0.5f)
    p = 1;
  else
    p = 0;
  return AFXModSine(440 * 8, t) * p;
}

AFXF64 TriFX(AFXF64 t) { return AFXModTri(1, t); }

AFXS32 FXPlay(AFXS32 Channel, AFXU32 State, AFXS32 Effect, AFXF64 Freq,
              AFXU32 ChannelMask) {
  // if(Effect!=FXThrust) return -1;// else Effect=FXBump;
  enum { FXSamples = 16 * 1024, f = FXSamples };
  static const struct AFXS {
    AFXSynFn Function;
    AFXF64 Freq;
    AFXS32 SamLen;
    AFXF64 Secs;
    AFXU32 Flags;
    AFXF64 AttackS, ReleaseS;
    AFXS32 EnvelopeLen;
    AFXF64 AttackEnveLope[3 * 2], ReleaseEnvelope[3 * 2];
  } Patch[FXMax] = {
      {ThrustFX,
       f * 1.0f,
       FXSamples,
       3,
       (AFXSynClip | AFXSyn2S16),
       2,
       2,
       3,
       {0, 0, 0.5f, 0.5f, 1, 1},
       {0, 1, 0.5f, 0.5f, 1, 0}},

      {LaserFX, f, FXSamples, 1, (AFXSynClip | AFXSyn2S16), AFXNoAttack,
       AFXNoRelease, 0},

      {UFOFX,
       f * 3,
       FXSamples,
       7,
       (AFXSynClip | AFXSyn2S16),
       5,
       2,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {ExplosionFX,
       f,
       FXSamples,
       1,
       (AFXSynClip | AFXSyn2S16),
       1,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {HyperFX,
       f / 3.0f,
       FXSamples,
       3,
       (AFXSynClip | AFXSyn2S16),
       0,
       0,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {BonusFX,
       f / 2.0f,
       FXSamples,
       2,
       (AFXSynClip | AFXSyn2S16),
       1,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {BumpFX,
       f,
       FXSamples,
       1,
       (AFXSynClip | AFXSyn2S16),
       1,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
      {TriFX,
       f,
       FXSamples,
       3600,
       (AFXSynClip | AFXSyn2S16),
       0.01f,
       1,
       2,
       {0, 0, 1, 1},
       {0, 1, 1, 0}},
  };
  static AFXS16 Sam[FXMax][FXSamples];
  static AFXU32 Flags = 0;

  if (!Flags) {
    AFXF64 *Work = SysNew(AFXF64, FXSamples);
    for (AFXU32 i = 0; i < FXMax; i++) {
      AFXSyn(Patch[i].Flags, Patch[i].Function, Work, Patch[i].SamLen, Sam[i]);
    }
    SysDelete(Work);
    Flags = 1;
  }

  SysAssert((Effect >= 0) && (Effect < FXMax));
  int c = Channel;
  if (State == FXStart) {
    if (c >= 0)
      if (Active & (1 << c))
        return -1;
    c = AFXFirstFreeChannel(ChannelMask);

    if (c < 0)
      return 0;
    AFXF64 fxf = Patch[Effect].Freq;
    if (Freq < 0)
      fxf = -fxf * Freq;
    else
      fxf = Freq;
    AFXSam(c, fxf, AFXFmtS16, Sam[Effect], Patch[Effect].SamLen,
           Patch[Effect].Secs);
    AFXAttack(c, &Patch[Effect].AttackEnveLope[0], Patch[Effect].EnvelopeLen,
              Patch[Effect].AttackS);
    AFXRelease(c, &Patch[Effect].ReleaseEnvelope[0], Patch[Effect].EnvelopeLen,
               Patch[Effect].ReleaseS);
    AFXVol(c, 1, 1);
    AFXActivate(c);
    return c;
  }

  if (c < 0)
    return c;

  SysAssert(c < 32);

  if (State == FXFadeOff) {
    AFXDeActivate(c);
    c = -1;
    return c;
  }

  if (State == FXFinish) {
    AFXDeActivate(c);
    c = -1;
    c = -1;
    return c;
  }

  if (State == FXOff) {
    AFXDeActivate(c);
    c = -1;
    return c;
  }

  return -1;
}
