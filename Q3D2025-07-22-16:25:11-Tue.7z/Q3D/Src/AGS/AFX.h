/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#ifndef _AFX_H_GS_2011_
#define _AFX_H_GS_2011_

#ifdef __cplusplus
extern "C" {
#endif

typedef char AFXC8;
typedef unsigned char AFXU8;
typedef signed char AFXS8;
typedef unsigned short AFXU16;
typedef signed short AFXS16;
typedef unsigned int AFXU32;
typedef signed int AFXS32;
typedef unsigned long long AFXU64;
typedef signed long long AFXS64;
typedef float AFXF32;
typedef double AFXF64;

typedef void *(*AFX_MALLOC)(AFXU32 Size, const AFXC8 *SrcFileName,
                            AFXU32 SrcLineNumber);
typedef void (*AFX_FREE)(void *Memory, const AFXC8 *SrcFileName,
                         AFXU32 SrcLineNumber);
typedef AFXS32 (*AFX_FILELOAD)(const AFXC8 *FileName, void *Buffer,
                               AFXU32 BufferSize, const AFXC8 *SrcFileName,
                               AFXU32 SrcLineNumber);
typedef AFXS32 (*AFX_FILESIZE)(const AFXC8 *FileName, const AFXC8 *SrcFileName,
                               AFXU32 SrcLineNumber);

enum {
  AFXMaxChannels = 32,
  AFXFmtS16 = 0,
  AFXNoAttack = 0,
  AFXNoRelease = 0,
  AFXNoLoopStart = -1,
  AFXEnd
};
AFXU32 AFXActive(void);
AFXS32 AFXSam(AFXS32 Channel, AFXF64 FreqSamplesPerSecond, AFXU32 SamFmt,
              void *SamMem, AFXS32 SamEnd,
              AFXF64 PlaySecondsNgvIsNumberOfTimesToPlay);
AFXS32 AFXSetCurrentOffset(AFXS32 Channel, AFXS32 Offset);
AFXS32 AFXGetCurrentOffset(AFXS32 Channel);
AFXS32 AFXFreq(AFXS32 Channel, AFXF64 FreqSamplesPerSecond);
AFXS32 AFXVol(AFXS32 Channel, AFXF64 Left, AFXF64 Right);
AFXS32 AFXMasterVol(AFXF64 Left, AFXF64 Right);
AFXS32 AFXActivate(AFXS32 Channel);
AFXS32 AFXAttack(AFXS32 Channel, const AFXF64 *Envelope, AFXS32 EnvelopeLength,
                 AFXF64 Seconds);
AFXS32 AFXRelease(AFXS32 Channel, const AFXF64 *Envelope, AFXS32 EnvelopeLength,
                  AFXF64 Seconds);
AFXS32 AFXDeActivate(AFXS32 Channel);
AFXS32 AFXFirstFreeChannel(AFXU32 Mask);

AFXS32 AFXLoadWav(const AFXC8 *FileName, AFXS16 *SamMem);

AFXF64 AFXEnvADSR(AFXF64 a, AFXF64 d, AFXF64 s, AFXF64 r, AFXF64 t);
AFXF64 AFXModSine(AFXF64 f, AFXF64 t);
AFXF64 AFXModPulse(AFXF64 f, AFXF64 t);
AFXF64 AFXModSquare(AFXF64 f, AFXF64 t);
AFXF64 AFXModTri(AFXF64 f, AFXF64 t);
AFXF64 AFXModSaw(AFXF64 f, AFXF64 t);
AFXF64 AFXModNoise(AFXF64 f, AFXF64 t);
AFXF64 AFXModOne(AFXF64 f, AFXF64 t);
AFXF64 AFXFToRC(AFXF64 f);
AFXF64 AFXHighPassFilter(AFXF64 RC, AFXF64 s, AFXF64 t);
AFXF64 AFXLowPassFilter(AFXF64 RC, AFXF64 s, AFXF64 t);

enum {
  AFXSynAdd = (1 << 8),
  AFXSynClip = (1 << 9),
  AFXSynFit = (1 << 10),
  AFXSyn2S16 = (1 << 11),
  AFXSynEnd
};
typedef AFXF64 (*AFXSynFn)(AFXF64 t);
AFXS32 AFXSyn(AFXU32 Flags, AFXSynFn Fn, AFXF64 *Sam, AFXS32 Samples,
              AFXS16 *Sam16);

typedef struct AFX3DS {
  AFXF64 *Pos, *Vel, *Up, Radius;
} AFX3DS;
extern AFX3DS AFX3DListener;
enum { AFX3DWrap = (1 << 0), AFX3DEnd };
AFXS32 AFX3D(AFXU32 Flags, AFXS32 Channel, AFX3DS *Source, AFXF64 Volume);

enum {
  FXOff,
  FXStart,
  FXFinish,
  FXFadeOff,
  FXThrust = 0,
  FXLaser,
  FXMAN,
  FXExplosion,
  FXHyper,
  FXBonus,
  FXBump,
  FXTest,
  FXMax
};
AFXS32 FXPlay(AFXS32 ID, AFXU32 State, AFXS32 Effect,
              AFXF64 FrequencyNgvForXDefault, AFXU32 ChannelMask);

#ifdef __cplusplus
}
#endif
#endif
