
#ifdef SYS_NS
#undef C8
#undef U8
#undef S8
#undef U16
#undef S16
#undef U32
#undef S32
#undef U64
#undef S61
#undef F32
#undef F64
#undef SYS_NS
#else
#error Not currently in SYSNS!
#endif
