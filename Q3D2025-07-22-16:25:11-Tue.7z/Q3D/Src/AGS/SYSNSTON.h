
#ifdef SYS_NS
#error Already is SysNS!
#else
#define C8 SysC8
#define U8 SysU8
#define S8 SysS8
#define U16 SysU16
#define S16 SysS16
#define U32 SysU32
#define S32 SysS32
#define U64 SysU64
#define S61 SysS64
#define F32 SysF32
#define F64 SysF64
#define SYS_NS
#endif
