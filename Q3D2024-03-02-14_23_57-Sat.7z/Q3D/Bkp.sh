#!/bin/sh
rm -r .vscode
rm Q3D
rm Q3DWeb/*.*
rm Logs/*.*
D=$(date +"%Y-%m-%d-%T-%a")
#rsync -rbvu --backup-dir=Q3DBkp$D ~/Q3D ~/Bkp
#tar -cJvf ../Bkp$D.tar.xz ../Bkp/
# tar -cJvf ../Q3D$D.tar.xz ../Q3D
7z a ../Q3D$D.7z ../Q3D
