
/*
BMF Font Binary Format Reader
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "BMF.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *BMFBlockType[] = {
    "ZERO",
    "BMF_BLOCK_TYPE_INFO",
    "BMF_BLOCK_TYPE_COMMON",
    "BMF_BLOCK_TYPE_PAGE",
    "BMF_BLOCK_TYPE_CHAR",
    "BMF_BLOCK_TYPE_KERNING",
};

BMF BMFParse(BMFC8 *BMFInMemory,BMFU32 BMFBytes, BMFU32 ToStdout)
{
  BMF BMFOut;
  int l;
  BMFU32 o=ToStdout;
  char *t, *p = BMFInMemory, *e=p+BMFBytes;
  BMF_HEADER *h = (BMF_HEADER *)p;
  assert((h->ID[0]) == 'B');
  assert((h->ID[1]) == 'M');
  assert((h->ID[2]) == 'F');
  assert(h->Version == 3);
  BMFOut.Header = h;

  p += sizeof(BMF_HEADER);

  if (o)
    printf("BMF Font Version:%d\n", h->Version);

  while (p<e) {
    BMF_BLOCK *b = (BMF_BLOCK *)p;
    printf("\nBlock: Type:%s Bytes:%d 0x%x\n", BMFBlockType[b->Type],
            b->Bytes, b->Bytes);
    assert(b->Type >= BMF_BLOCK_TYPE_START);
    assert(b->Type < BMF_BLOCK_TYPE_END);
    p += sizeof(BMF_BLOCK);
    int nb = b->Bytes;
    switch (b->Type) {
    case BMF_BLOCK_TYPE_INFO: {
      BMF_INFO *info;
      info = BMFOut.Info = (BMF_INFO *)p;
      if (o)
        printf(
                "Font Size:%d BitField:0x%x CharSet:%d StretchH:%d AA:%d "
                "PadU:%d PadR:%d PadD:%d PadL:%d SpacingH:%d SpacingV:%d "
                "Outline:%d FontName:%s\n",
                info->FontSize, info->Bits_SUIBFRRR, info->CharSet,
                info->StretchH, info->AA, info->PaddingUp, info->PaddingRight,
                info->PaddingDown, info->PaddingLeft, info->SpacingHoriz,
                info->SpacingVert, info->Outline, info->FontName);
    } break;
    case BMF_BLOCK_TYPE_COMMON: {
      BMF_COMMON *cm;
      cm = BMFOut.Common = (BMF_COMMON *)p;
      if (o)
        printf(
                "Line Height:%d Base:%d ScaleW:%d ScaleH:%d Pages:%d "
                "BitField:0x%x A:%d R:%d G:%d B:%d\n",
                cm->LineHeight, cm->Base, cm->SclW, cm->SclH, cm->Pages,
                cm->Bits_RRRRRRRP, cm->AChannel, cm->RChannel, cm->GChannel,
                cm->BChannel);
    } break;
    case BMF_BLOCK_TYPE_PAGES: {
      int pgno = 0;
      t = p;
      while (nb > 0) {
        BMFOut.Page[pgno] = (BMF_PAGE)t;
        if (o)
          printf( "%s\n", BMFOut.Page[pgno]);
        l = strlen(BMFOut.Page[pgno])+1;
        nb -= l;
        t += l;
        pgno++;
      }
      BMFOut.Pages=pgno;
    } break;
    case BMF_BLOCK_TYPE_CHARS: {
      BMF_CHARS *ch;
      ch = BMFOut.Chars = (BMF_CHARS *)p;
      BMFOut.Characters = 0;
      for (int i = 0; i < (nb / sizeof(BMF_CHARS)); i++) {
        {
          BMF_CHARS *ch = &BMFOut.Chars[i];
          if (o)
            printf(
                    "ID:%3d(%c) X:%4d Y:%4d W:%4d H:%4d XO:%4d YO:%4d XAdv:%4d Page:%d "
                    "Chnl:%d\n",
                    ch->ID,((ch->ID-32)%(128-32))+32, ch->X, ch->Y, ch->Width, ch->Height, ch->XOffset,
                    ch->YOffset, ch->XAdvance, ch->Page, ch->Channel);
          BMFOut.Characters++;
        }
      }
    } break;
    case BMF_BLOCK_TYPE_KERNING: {
      BMF_KERNING *kn;
      BMFOut.Kernings = 0;
      kn = BMFOut.Kerning = (BMF_KERNING *)p;
      for (int i = 0; i < (nb / sizeof(BMF_KERNING)); i++) {
        if (o)
          printf( "First:%d Second:%d Amount:%d\n", kn->First, kn->Second,
                  kn->Amount);
        BMFOut.Kernings++;
      }
    } break;
    }
    p += b->Bytes;
  }
  if (o)
    fflush(stdout);
  return BMFOut;
}

#ifdef BMF_CREATE_CLI

int main(int argc, char *v[]) {
  if (argc != 2) {
    printf("BMF <BMF Font File> (C) GS 2024\n");
    exit(1);
  }
  FILE *f;
  int l;
  f = fopen(v[1], "rb");
  assert(f);
  fseek(f, 0, SEEK_END);
  l = ftell(f);
  void *m = malloc(l);
  fseek(f, 0, SEEK_SET);
  int r = fread(m, 1, l, f);
  assert(r == l);
  BMFParse(m, l, 1);
  free(m);
  return 0;
}
#endif
