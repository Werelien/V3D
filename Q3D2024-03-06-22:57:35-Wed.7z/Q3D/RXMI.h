
/*
RXMI Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/

typedef char RXMIC8;
typedef unsigned char RXMIU8;
typedef signed char RXMIS8;
typedef unsigned short RXMIU16;
typedef signed short RXMIS16;
typedef unsigned int RXMIU32;
typedef signed int RXMIS32;
typedef unsigned long long RXMIU64;
typedef signed long long RXMIS64;
typedef float RXMIF32;
typedef double RXMIF64;

enum {
  RXMI_WICKI_HAYDEN = 0,

  RXMI_CAPSLOCK = 128, // @
  RXMI_RSHIFT,         // A
  RXMI_LSHIFT,         // B
  RXMI_RCTRL,          // C
  RXMI_LCTRL,          // D
  RXMI_RALT,           // E
  RXMI_LALT,           // F
  RXMI_RMETA,          // G
  RXMI_LMETA,          // H
  RXMI_LSUPER,         // I
  RXMI_RSUPER,         // J
  RXMI_MODE,           // K
  RXMI_COMPOSE,        // L
  RXMI_UP,             // M
  RXMI_DOWN,           // N
  RXMI_RIGHT,          // O
  RXMI_LEFT,           // P
  RXMI_INSERT,         // Q
  RXMI_HOME,           // R
  RXMI_END,            // S
  RXMI_PAGEUP,         // T
  RXMI_PAGEDOWN,       // U
  RXMI_BACKSPACE,      // V
  RXMI_TAB,            // W
  RXMI_CLEAR,          // X
  RXMI_RETURN,         // Y
  RXMI_PAUSE,          // Z
  RXMI_ESCAPE,         //[
  RXMI_DELETE,         // Backslash
  RXMI_F1,             //]
  RXMI_F2,             //^
  RXMI_F3,             //_
  RXMI_F4,             //`
  RXMI_F5,             // a
  RXMI_F6,             // b
  RXMI_F7,             // c
  RXMI_F8,             // d
  RXMI_F9,             // e
  RXMI_F10,            // f
  RXMI_F11,            // g
  RXMI_F12,            // h

  RXMI_KEYS_MAX = 256,
  RXMI_KEYS_END,

  RXMIMOTIONSTATE_FLATTEN = (1 << 0),
  RXMIMOTIONSTATE_SHARPEN = (1 << 1),
  RXMIMOTIONSTATE_VDXOFF = (1 << 2),
  RXMIMOTIONSTATE_PDYOFF = (1 << 3),

};
typedef struct RXMISTATUS {
  RXMIS32 T[256], Octave, NoteOffset;
  RXMIF64 Velocity, PitchShift;
  RXMIU64 SequenceActive;
} RXMISTATUS;
extern RXMISTATUS RXMI;
typedef struct RXMINOTESTATE {
  RXMIU64 On; // 1 On 0 Off Rest Reserved
  RXMIF64 TimeStamp, Freq;
  RXMIF64 VelocityUsed;
  RXMIU8 Note, Octave;
  // Octave is MIDI Note Octave which is standard English
  // notation +1 ie standard A4 440Hz Concert Pitch would
  // be here as MIDI A5(5*12+9=Midi Note 69) 440Hz

} RXMINOTESTATE;
extern RXMINOTESTATE RXMI_MidiNoteStatus[128];
RXMIS64 RXMI_Open(RXMIU64 Flags);
RXMIS64 RXMI_KeyOn(RXMIS64 Key, RXMIF64 Time);
RXMIS64 RXMI_KeyOff(RXMIS64 Key, RXMIF64 Time);
RXMIS64 RXMI_Motion(RXMIS64 State, RXMIF64 VDX, RXMIF64 PDY, RXMIF64 Time);
RXMIS64 RXMI_Close(void);
RXMIF64 RXMI_MIDINoteToHz(RXMIU8 MIDINote);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
#define RXMI_IMPLEMENTATION
#ifdef RXMI_IMPLEMENTATION

#define RXMI_DEBUG
#ifdef RXMI_DEBUG
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#define RXMIAssert(exp) assert(exp)
#define RXMIODS(...) printf(__VA_ARGS__)
#else
#define RXMIAssert(exp)
#define RXMIODS(...)
#endif

RXMINOTESTATE RXMI_MidiNoteStatus[128] = {[0 ... 127] = {0}};
RXMIF64 RXMI_MIDINoteToHz(RXMIU8 MIDINote) {
  MIDINote = MIDINote > 127 ? 127 : MIDINote;
  return 440.0 * pow(2, (MIDINote - 69.0) / 12.0);
}

RXMISTATUS RXMI = {{[0 ... 255] = -1}, 0, 0, 0};

static const char *RXMINote[12] = {"C-", "C#", "D-", "D#", "E-", "F-",
                                   "F#", "G-", "G#", "A-", "A#", "B-"};
static RXMIS8 RXMI_KeysMidiNote(RXMIU8 Key) {

  int n = RXMI.T[Key];
  if (n < 0)
    return n;
  n += RXMI.Octave * 12 + RXMI.NoteOffset;
  if (n > 127)
    n = 127;
  return n;
}
RXMIS64 RXMI_Open(RXMIU64 Flags) {
  RXMI.Octave = 5;
  RXMI.NoteOffset = 0;
  RXMIODS("Octave:%d Note:%s(%d)\n\n", RXMI.Octave, RXMINote[RXMI.NoteOffset],
          RXMI.NoteOffset);
  const char *kb[4] = {
      " ` 1 2 3 4 5 6 7 8 9 0 - = V", "W q w e r t y u i o p [ ] Y",
      " @ a s d f g h j k l ; ' # ", "B \\ z x c v b n m , . / A "};
  RXMIS64 o[4] = {12 + 5, 12, 7, 0};
  for (int i = 0; i < 4; i++) {
    const char *s = kb[i];
    int n = 0;
    if (~i & 1)
      RXMIODS("   ");
    for (int j = 0; s[j]; j++) {
      if (s[j] != ' ') {
        int midin = RXMI.T[s[j]] = o[i] + n * 2;
        midin += RXMI.Octave * 12 + RXMI.NoteOffset;
        n++;
        int ocn = midin / 12;
        midin %= 12;
        RXMIODS("[%c:%s%d]", s[j], RXMINote[midin], ocn);
      } else
        RXMIODS(" ");
    }
    RXMIODS("\n");
  }
  return 0;
}
static RXMIS64 RXMI_TranslateKey(RXMIS64 Key) {
  if (Key < 32)
    return -1;
  if (Key >= 128) {
    Key -= 128;
    if (Key >= 32)
      return -1;
    Key += '@';
    if (Key > 'h')
      return -1;
    if (Key >= ']')
      return -1;
    switch (Key) {
    case '[':
      Key = '{';
      break;
    case ']':
      Key = '}';
      break;
    case '\\':
      Key = '|';
      break;
    }
  }
  return Key;
}
static void RXMI_Normalise(void) {
  if (RXMI.NoteOffset < 0) {
    RXMI.NoteOffset = 11;
    RXMI.Octave--;
  }
  if (RXMI.NoteOffset > 11) {
    RXMI.NoteOffset = 0;
    RXMI.Octave++;
  }
  if (RXMI.Octave < 0)
    RXMI.Octave = 11;
  if (RXMI.Octave > 11)
    RXMI.Octave = 0;
}
RXMIS64 RXMI_KeyOn(RXMIS64 Key, RXMIF64 Time) {
  RXMIS64 k = RXMI_TranslateKey(Key);
  if (k < 0)
    return -1;
  if ((k >= 'M') && (k <= 'P')) {
    RXMIODS("Octave:%d NoteOffset:%d ", RXMI.Octave, RXMI.NoteOffset);
    RXMIODS("[%s%d] =>", RXMINote[RXMI.NoteOffset], RXMI.Octave);
    switch (k) {
    case 'M':
      RXMI.Octave++;
      break;
    case 'N':
      RXMI.Octave--;
      break;
    case 'O':
      RXMI.NoteOffset++;
      break;
    case 'P':
      RXMI.NoteOffset--;
      break;
    }
    RXMI_Normalise();
    RXMIODS("Octave:%d NoteOffset:%d ", RXMI.Octave, RXMI.NoteOffset);
    RXMIODS("[%s%d]\n", RXMINote[RXMI.NoteOffset], RXMI.Octave);
    return -1;
  }
  RXMIODS("RXMI KeyOn: %08llx 0X%02llX '%c'", Key, k, (RXMIC8)k);
  int n = RXMI_KeysMidiNote(k);
  if (n >= 0) {
    RXMIU8 ocn = n / 12;
    RXMIU8 ncn = n % 12;
    RXMIF64 f = RXMI_MIDINoteToHz(n);
    RXMIODS("[%c:%s%d](%d:%fHz)\n", (char)k, RXMINote[ncn], ocn, n, f);
    RXMI_MidiNoteStatus[n].On = 1;
    RXMI_MidiNoteStatus[n].TimeStamp = Time;
    RXMI_MidiNoteStatus[n].Freq = f;
    RXMI_MidiNoteStatus[n].VelocityUsed = RXMI.Velocity;
    RXMI_MidiNoteStatus[n].Note = ncn;
    RXMI_MidiNoteStatus[n].Octave = ocn;
    return n;
  } else
    RXMIODS("\n");
  return -1;
}
RXMIS64 RXMI_KeyOff(RXMIS64 Key, RXMIF64 Time) {
  if (Key < 0)
    return -1;
  RXMIS64 k = RXMI_TranslateKey(Key);
  if (k < 0)
    return -1;
  RXMIODS("RXMI KeyOff: %08llx 0X%02llX '%c'\n", Key, k, (RXMIC8)k);
  int n = RXMI_KeysMidiNote(k);
  RXMI_MidiNoteStatus[n].On = 0;
  RXMI_MidiNoteStatus[n].TimeStamp = Time;
  return n;
}
RXMIS64 RXMI_Close(void) { return 0; }

#endif
