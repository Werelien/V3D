#!/bin/sh
./Q3D
