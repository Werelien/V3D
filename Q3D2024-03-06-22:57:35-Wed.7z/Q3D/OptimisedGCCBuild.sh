#!/bin/sh
rm Q3D
make -j8
ls -al Q3D
strip Q3D
echo "...Stripped..."
ls -al Q3D



