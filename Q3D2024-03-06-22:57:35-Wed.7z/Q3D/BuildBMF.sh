#!/bin/sh
tcc -DBMF_CREATE_CLI -Ofast -oBMF BMF.c
ls -al BMF
strip BMF
echo "...Stripped..."
ls -al BMF
