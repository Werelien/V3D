/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#include "SFX.h"
#include "GFX.h"
#include "SYS.h"
#include <math.h>

static SysU32 Active = 0;
static SysF32 MasterVol[2] = {1, 1};


SysU8 *MemCpy(SysU8 *d, const SysU8 *s, SysU32 l) {
  for (SysU32 i = 0; i < l; i++)
    d[i] = s[i];
  return d;
}

SysS32 MemRead(SysU8 *b, SysU32 l, const SysU8 *s, SysU32 sl, SysU32 *so) {
  if ((so[0] + l) > sl)
    l = sl - so[0];
  MemCpy(b, &s[so[0]], l);
  so[0] += l;
  return l;
}

SysS32 MemWrite(const SysU8 *b, SysU32 l, SysU8 *m, SysU32 ml, SysU32 *mo) {
  SysAssert((mo[0] + l) <= ml);
  MemCpy(&m[mo[0]], b, l);
  mo[0] += l;
  return l;
}

static struct SFXS {
  SysU32 Fmt;
  SysS32 AttackEnvelopeLen,ReleaseEnvelopeLen;
  void *Sam;
  const SysF32 *AttackEnvelope,*ReleaseEnvelope;
  SysF64 Freq, Vol[2], PlayForSecs, LenSecs,AttackSecs,ReleaseSecs;
  SysS64 End, LoopsCurrent, LoopRange, LoopRangeMask;
  SysF64 CurrentOffset;
} Ch[SFXMaxChannels];

SysS32 SFXFirstFreeChannel(SysU32 Mask) {
  SysU32 na = (~Active) & Mask;
  if (!na)
    return -1;

  SysU32 i = 0, a = Active | (~Mask);
  while (na) {
    if (na & 1)
      return i;
    na >>= 1;
    i++;
  }
  return -1;
}

SysS32 SFXSetCurrentOffset(SysS32 Channel, SysS32 Offset) {
  Ch[Channel].CurrentOffset = Offset;
  return 0;
}

SysS32 SFXGetCurrentOffset(SysS32 Channel) {
  return Ch[Channel].CurrentOffset;
  return 0;
}
SysS32 SFXSam(SysS32 Channel, SysF32 Freq, SysU32 SamFmt, void *SamMem,
              SysS32 SamEnd, SysF64 PlayForSeconds) {
  SysAssert(SamFmt == SFXFmtS16);
  SFXDeActivate(Channel);
  SysF64 LengthInSeconds = ((SysF64)(SamEnd)) / Freq;
  if (PlayForSeconds < 0) {
    PlayForSeconds = -PlayForSeconds*((SysF64)(SamEnd)) / Freq;
  }
  SysS64 r = SamEnd;
  SysAssert(!(r & (r - 1)));
  Ch[Channel].Fmt = SamFmt;
  SFXFreq(Channel,Freq);
  Ch[Channel].Sam = SamMem;
  Ch[Channel].End = SamEnd;
  Ch[Channel].PlayForSecs= PlayForSeconds;
  Ch[Channel].LenSecs = LengthInSeconds;
  Ch[Channel].LoopRange = r;
  Ch[Channel].LoopsCurrent = 0;
  Ch[Channel].LoopRangeMask = r - 1;
  Ch[Channel].ReleaseEnvelope = 0;
  Ch[Channel].AttackEnvelope = 0;
  Ch[Channel].AttackEnvelopeLen = 0;
  Ch[Channel].ReleaseEnvelopeLen = 0;
  Ch[Channel].AttackSecs = 0;
  Ch[Channel].ReleaseSecs = 0;

  return 0;
}

SysS32 SFXFreq(SysS32 Channel, SysF32 FreqSamplesPerSecond) {
  Ch[Channel].Freq = FreqSamplesPerSecond;
  return 0;
}

SysS32 SFXVol(SysS32 Channel, SysF32 Left, SysF32 Right) {
  Ch[Channel].Vol[0] = Left;
  Ch[Channel].Vol[1] = Right;
  return 0;
}

SysS32 SFXMasterVol(SysF32 Left, SysF32 Right) {
  MasterVol[0] = Left;
  MasterVol[1] = Right;
  return 0;
}

SysF32 VolumeOf(const SysF32 *Envelope,SysS32 Len,SysF32 LenS,SysF32 TimeS)
{
  if(!Len) return -1;
  SysAssert(Envelope);
  SysAssert(Len>=2);
  SysS32 l2=(Len<<1);
  if(TimeS>=LenS) return Envelope[l2-2+1];
  if(TimeS<=0) return Envelope[0];
  SysF32 t=TimeS/LenS;
  for(int i=0;i<(l2-2);i+=2)
  {
    if(t<=Envelope[i+2])
    {
      SysF32 dv = Envelope[i + 2+1] - Envelope[i+1],dt=Envelope[i+2]-Envelope[i];
      SysF32 v=Envelope[i+1] + (t - Envelope[i])*dv/dt;
      return v;
    }
  }
  return Envelope[l2-2+1];
}

SysS32 EnvelopeCheck(const SysF32 *m, SysU32 l,SysF32 S) {
  if(S<=0)
  {
    SysAssert(!l);
    return 0;
  }
  if(l<2) return -1;
  SysF32 lt = m[0];
  if(lt != 0) return -1;
  for (int i = 1; i < l; i++) {
    SysF32 ct = m[(i << 1)];
    if(ct <= lt) return -1;
    lt = ct;
  }
  if(lt != 1) return -1;
  return 0;
}

SysS32 SFXAttack(SysS32 Channel,const SysF32 *Envelope,SysS32 EnvelopeLength,SysF32 Seconds)
{
  Ch[Channel].AttackEnvelope=Envelope;
  Ch[Channel].AttackEnvelopeLen=EnvelopeLength;
  Ch[Channel].AttackSecs = Seconds;
  SysAssert((!Seconds)||(!EnvelopeCheck(Envelope, EnvelopeLength,Seconds)));
  return 0;
}
SysS32 SFXRelease(SysS32 Channel,const SysF32 *Envelope,SysS32 EnvelopeLength,SysF32 Seconds)
{
  Ch[Channel].ReleaseEnvelope=Envelope;
  Ch[Channel].ReleaseEnvelopeLen=EnvelopeLength;
  Ch[Channel].ReleaseSecs = Seconds;
  SysAssert((!Seconds)||(!EnvelopeCheck(Envelope, EnvelopeLength,Seconds)));
  return 0;
}
SysS32 SFXActivate(SysS32 Channel){
  Ch[Channel].CurrentOffset = 0;
  Active |= (1 << Channel);
  return 0;
}

SysS32 SFXDeActivate(SysS32 Channel) {

    Active &= ~(1 << Channel);
  return 0;
}

SysS32 SFXLoadWav(const SysC8 *FileName, SysS16 *SamMem) {
  SysAssert(SamMem);

  SysS32 l = SysLoad(0, FileName, 0, 0, 0);
  l -= 44;
  SysLoad(0, FileName, 44, l, SamMem);
  return l / 2;
}

SysS32 SFXMix(SysF32 *MixBuffer, SysS32 MixBufferLen, SysS32 c, SysS16 *Sam) {

  static SysU64 Counter = 0;
  static SysF64 maxt = 0, t = 0;
  SysU64 r = Ch[c].LoopRange, m = Ch[c].LoopRangeMask;
  SysF32 CurrentFadeV=1;

  t = SysSec();

  SysF64 period = Ch[c].Freq / SysAudioFreq;
  do {
    SysF64 TimePlayed = Ch[c].CurrentOffset / Ch[c].Freq;
    SysF64 TimeLeft = Ch[c].PlayForSecs - TimePlayed;

    SysS64 LenToEnd=MixBufferLen;
    if (TimeLeft <= 0) {
      if (Ch[c].ReleaseEnvelopeLen <= 0)
        return 1;
      if ((-TimeLeft) >= Ch[c].ReleaseSecs)
        return 1;
      CurrentFadeV = VolumeOf(Ch[c].ReleaseEnvelope, Ch[c].ReleaseEnvelopeLen,
                              Ch[c].ReleaseSecs, -TimeLeft);
      SysODS("Fade:RS:%f TP:%fS TL:%fS CF:%f\n", Ch[c].ReleaseSecs, TimePlayed,TimeLeft,
             CurrentFadeV);
      for (int i = 0; i < Ch[c].ReleaseEnvelopeLen; i++)
        SysODS("%d: %fS\n", Ch[c].ReleaseEnvelope[i]);
      if (CurrentFadeV < 0)
        return 1;
      LenToEnd=-TimeLeft*SysAudioFreq;
      if(LenToEnd<=0) return 1;
      if(LenToEnd>MixBufferLen) LenToEnd=MixBufferLen;
    // = TimeLeft * SysAudioFreq+32;
    } else if (Ch[c].AttackEnvelopeLen > 0) {
      CurrentFadeV = VolumeOf(Ch[c].AttackEnvelope, Ch[c].AttackEnvelopeLen,
                              Ch[c].AttackSecs, TimePlayed);
      SysODS("Fade:AS:%f TP:%fS TL:%fS CF:%f\n", Ch[c].AttackSecs, TimePlayed,TimeLeft,
             CurrentFadeV);
      for (int i = 0; i < Ch[c].AttackEnvelopeLen; i++)
        SysODS("%d: %fS\n", Ch[c].AttackEnvelope[i]);
      if (CurrentFadeV < 0)
        CurrentFadeV = 1;
    }


    SysU64 ranges = 0, offset, rm, shft = 20, mshft = (1 << shft),
           prd = period * mshft;
    SysF64 of = fmod(Ch[c].CurrentOffset, r),base=Ch[c].CurrentOffset-of;
    rm = (m << shft) | (mshft - 1);
    offset = of * mshft;
    SysF32 vl = Ch[c].Vol[0] * CurrentFadeV;
    SysF32 vr = Ch[c].Vol[1] * CurrentFadeV;
    for (SysS32 i = 0; i < LenToEnd; i++) {
      SysU64 oi = (offset & rm);
      SysU16 oii = oi >> shft;
      SysAssert((oii >= 0) && (oii < Ch[c].End));
      SysF32 s = Sam[oii];
      SysF32 l = s * vl;
      SysF32 r = s * vr;
      MixBuffer[(i << 1) + 0] += l;
      MixBuffer[(i << 1) + 1] += r;
      offset += prd;
    }

    Ch[c].CurrentOffset = offset;
    Ch[c].CurrentOffset /= mshft;
    Ch[c].CurrentOffset += base;

    MixBufferLen -= LenToEnd;
  } while (MixBufferLen > 0);
  t = SysSec() - t;
  if (t > maxt)
    maxt = t;
  Counter++;
#ifdef SYS_DEBUG_ODS
  // if (~(Counter & 1023))
  SysODS("SFXMix: CHM:%x CH:%d T:%fS Max:%f\n", Active, c, t, maxt);
#endif
  SysAssert(!MixBufferLen);
  return 0;
}

enum { MAX_MIX_BUFFER_LEN = 8 * 1024 * 2 };
static SysU32 MixBufferLen = MAX_MIX_BUFFER_LEN;
static SysF32 MixBuffer[MAX_MIX_BUFFER_LEN];
SysS32 SysUserAudio(SysU32 AudioFlags, SysU32 AudioFreq, SysU8 *Stream,
                    SysS32 Len) {
  // static SysU32 l=0;
  // SysU32 m=SysMs(),d=m-l;
  // if(!d) d=1;
  // SysODS("%d %d %x %d %d %d
  // %d\n",AudioFlags,AudioFreq,Stream,(Len*14)/4,d,1000/d,(Len*1000)/(d*4));
  // l=m;

  SysAssert( SysAudioFreq = AudioFreq);

  if (!Active) {
    for (SysS32 i = 0; i < (Len >> 2); i++)
      ((SysU32 *)Stream)[i] = 0;
    return 0;
  }

  SysU32 BufferLen = (Len >> 2);
  SysAssert(MixBufferLen >= BufferLen);

  for (SysU32 i = 0; i < (BufferLen << 1); i++)
    MixBuffer[i] = 0;

  SysU32 i = 0, a = Active;
  while (a) {
    if (a & 1) {
      SysS32 Finished;
      Finished = SFXMix(MixBuffer, BufferLen, i, (SysS16 *)(Ch[i].Sam));
      if (Finished) {
        SFXDeActivate(i);
      }
    }
    a >>= 1;
    i++;
  }
  SysS16 *b = (SysS16 *)Stream;

  for (SysU32 i = 0; i < BufferLen; i++) {
    SysF32 l = MixBuffer[(i << 1) + 0] * MasterVol[0];
    SysF32 r = MixBuffer[(i << 1) + 1] * MasterVol[1];
    if (l < -0x8000)
      l = -0x8000;
    else if (l > 0x7fff)
      l = 0x7fff;
    if (r < -0x8000)
      r = -0x8000;
    else if (r > 0x7fff)
      r = 0x7fff;
    b[(i << 1) + 0] = l;
    b[(i << 1) + 1] = r;
  }

  // SysODS("%08x %08x %08x\n",Active,FadeOn,FadeOff);
  return 0;
}

SysF32 SFXEnvADSR(SysF32 a, SysF32 d, SysF32 s, SysF32 r, SysF32 t) {
  if (t < a)
    return t / a;
  t -= a;
  if (t < d)
    return 1 + (t / d) * (s - 1);
  t -= d;
  SysF32 h = (1 - (a + d + r));
  if (t < h)
    return s;
  t -= h;
  if (t < r)
    return (1 - t / r) * s;
  return 0;
}

SysF32 SFXModSine(SysF32 f, SysF32 t) {
  const SysF32 pi2 = acosf(-1) * 2;
  return sinf(t * f * pi2);
}

SysF32 SFXModSquare(SysF32 f, SysF32 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return -1;
  else
    return 1;
}

SysF32 SFXModPulse(SysF32 f, SysF32 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return 0;
  else
    return 1;
}

SysF32 SFXModTri(SysF32 f, SysF32 t) {
  t = fmodf(f * t, 1);
  if (t < 0.5f)
    return (-1 + 2 * (t / 0.5f));
  else
    return (1 - 2 * ((t - 0.5f) / 0.5f));
}

SysF32 SFXModSaw(SysF32 f, SysF32 t) {
  t = fmodf(f * t, 1);
  return (-1 + 2 * t);
}

SysF32 SFXModOne(SysF32 f, SysF32 t) { return 1; }

SysU32 Hash(SysU32 Index) { return SysPRNG(0,0,Index,8); };
SysF32 SFXNoise(SysU32 s, SysF32 x) {
  SysAssert(x >= 0);
  SysS32 xi[2] = {(SysS32)x, (SysS32)(x + 1)};
  x -= xi[0];
  SysU32 h[2] = {Hash((s << 16) + xi[0]) & 0xffff,
                 Hash((s << 16) + xi[1]) & 0xffff};
  SysF32 l[2] = {-1.0f + h[0] * 2.0f / 0xffff, -1.0f + h[1] * 2.0f / 0xffff};
  return l[0] + (1 - x) * (l[1] - l[0]);
}

SysF32 SFXModNoise(const SysF32 f, SysF32 t) { return SFXNoise(0, t * f); }

SysF32 SFXFToRC(SysF32 f) { return 1.0f / (2.0f * acosf(-1) * f); }

SysF32 SFXHighPassFilter(SysF32 RC, SysF32 s, SysF32 t) {
  static SysF32 LastO = 0, LastS = 0, LastT = 0;
  SysF32 o;
  if (t <= 0)
    o = s;
  else {
    SysF32 dt = t - LastT, ds = s - LastS;
    SysF32 a = RC / (RC + dt);
    o = a * (LastO + ds);
  }
  LastO = o;
  LastS = s;
  LastT = t;
  return o;
}

SysF32 SFXLowPassFilter(SysF32 RC, SysF32 s, SysF32 t) {
  static SysF32 LastO = 0, LastT = 0;
  SysF32 o;
  if (t <= 0)
    o = s;
  else {
    SysF32 dt = t - LastT;
    SysF32 a = dt / (RC + dt);
    o = LastO + a * (s - LastO);
  }
  LastO = o;
  LastT = t;
  return o;
}

SysF32 TestFX(SysF32 t) {
  const SysF32 RC = SFXFToRC(8000);
  SysF32 o = SFXModSine(800, t);
  o = SFXHighPassFilter(RC, o, t);
  return o;
}

SysS32 SFXSyn(SysU32 Flags, SFXSynFn Fn, SysF32 *Sam, SysS32 Samples,
              SysS16 *Sam16) {
  SysAssert(Sam);

  if (!(Flags & SFXSynAdd))
    for (SysS32 i = 0; i < Samples; i++)
      Sam[i] = 0;

  for (SysS32 i = 0; i < Samples; i++) {
    Sam[i] += Fn(((SysF32)i) / Samples);
  }

  if (Flags & SFXSynClip) {
    for (SysS32 i = 0; i < Samples; i++)
      if (Sam[i] > 1)
        Sam[i] = 1;
      else if (Sam[i] < -1)
        Sam[i] = -1;
  }

  if (Flags & SFXSynFit) {
    SysF32 m[2] = {0, 0};
    for (SysS32 i = 0; i < Samples; i++)
      if (Sam[i] > m[1])
        m[1] = Sam[i];
      else if (Sam[i] < m[0])
        m[0] = Sam[i];
    for (SysS32 i = 0; i < Samples; i++)
      Sam[i] = -1 + 2 * ((Sam[i] - m[0]) / (m[1] - m[0]));
  }

  if (Flags & SFXSyn2S16) {
    SysAssert(Sam16);
    for (SysS32 i = 0; i < Samples; i++)
      Sam16[i] = 0x7fff * Sam[i];
  }

  return 0;
}

void Limit(SysF32 *v, SysF32 *o, SysF32 l);
SFX3DS SFX3DListener = {0, 0, 0, 0};
SysS32 SFX3D(SysU32 Flags, SysS32 Channel, SFX3DS *Source, SysF32 Volume) {
  if (Channel < 0)
    return Channel;
  /*
SysAssert(Source);
SysAssert(Source->Pos);
SysAssert(SFX3DListener.Pos);
SysF32 v[3];
V3Copy(v, Source->Pos);
if (Flags & SFX3DWrap)
Limit(v, SFX3DListener.Pos, SFX3DListener.Radius);
V3Sub(v, v, SFX3DListener.Pos);
SysF32 d = V3Len(v);
d = 1 - d / Source->Radius;
d = d * d * d;
d = d * Volume;
if (d < 0)
d = 0;
else if (d > 1)
d = 1;
SFXVol(Channel, d, d);
*/
  return Channel;
}

SysF32 ThrustFX2(SysF32 t) {
  SysF32 ft = t, bf = 880 * 8;
  return (SFXModNoise(bf, ft) * 0.7f + SFXModNoise(bf * 1.5f, ft) * 0.3f) *
         SFXEnvADSR(0.1f, 0.0f, 1.0f, 0.1f, t) * 0.5f;
}

SysF32 ThrustFX(SysF32 t) {
  SysF32 w = SFXModSine(500, t) * SFXModNoise(1000, t);
  return w;
}

SysF32 LaserFX(SysF32 t) {
  return SFXModSaw(220 * (1 + SFXEnvADSR(0.1f, 0.0f, 1.0f, 0.9f, t)), t) *
         SFXEnvADSR(0.1f, 0.0f, 1.0f, 0.1f, t);
}

SysF32 UFOFX(SysF32 t) {
  return SFXModTri(50 * (1 + 2 * SFXEnvADSR(0.5f, 0.0f, 1.0f, 0.5f, t)), t);
}

SysF32 BumpFX(SysF32 t) {
  SysF32 f = 100;
  return SFXModNoise(3 * f, t) * SFXModSquare(f, t);
}

SysF32 ExplosionFX(SysF32 t) {
  SysF32 f = 100;
  return SFXModNoise(3 * f, t) * SFXModTri(f, t);
}

SysF32 HyperFX(SysF32 t) {
  SysF32 af;
  af = 0.6f + 0.4f * SFXModSine(20, t);
  return SFXModSine(110, af * t) * SFXEnvADSR(0.1f, 0.0f, 1.0f, 0.9f, t);
}

SysF32 BonusFX(SysF32 t) {
  SysF32 p = fmod(t * 8, 1);
  if (p < 0.5f)
    p = 1;
  else
    p = 0;
  return SFXModSine(440 * 8, t) * p;
}

SysS32 FXPlay(SysS32 Channel, SysU32 State, SysS32 Effect, SysU32 ChannelMask) {
  // if(Effect!=FXThrust) return -1;// else Effect=FXBump;
  enum { FXSamples = 32 * 1024, f = FXSamples };
  static const struct SFXS {
    SFXSynFn Function;
    SysF32 Freq;
    SysS32 SamLen;
    SysF32 Secs;
    SysU32 Flags;
    SysF32 AttackS, ReleaseS;
    SysS32 EnvelopeLen;
    SysF32 AttackEnveLope[3 * 2], ReleaseEnvelope[3 * 2];
  } Patch[FXMax] = {
      {ThrustFX,
       f * 1.0f,
       FXSamples,
       3,
       (SFXSynClip | SFXSyn2S16),
       2,
       2,
       3,
       {0, 0, 0.5f, 0.5f, 1, 1},
       {0, 1, 0.5f, 0.5f, 1, 0}},

      {LaserFX, f, FXSamples, 1, (SFXSynClip | SFXSyn2S16), SFXNoAttack,
       SFXNoRelease, 0},

      {UFOFX,
       f * 3,
       FXSamples,
       7,
       (SFXSynClip | SFXSyn2S16),
       5,
       2,
       2,{0, 0, 1, 1},{0, 1, 1, 0}},
      {ExplosionFX, f, FXSamples, 1, (SFXSynClip | SFXSyn2S16), 1,1, 2,{0, 0, 1, 1},
       {0, 1, 1, 0}},
      {HyperFX, f / 3.0f, FXSamples, 3, (SFXSynClip | SFXSyn2S16), 0,0, 2,{0, 0, 1, 1},
       {0, 1, 1, 0}},
      {BonusFX, f / 2.0f, FXSamples, 2, (SFXSynClip | SFXSyn2S16), 1,1, 2,{0, 0, 1, 1},
       {0, 1, 1, 0}},
      {BumpFX, f, FXSamples, 1, (SFXSynClip | SFXSyn2S16), 1,1, 2,{0, 0, 1, 1},
       {0, 1, 1, 0}},
      {TestFX, f, FXSamples, 1, (SFXSynClip | SFXSyn2S16), 1,1, 2,{0, 0, 1, 1},
       {0, 1, 1, 0}},
  };
  static SysS16 Sam[FXMax][FXSamples];
  static SysU32 Flags = 0;

  if (!Flags) {
    SysF32 *Work = SysNew(SysF32, FXSamples);
    for (SysU32 i = 0; i < FXMax; i++) {
      SFXSyn(Patch[i].Flags, Patch[i].Function, Work, Patch[i].SamLen, Sam[i]);
    }
    SysDelete(Work);
    Flags = 1;
  }

  SysAssert((Effect >= 0) && (Effect < FXMax));
  int c = Channel;
  if (State == FXStart) {
    if (c >= 0)
      if (Active & (1 << c))
        return -1;
    c = SFXFirstFreeChannel(ChannelMask);

    if (c < 0)
      return 0;
    SFXSam(c, Patch[Effect].Freq, SFXFmtS16, Sam[Effect], Patch[Effect].SamLen,
           Patch[Effect].Secs);
    SFXAttack(c, &Patch[Effect].AttackEnveLope[0], Patch[Effect].EnvelopeLen,
              Patch[Effect].AttackS);
    SFXRelease(c, &Patch[Effect].ReleaseEnvelope[0], Patch[Effect].EnvelopeLen,
               Patch[Effect].ReleaseS);
    SFXVol(c, 1, 1);
    SFXActivate(c);
    return c;
  }

  if (c < 0)
    return c;

  SysAssert(c < 32);

  if (State == FXFadeOff) {
    SFXDeActivate(c);
    c = -1;
    return c;
  }

  if (State == FXFinish) {
    SFXDeActivate(c);
    c = -1;
    c = -1;
    return c;
  }

  if (State == FXOff) {
    SFXDeActivate(c);
    c = -1;
    return c;
  }

  return -1;
}
