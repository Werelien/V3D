/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#ifndef _SYS_H_GS_2011_
#define _SYS_H_GS_2011_

typedef char SysC8;
typedef unsigned char SysU8;
typedef signed char SysS8;
typedef unsigned short SysU16;
typedef signed short SysS16;
typedef unsigned int SysU32;
typedef signed int SysS32;
typedef unsigned long long SysU64;
typedef signed long long SysS64;
typedef float SysF32;
typedef double SysF64;

enum {
  SYSINPUT_TOUCHON = 0x10000,
  SYSINPUT_TOUCHOFF = 0x10001,
  SYSINPUT_TOUCHMOVE = 0x10002,
  SYSINPUT_ACCEL = 0x20000,
  SYSSTATE_AUDIOON = 1,
  SYSSTATE_AUDIOOFF = -1,
  SYSSTATE_UDPON = 2,
  SYSSTATE_UDPOFF = -2,
  SYSTATE_TITLE = 3,
  SYSAUDIO_STEREO = (1 << 0),
  SYSAUDIO_FREQ = 44100,
  SYSFRAME_QUIT = (1 << 0),
  SYSFRAME_PAUSE = (1 << 0),
  SYSFRAME_RESUME = (1 << 1),
  SYSFRAME_GL_CREATE = (1 << 2),
  SYSFRAME_GL_CHANGE = (1 << 3),
  SYSLOADSAVE_DEFAULTDIR = 0,
  SYSLOADSAVE_USERDIR = (1 << 1),
  SYSTXTSTYLE_BOLD = 0,
  SYSTXTSTYLE_ITALIC,
  SYSTXTSTYLE_UNDERLINE,
  SYSTXTSTYLE_STRIKETHROUGH,
  SYSTXTSTYLE_NORMAL,
  SYS_LAST
};

SysU32 SysState(SysS32 Cmd, void *Arg);
SysU32 SysUDPIP(SysC8 *IPDNSString);
SysU32 SysUDPBroadcastIP(void);
SysU32 SysUDPSend(SysU32 IPAddress, SysU16 Port, void *Packet,
                  SysU32 PacketByteSize);
SysU32 SysUDPBind(SysU32 IPAddress, SysU16 Port);
SysU32 SysUDPRecieve(SysU32 *IPAddress, SysU16 *Port, void *Packet,
                     SysU32 PacketByteSize, SysU32 *BytesRecieved);
SysF64 SysSec(void);
SysU64 SysRNG(void);
SysU64 SysPRNG(SysU64 Seed01,SysU64 Seed23,SysU64 Index01,SysS32 Rounds);
SysS32 SysLoad(SysU32 Flags, const SysC8 *FileName, SysU32 Offset, SysU32 Size,
               void *Buffer);
SysS32 SysSave(SysU32 Flags, const SysC8 *FileName, SysU32 Size, void *Buffer);
SysF32 SysAspectRatio(SysU32 *Width, SysU32 *Height);
SysS32 SysUserInput(SysU64 CmdFlgs, SysU64 ID, SysF64 X, SysF64 Y, SysF64 Z,
                    SysF64 DX, SysF64 DY, SysF64 DZ, SysF64 Pressure);
SysS32 SysUserFrame(SysS32 Flags);

extern SysU32 SysAudioFreq, SysAudioFlags;
SysS32 SysUserAudio(SysU32 Flags, SysU32 AudioFreq, SysU8 *Stream, SysS32 Len);
SysS32 SysMusicOn(SysC8 *FileName, SysF32 FadeInS, SysS32 Loops);
SysS32 SysMusicPause(void);
SysS32 SysMusicVolume(SysF32 Volume);
SysS32 SysMusicResume(void);
SysS32 SysMusicOff(SysF32 FadeOut);

typedef struct SYSMOUSE {
  SysF32 X, Y, DeltaX, DeltaY, WindowX, WindowY;
  SysU64 Buttons;
} SYSMOUSE;
extern const SYSMOUSE *SysMouse;
enum {
  SYS_CAPSLOCK=128,
  SYS_RSHIFT,
  SYS_LSHIFT,
  SYS_RCTRL,
  SYS_LCTRL,
  SYS_RALT,
  SYS_LALT,
  SYS_RMETA,
  SYS_LMETA,
  SYS_LSUPER,
  SYS_RSUPER,
  SYS_MODE,
  SYS_COMPOSE,
  SYS_UP,
  SYS_DOWN,
  SYS_RIGHT,
  SYS_LEFT,
  SYS_INSERT,
  SYS_HOME,
  SYS_END,
  SYS_PAGEUP,
  SYS_PAGEDOWN,
  SYS_BACKSPACE,
  SYS_TAB,
  SYS_CLEAR,
  SYS_RETURN,
  SYS_PAUSE,
  SYS_ESCAPE,
  SYS_DELETE,
  SYS_F1,
  SYS_F2,
  SYS_F3,
  SYS_F4,
  SYS_F5,
  SYS_F6,
  SYS_F7,
  SYS_F8,
  SYS_F9,
  SYS_F10,
  SYS_F11,
  SYS_F12,
  
  SYS_KEYS_FLUSH,
  
  SYS_KEYS_END

};

SysU64 SysKeyActive(SysU64 Key);
SysU64 SysKeyPressed(SysU32 Key);

void SysKill(SysS32 n);
void SysWindowTitle(SysC8 *s);
void *SysDbgAlloc(SysU32 Bytes, const SysC8 *File, SysU32 Line);
void SysDbgFree(void *Mem, const SysC8 *File, SysU32 Line);
void SysODS(const SysC8 *DebugString, ...);

#define malloc SYS_MALLOC_NOT_ALLOWED
#define free SYS_FREE_NOT_ALLOWED

#ifdef SYS_DEBUG_ODS

#define SysNew(T, S) (T *)SysDbgAlloc(sizeof(T) * (S), __FILE__, __LINE__)
#define SysDelete(M) SysDbgFree(M, __FILE__, __LINE__)
#include <assert.h>
#define SysAssert(exp) assert(exp)

#else

#define SysNew(T, S) (T *)SysDbgAlloc(sizeof(T) * (S), 0, 0)
#define SysDelete(M) SysDbgFree(M, 0, 0)
#define SysAssert(exp)

#endif

#endif
