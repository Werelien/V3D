#!/bin/bash
source ~/emsdk/emsdk_env.sh

