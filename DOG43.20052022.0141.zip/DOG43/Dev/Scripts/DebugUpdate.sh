#!/bin/bash
cd ../../Build/
make -j 8 config=debug
cp -r ../Dev/Src/Shaders ../Final/Assets
cp Debug/V3D ../Final/
