-- premake5.lua
workspace "V3D"
location "../Build"
configurations {"Debug", "Release"}
cdialect "c99"

project "V3D"
kind "ConsoleApp"
language "C"

files {"**.h", "**.c"}

filter "configurations:Debug"
targetdir "../Build/Debug"
defines {"SYS_DEBUG_ODS", "GFX_DEBUG_ODS"}
flags {}
symbols "On"

links {"GL", "SDL2", "SDL2_ttf", "m"}

filter "configurations:Release"
targetdir "../Build/Release"
defines {"SYS_RELEASE_ODS", "GFX_RELEASE_ODS"}
flags {}
optimize "On"

links {"GL", "SDL2", "SDL2_ttf", "m"}
