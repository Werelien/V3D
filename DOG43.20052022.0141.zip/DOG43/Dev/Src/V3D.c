#include "GFX.h"
#include "SFX.h"
#include "SYS.h"
#include "math_3d.h"
#include <string.h>

static char Scratch[32 * 1024];
SysF64 FPS(SysS32 PeriodSecs)
{
	static SysF64 FPS = 0;
	static SysU64 FrameCount = 0, FPSFrameCount = 0, FPSS = 0;
	if (PeriodSecs <= 0)
		return FPS;
	SysF64 SysT = SysSec() - FPSS;
	if (SysT >= PeriodSecs)
	{
		FPS = (FrameCount - FPSFrameCount) / SysT;
		FPSFrameCount = FrameCount;
		FPSS = SysSec();
		SysODS("FPS:%f\n", FPS);
	}
	FrameCount++;
	return FPS;
}

void ShaderLoad(SysU32 Shader, SysC8 *VF, SysC8 *FF)
{
	GFXShaderCreate(Shader, VF, FF, GFXFLAG_LOAD);
}

enum

{
	Q3DIMGBASE = 100,
	HUDIMGBASE = 101,
	MAX_IMAGES = 256
};
GFXTEXH Image[MAX_IMAGES];

SysS32 FontHeight, FontAscent, FontDescent, FontSkip, FontTxtWH;

const SysTxtCache *TxtRender(const char *s, SysU32 x, SysU32 y, SysS32 *w, SysS32 *h)
{
	const SysTxtCache *c;
	c = SysTxtRender(0, s, 0);
	SysF32 ts = SysSec();
	GFXTexUpdate(Image[255], GFX_U8, x, y, c->Width, c->Height, c->Pixels, c->Pitch, GFXTEX_FLAG_MIPMAP | GFXTEX_FLAG_LINEAR);
	ts = SysSec() - ts;
	if (w)
		*w = c->Width;
	if (h)
		*h = c->Height;
	SysODS("TxtRender:%s x:%d y:%d   w:%d h:%d  Tex Update Seconds:%f\n", s, x, y, c->Width, c->Height, ts);
	FontHeight = c->FHeight;
	FontAscent = c->FAscent;
	FontDescent = c->FDescent;
	FontSkip = c->FSkip;
	SysTxtCacheDestroy();
	SysAssert(FontHeight == c->Height);
	return c;
}

void TxtInit(const SysC8 *FntName, SysU32 TexCacheW, SysU32 TexCacheH, SysU32 FontSize)
{
	SysAssert(TexCacheW == TexCacheH);
	FontTxtWH = TexCacheW;
	Image[255] = GFXTexCreate(GFX_U8, TexCacheW, TexCacheH, 0, 0, GFXTEX_FLAG_MIPMAP | GFXTEX_FLAG_LINEAR);

	SysODS("\n\nInitialise Fonts...\n");
	SysTxtOpenFont(0, FntName, FontSize, 0);
	SysODS("Font Initialised\n");
}

SysF64 FHash64(SysU64 h, SysF32 Low, SysF32 High)
{
	SysF64 l = ((SysF64)(h & 0x7fffffffffffffff)) / (SysF64)0x7fffffffffffffff;
	return Low + (l * (High - Low));
}

SysF32 FHash32(SysF32 Low, SysF32 High)
{
	return FHash64(SysRNG(), Low, High);
}

SysF32 *ScaleMatrix(SysF32 *M, SysF32 Scale)
{
	int o = 0;
	for (int j = 0; j < 4; j++)
		for (int i = 0; i < 4; i++)
			M[o++] = ((i == j) * Scale);
	M[15] = 1;
	return M;
}

SysS32 PowOf2(SysS32 v)
{
	SysS32 n = 0;
	while ((1 << n) < v)
		n++;
	return n;
}

mat4_t ProjM;

typedef struct Q3DMV
{
	SysF32 X0, Y0, X1, Y1;
	SysS16 U0, V0, U1, V1;
	SysU32 RGBA;
	SysU8 C[4];
} Q3DMV;

void RenderHud(GFXBVI *VB, int NumberOfQ, int s, SysF32 t, SysU32 RGBA, SysU32 UV, SysF32 XScl, SysF32 YScl, SysU32 CFG)
{

	enum
	{
		MAX_HUD = 256
	};

	static Q3DMV QHud[MAX_HUD];

	enum
	{
		nofui = 2,
	};
	typedef struct hs
	{
		char *s;
		SysF32 x, y, w, h;
		SysU32 n, Flags;
	} hs;
	static hs h[nofui] = {
		{"FPS:00000000", -0.25f, 0.38f, 0, 0, 0, 0},
		{"Quads:00000000", 0.25f, 0.38f, 0, 0, 0, 0},
	};
	static SysF32 m3d[256][256][16];

	if (!VB->Flags)
	{
		SysODS("\nCreating Hud...\n");

		Image[HUDIMGBASE] = GFXTexCreate(GFX_4XF32, 256 * 4, 1, 0, 0, 0);

		SysAssert(nofui < MAX_HUD);

		VB->VNormalised = 0;

		VB->VType[0] = GFXV_4XF32;
		VB->VType[1] = GFXV_4XS16;
		VB->VType[2] = GFXV_4XU8;
		VB->VType[3] = GFXV_4XU8;

		typedef struct I6
		{
			SysU16 v[4];
		} I6;

		I6 ib = {0, 1, 2, 3};

		VB->VN = 1;
		VB->Flags = GFX_BVI_CREATE;
		GFXVS v0 = {0, GFX_BVI_DYNAMIC, 4, sizeof(Q3DMV), 1, sizeof(Q3DMV) * MAX_HUD, &QHud[0], 0, 0};
		VB->V[0] = v0;
		GFXIS i0 = {0, GFX_BVI_STATIC, 4, sizeof(ib), &ib, 0, 0};
		VB->I = i0;
		GFXBufferVertIndex(VB);
		SysODS("Hud Created\n\n");
	}

	static SysF64 LastFPS = -1;
	static int lastn = -1;

	SysF64 fps = FPS(0);
	if (fps != LastFPS)
	{
		int i = 0, u = 0, v = i * FontHeight;
		SysS32 tw, th;
		LastFPS = fps;
		sprintf(Scratch, "FPS:%2.2f ", fps);
		h[i].n = strlen(Scratch);
		TxtRender(Scratch, u, v, &tw, &th);
		tw -= 4;
		h[i].w = tw;
		h[i].h = th;
		QHud[i].U0 = u;
		QHud[i].V0 = v;
		QHud[i].U1 = QHud[i].U0 + tw;
		QHud[i].V1 = QHud[i].V0 + th;
		h[i].Flags = 1;
	}

	if (NumberOfQ != lastn)
	{
		int i = 1, u = 0, v = i * FontHeight;
		SysS32 tw, th;
		lastn = NumberOfQ;
		sprintf(Scratch, "Quads:%d ", NumberOfQ);
		h[i].n = strlen(Scratch);
		TxtRender(Scratch, u, v, &tw, &th);
		tw -= 4;
		h[i].w = tw;
		h[i].h = th;
		QHud[i].U0 = u;
		QHud[i].V0 = v;
		QHud[i].U1 = QHud[i].U0 + tw;
		QHud[i].V1 = QHud[i].V0 + th;
		h[i].Flags = 1;
	}

	SysRNGSeed(s | 1, (~s) | (1 << 16));
	int Changed = 0;
	for (int i = 0; i < nofui; i++)
		if (h[i].Flags)
		{
			SysF32 x = h[i].x, y = h[i].y;
			mat4_t m;

			m = m4_translation(vec3(x, y, -1));
			SysF32 scl = 0.002f;
			mat4_t sm = m4_scaling(vec3((scl * h[i].w), scl * FontHeight, 0.1f));
			m = (m4_mul(m, sm));
			m = m4_transpose(m);
			memcpy(&(m3d[i >> 8][i & 0xff][0]), &m.m00, 3 * 4 * sizeof(SysF32));

			QHud[i].X0 = 0;
			QHud[i].Y0 = 1;
			QHud[i].X1 = 1;
			QHud[i].Y1 = 0;
			QHud[i].RGBA = RGBA;
			QHud[i].C[0] = (i & 0xff);
			QHud[i].C[1] = (i >> 8);
			h[i].Flags = 0;
			Changed |= (1 << i);
		}
	if (Changed)
	{
		VB->V[0].ByteOffset = 0;
		VB->V[0].ByteLen = nofui * sizeof(Q3DMV);
		VB->Flags = GFX_BVI_UPDATE;
		GFXBufferVertIndex(VB);
		GFXTexUpdate(Image[HUDIMGBASE], GFX_4XF32, 0, 0, 256 * 4, 1, &(m3d[0][0][0]), 0, 0);
	}
	SysF64 rgba[4] = {FHash32(0, 1), FHash32(0, 1), FHash32(0, 1), FHash32(0, 1)};
	GFXRender(GFX_TRIANGLE_STRIP, VB, nofui);
}

enum
{
	MAX_Q3D = 64 * 1024
};
SysU32 Paused = 0;
void RenderQuads(GFXBVI *VB, int n, int s, SysF32 t, SysU32 RGBA, SysU32 UV, SysF32 XScl, SysF32 YScl, SysU32 CFG)
{

	static Q3DMV Quad[MAX_Q3D];
	if (n > MAX_Q3D)
		n = MAX_Q3D;

	static SysF32 m3d[256][256][16];
	if (!VB->Flags)
	{

		SysODS("\nCreating Quads\n");

		Image[Q3DIMGBASE] = GFXTexCreate(GFX_4XF32, 256 * 4, 256, 0, 0, 0);

		VB->VNormalised = 0;

		VB->VType[0] = GFXV_4XF32;
		VB->VType[1] = GFXV_4XS16;
		VB->VType[2] = GFXV_4XU8;
		VB->VType[3] = GFXV_4XU8;

		typedef struct I6
		{
			SysU16 v[4];
		} I6;

		I6 ib = {0, 1, 2, 3};

		VB->VN = 1;
		VB->Flags = GFX_BVI_CREATE;
		GFXVS v0 = {0, GFX_BVI_DYNAMIC, 4, sizeof(Q3DMV), 1, sizeof(Q3DMV) * MAX_Q3D, &Quad[0], 0, 0};
		VB->V[0] = v0;
		GFXIS i0 = {0, GFX_BVI_STATIC, 4, sizeof(ib), &ib, 0, 0};
		VB->I = i0;
		GFXBufferVertIndex(VB);
		SysODS("Quads Created\n\n");
	}
	static int lastn = -1;
	if ((!Paused) || (lastn != n))
	{
		lastn = n;
		SysRNGSeed(s | 1, (~s) | (1 << 16));
		for (int i = 0; i < n; i++)
		{
			SysF32 a = FHash32(-M_PI, M_PI) + t * 2 * M_PI * 0.5f;
			mat4_t tm = m4_translation(vec3(FHash32(-8, 8), FHash32(-8, 8), FHash32(0, -64)));
			mat4_t rm = m4_rotation(a, vec3(FHash32(-1, 1), FHash32(-1, 1), FHash32(-1, 1)));
			mat4_t sm = m4_scaling(vec3(XScl, YScl, 1));

			mat4_t m = m4_transpose(m4_mul(m4_mul(tm, rm), sm));

			memcpy(&(m3d[i >> 8][i & 0xff][0]), &m.m00, 3 * 4 * sizeof(SysF32));

			Quad[i].X0 = -1;
			Quad[i].Y0 = -1;
			Quad[i].X1 = 1;
			Quad[i].Y1 = 1;
			Quad[i].U0 = 0;
			Quad[i].V0 = 0;
			Quad[i].U1 = 0x7fff;
			Quad[i].V1 = 0x7fff;
			Quad[i].RGBA = RGBA;
			Quad[i].C[0] = (i & 0xff);
			Quad[i].C[1] = (i >> 8);
		}

		VB->V[0].ByteOffset = 0;
		VB->V[0].ByteLen = n * sizeof(Q3DMV);
		VB->Flags = GFX_BVI_UPDATE;
		GFXBufferVertIndex(VB);
		GFXTexUpdate(Image[Q3DIMGBASE], GFX_4XF32, 0, 0, 256 * 4, (((n - 1) >> 8) + 1), &(m3d[0][0][0]), 0, 0);
	}
	SysF64 rgba[4] = {FHash32(0, 1), FHash32(0, 1), FHash32(0, 1), FHash32(0, 1)};
	GFXRender(GFX_TRIANGLE_STRIP, VB, n);
}

SysF32 GridMod(SysF32 a, SysF32 b)
{
	a = fmodf(a, 2 * b);
	if (a > b)
	{
		a = -b + a - ((SysS32)(a / b)) * b;
	}
	else if (a < -b)
	{
		a = b + a - ((SysS32)(a / b)) * b;
	}
	return a;
}

SysS32 SysUserInput(SysU32 CmdFlgs, SysU32 ID, SysS32 Xr, SysS32 Yr, SysS32 Zr, SysS32 Pressure)
{
	return 0;
}

void UpdateScreenWH(void)
{
	SysU32 w, h;
	SysF32 a = GFXAspectRatio(&w, &h, 0);
	ProjM = m4_perspective(360 / 8, a, 0.00001f, 100.f);
	GFXViewPort(0, 0, w, h);
	GFXClip(0, 0, 0, 0);
}

void LoadShaders(void)
{
	ShaderLoad(0, "./Assets/Shaders/Q3DV.vert", "./Assets/Shaders/Q3DF.frag");
	ShaderLoad(1, "./Assets/Shaders/Q3DFntV.vert", "./Assets/Shaders/Q3DFNTF.frag");
}

GFXTEXH TexLoad(SysC8 *TGAF, SysU32 Flags)
{
	return GFXTGATexCreate(TGAF, Flags | GFXFLAG_LOAD);
}

void LoadAssets()
{
	static int Loaded = 0;
	if (Loaded)
		return;
	else
	{
		Image[0] = TexLoad("./Assets/Images/0.tga", (GFX_4XU4 | GFXTGA_TRANS0 | GFXTEX_FLAG_LINEAR | GFXTEX_FLAG_MIPMAP));
		SysAssert(Image[0].ID);
		Loaded = 1;
	}
}

#define RENDER_TO_TEXTURE
SysU32 ScreenWidth, ScreenHeight;
GFXTEXH FBRenderTex = {0};
const SysU32 FBRenderWidth = 1024, FBRenderHeight = 768;
#ifdef RENDER_TO_TEXTURE
void CreateRenderTarget(void)
{
	GFXFrameBufferCreate(GFX_4XU8, &FBRenderTex, FBRenderWidth, FBRenderHeight, GFXTEX_FLAG_DEPTH | GFXTEX_FLAG_MIPMAP);
	ShaderLoad(2, "./Assets/Shaders/RTV.vert", "./Assets/Shaders/RTF.frag");
}

void TextureRenderTarget(void)
{
	GFXFrameBufferTarget(&FBRenderTex);
	GFXViewPort(0, 0, FBRenderWidth, FBRenderHeight);
	GFXClip(0, 0, FBRenderWidth, FBRenderHeight);
}

void ScreenRenderTarget(void)
{
	GFXFrameBufferTargetScreen();
	GFXViewPort(0, 0, ScreenWidth, ScreenHeight);
	GFXClip(0, 0, ScreenWidth, ScreenHeight);
}

void RenderToScreen(SysU64 RGBA)
{
	static GFXBVI VB = {0};
	if (!VB.Flags)
	{
		for (int i = 0; i < 16; i++)
		{
			VB.VNormalised = 0;
			VB.VType[i] = GFXV_4XS8;
		}
		typedef struct I6
		{
			SysU16 v[4];
		} I6;

		SysS8 vv[32] = {
			-1, -1, 0, 1, 0, 0, 0, 0,
			1, -1, 0, 1, 1, 0, 0, 0,
			-1, 1, 0, 1, 0, 1, 0, 0,
			1, 1, 0, 1, 1, 1, 0, 0};
		I6 ib = {0, 1, 2, 3};
		VB.VN = 1;
		VB.Flags = GFX_BVI_CREATE;
		GFXVS v0 = {0, GFX_BVI_STATIC, 2, 2 * 4 * sizeof(SysS8), 0, sizeof(vv), &vv[0], 0, 0};
		VB.V[0] = v0;
		GFXIS i0 = {0, GFX_BVI_STATIC, 4, sizeof(ib), &ib, 0, 0};
		VB.I = i0;
		GFXBufferVertIndex(&VB);
	}
	GFXBlend(GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, 0);
	GFXRGBAMask(0xffffffff);
	GFXCull(GFXCULL_NONE);
	GFXZOptions(GFXFLAG_Z_WRITE_OFF | GFXFLAG_Z_TEST_OFF);
	GFXClear(RGBA, 1);

	GFXShader(2);

	const GFXF32 RGBAF[4] = {1.0f, 1.0f, 1.0f, 1.0f};
	mat4_t mt = m4_identity();
	GFXShaderM4(0, &mt.m00, 1);
	GFXShaderV4(0, &RGBAF[0], 1);
	GFXTex(0, FBRenderTex, GFXTEX_FLAG_MIPMAP);
	// GFXTex(0, Image[0]);
	GFXRender(GFX_TRIANGLE_STRIP, &VB, 1);
}

#else
void CreateRenderTarget(void)
{
}
void RenderToScreen(SysU64 RGBA)
{
}
void ScreenRenderTarget(void)
{
}
void TextureRenderTarget(void)
{
}
#endif

GFXS32 FileLoad(const GFXC8 *FileName, void *Buffer, GFXU32 BufferSize, const GFXC8 *SrcFileName, GFXU32 SrcLineNumber)
{
	return SysLoad(0, FileName, 0, BufferSize, Buffer);
}

GFXS32 FileSize(const GFXC8 *FileName, const GFXC8 *SrcFileName, GFXU32 SrcLineNumber)
{
	return SysLoad(0, FileName, 0, 0, 0);
}

SysS32 SysUserFrame(SysS32 Flags)
{
	static GFXBVI BVI[2] = {{0}, {0}};
	static SysU32 Mode = 0;
	if (Mode)
	{
		if (Flags & SYSFRAME_GL_CREATE)
		{
			SysU32 w, h;
			SysAspectRatio(&w, &h);
			GFXOpen(w, h, SysDbgAlloc, SysDbgFree, FileLoad, FileSize);
		}
	}
	if (Flags & SYSFRAME_RESUME)
	{
	}
	else if (Flags & SYSFRAME_PAUSE)
	{
		return 0;
	}

	switch (Mode)
	{
	case 0:
	{

		BVI[0].Flags = BVI[1].Flags = 0;
		SysAspectRatio(&ScreenWidth, &ScreenHeight);
		GFXOpen(ScreenWidth, ScreenHeight, SysDbgAlloc, SysDbgFree, FileLoad, FileSize);
		SysODS("AspectRatio: Sys:%f GFX:%f\n", SysAspectRatio(0, 0), GFXAspectRatio(0, 0, 0));

		TxtInit("./Assets/Fonts/Mono.TTF", 256, 256, 16);
		LoadShaders();

		GFXCull(GFXCULL_NONE);
		GFXRenderBegin();
		GFXClear(0, 1);

		SysState(SYSSTATE_AUDIOON, 0);
		SysState(SYSSTATE_UDPON, 0);

		LoadAssets();
		CreateRenderTarget();

		Mode++;
		break;
	}
	case 1:
	{
		UpdateScreenWH();
		static SysU32 State = 0;
		static SysU64 fc = 0, lastfc = 0;
		static SysF64 lastft = 0;
		static SysF32 BlendFactor = 0.0f;
		static SysF32 lw = 3;
		static int NC = 256;
		const int NCA = 128;
		GFXRenderBegin();
		TextureRenderTarget();
		for (int i = 0; i < 5; i++)
		{
			if (SysKeyState[30 + i])
			{
				State &= ~(1 << i);
				State |= (SysKeyState[225] << i);
			}
		}
		if (SysKeyState[35 + 0])
		{
			if (SysKeyState[225])
				BlendFactor += 0.01f;
			else
				BlendFactor -= 0.01f;
			if (BlendFactor < 0)
				BlendFactor = 0;
			else if (BlendFactor > 1)
				BlendFactor = 1;
			SysODS("Objects:%d Blend Factor:%f Line Width:%f FPS:%f\n", NC, BlendFactor, lw, FPS(0));
		}
		if (SysKeyState[35 + 1])
		{
			if (SysKeyState[225])
				NC += NCA;
			else
				NC -= NCA;
			if (NC < 0)
				NC = 0;
			if (NC > MAX_Q3D)
				NC = MAX_Q3D;

			SysODS("Objects:%d Blend Factor:%f Line Width:%f FPS:%f\n", NC, BlendFactor, lw, FPS(0));
		}
		if (SysKeyState[35 + 2])
		{
			if (SysKeyState[225])
				lw += 0.1f;
			else
				lw -= 0.1f;
			SysF32 r[2];
			GFXLineWidthRange(r);
			if (lw < r[0])
				lw = r[0];
			else if (lw > r[1])
				lw = r[1];
			SysODS("Objects:%d Blend Factor:%f Line Width:%f FPS:%f\n", NC, BlendFactor, lw, FPS(0));
		}
		GFXBlend(GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, 0);
		GFXRGBAMask(0xffffffff);
		GFXCull(GFXCULL_NONE);
		GFXZOptions(GFXFLAG_Z_WRITE_ON | GFXFLAG_Z_TEST_ALWAYS);
		GFXClear(fc, 1);
		GFXZOptions(GFXFLAG_Z_WRITE_ON | GFXFLAG_Z_TEST_LE);

		if (State & 1)
		{
			Paused = 1;
		}
		else
		{
			Paused = 0;
		}

		SysF32 t = SysSec();
		SysF32 FragAlpha[4] = {0, 0, 0, 0};
		SysF32 VTexXY[4] = {0, 0, 0, 0};
		mat4_t mt;

		GFXShader(0);
		mt = m4_transpose(ProjM);
		GFXShaderM4(0, &mt.m00, 1);
		FragAlpha[3] = BlendFactor;
		GFXShaderV4(0 | GFXFRAGV4, FragAlpha, 1);
		VTexXY[0] = 0x7fff;
		GFXShaderV4(0, VTexXY, 1);
		GFXBlend(GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, 0);
		GFXTex(0, Image[0], 0);
		GFXTex(GFXVTEXSTAGE | 0, Image[Q3DIMGBASE], 0);
		RenderQuads(&BVI[0], NC, 1, t, 0x7f7f7f7f, 0x0000ffff, 1, 1, 0);

		GFXZOptions(GFXFLAG_Z_WRITE_OFF | GFXFLAG_Z_TEST_OFF);
		GFXShader(1);
		mt = m4_transpose(ProjM);
		GFXShaderM4(0, &mt.m00, 1);
		FragAlpha[3] = BlendFactor;
		VTexXY[0] = FontTxtWH;
		GFXShaderV4(0, VTexXY, 1);
		GFXShaderV4(0 | GFXFRAGV4, FragAlpha, 1);
		GFXBlend(GFXBLEND_SRC_ALPHA, GFXBLEND_ONE_MINUS_SRC_ALPHA, GFXBLEND_SRC_ALPHA, GFXBLEND_ONE_MINUS_SRC_ALPHA, 0xffffffff);
		GFXTex(0, Image[255], 0);
		GFXTex(GFXVTEXSTAGE | 0, Image[HUDIMGBASE], 0);
		RenderHud(&BVI[1], NC, 2, t, 0x7f7f7f7f, 0x0000ffff, 1, 1, 0);

		ScreenRenderTarget();
		RenderToScreen(fc);
		fc++;
		break;
	}
	}

	FPS(5);

	GFXRenderEnd();

	if (0)
	{
		GFXClose();
	}

	return 0;
}
