/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
#ifndef _GFX_H_GS_2011_
#define _GFX_H_GS_2011_

#ifdef __cplusplus
extern "C" {
#endif

typedef char GFXC8;
typedef unsigned char GFXU8;
typedef signed char GFXS8;
typedef unsigned short GFXU16;
typedef signed short GFXS16;
typedef unsigned int GFXU32;
typedef signed int GFXS32;
typedef unsigned long long GFXU64;
typedef signed long long GFXS64;
typedef float GFXF32;
typedef double GFXF64;

typedef void *(*GFX_MALLOC)(GFXU32 Size, const GFXC8 *SrcFileName,
                            GFXU32 SrcLineNumber);
typedef void (*GFX_FREE)(void *Memory, const GFXC8 *SrcFileName,
                         GFXU32 SrcLineNumber);
typedef GFXS32 (*GFX_FILELOAD)(const GFXC8 *FileName, void *Buffer,
                               GFXU32 BufferSize, const GFXC8 *SrcFileName,
                               GFXU32 SrcLineNumber);
typedef GFXS32 (*GFX_FILESIZE)(const GFXC8 *FileName, const GFXC8 *SrcFileName,
                               GFXU32 SrcLineNumber);

enum {
  GFX_POINTS = 0,
  GFX_LINES = 1,
  GFX_LINE_STRIP = 3,
  GFX_TRIANGLES = 4,
  GFX_TRIANGLE_STRIP = 5,
  GFX_TRIANGLE_FAN = 6
};

enum {
  GFXTEX_NULL = 0,

  GFX_4XU8 = 0,
  GFX_4XU4,
  GFX_3XU5U1,
  GFX_4XF16,
  GFX_4XF32,
  GFX_4XU16,
  GFX_4XU32,
  GFX_U8,

  GFXFLAG_Z_TEST_OFF = 0,
  GFXFLAG_Z_TEST_GE,
  GFXFLAG_Z_TEST_G,
  GFXFLAG_Z_TEST_LE,
  GFXFLAG_Z_TEST_L,
  GFXFLAG_Z_TEST_ALWAYS,
  GFXFLAG_Z_TEST_NEVER,
  GFXFLAG_Z_WRITE_ON = (1 << 16),
  GFXFLAG_Z_WRITE_OFF = (1 << 17),

  GFXFLAG_LOAD = (1 << 15),
  GFXTGA_FLAGFLIPV = (1 << 16),
  GFXTGA_ALPHAGEN = (1 << 18),
  GFXTGA_ALPHAGENINV = (1 << 19),
  GFXTGA_INVERT = (1 << 20),
  GFXTGA_TRANS0 = (1 << 21),
  GFXTGA_RGBA = (1 << 22),
  GFXTGA_RGB = (1 << 23),

  GFXTEX_UNMAPPED = -1,
  GFXTEX_FLAG_LINEAR = (1 << 28),
  GFXTEX_FLAG_MIPMAP = (1 << 29),
  GFXTEX_FLAG_CLAMP = (1 << 30),
  GFXTEX_FLAG_DEPTH = (1 << 31),

  GFXBLEND_ZERO = 0,
  GFXBLEND_ONE,
  GFXBLEND_SRC_COLOR,
  GFXBLEND_ONE_MINUS_SRC_COLOR,
  GFXBLEND_SRC_ALPHA,
  GFXBLEND_ONE_MINUS_SRC_ALPHA,
  GFXBLEND_DST_ALPHA,
  GFXBLEND_ONE_MINUS_DST_ALPHA,
  GFXBLEND_DST_COLOR,
  GFXBLEND_ONE_MINUS_DST_COLOR,
  GFXBLEND_SRC_ALPHA_SATURATE,
  GFXBLEND_CONSTANT_COLOR,
  GFXBLEND_ONE_MINUS_CONSTANT_COLOR,
  GFXBLEND_CONSTANT_ALPHA,
  GFXBLEND_ONE_MINUS_CONSTANT_ALPHA,
  GFXBLEND_OFF = 0xffff,

  GFXFRAGV4 = (1 << 16),
  GFXVTEXSTAGE = 16,

  GFXCULL_NONE = 0,
  GFXCULL_CW = 1,
  GFXCULL_CCW = 2,

  GFX_MAXSHADERS = 32,

  GFX_BVI_NONE = 0,
  GFX_BVI_STATIC,
  GFX_BVI_DYNAMIC,
  GFX_BVI_STREAM,
  GFX_BVI_CREATE = (1 << 24),
  GFX_BVI_UPDATE = (1 << 25),

  GFX_BVI_MAP_READ = (1 << 0),
  GFX_BVI_MAP_WRITE = (1 << 1),
  GFX_BVI_MAP_DISCARD = (1 << 2),
  GFX_BVI_MAP_UNSYNC = (1 << 3),

  GFXV_4XS8 = 0,
  GFXV_4XU8,
  GFXV_4XS16,
  GFXV_4XU16,
  GFXV_4XS32,
  GFXV_4XU32,
  GFXV_4XF16,
  GFXV_4XF32,
  GFXV_4XFIXED16_16,
  GFXV_S2S10X3,
  GFXV_U2U10X3,

  GFXFLAG_END
};

typedef struct GFXVS {
  GFXU32 ID, SDS;
  GFXS32 NUV4, ByteStride, InstDiv, ByteDataSize;
  void *Data;
  GFXS32 ByteOffset, ByteLen;
} GFXVS;
typedef struct GFXIS {
  GFXU32 ID, SDS;
  GFXS32 NU16, ByteDataSize;
  void *Data;
  GFXS32 ByteOffset, ByteLen;
} GFXIS;

typedef struct GFXBVI {
  GFXU32 ID, VN, VC;
  GFXU64 Flags;
  GFXU8 VType[16];
  GFXU64 VNormalised;
  GFXU32 Mapped;
  GFXVS V[16];
  GFXIS I;
} GFXBVI;

typedef struct GFXTexH {
  GFXU32 ID, Flags;
  GFXU32 FBFrameBuffer, FBDepthBuffer;
  GFXU32 PBID;
  GFXS32 PBOX, PBOY, PBW, PBH;
  GFXU32 PBT;
} GFXTEXH;

extern GFXU32 GFXCurrentShader;
extern GFXTEXH GFXDefaultTex;

#define GFX_ShaderCodeToString(PreProcessor, ...) )PreProcessor "\n" #__VA_ARGS__

void GFXOpen(GFXU32 Width, GFXU32 Height, GFX_MALLOC M, GFX_FREE F,
             GFX_FILELOAD L, GFX_FILESIZE S);
void GFXClose(void);
void GFXShaderCreate(GFXU32 s, const GFXC8 *VSource, const GFXC8 *FSource,
                     GFXU64 Flags);
void GFXShaderDestroy(GFXU32 s);
GFXF32 GFXLineWidthRange(GFXF32 *Range);
void GFXViewPort(GFXS32 X, GFXS32 Y, GFXS32 Width, GFXS32 Height);
void GFXClip(GFXS32 X, GFXS32 Y, GFXS32 Width, GFXS32 Height);
// GFXF32 GFXAspectRatio(GFXU32 *W, GFXU32 *H, GFXU32 ViewPort0Screen1);
void GFXClear(GFXU32 RGBA, GFXF32 Depth);
void GFXShader(GFXU32 Index);
void GFXShaderM4(GFXU32 Index, const GFXF32 *M4, GFXU32 NumberOf);
void GFXShaderV4(GFXU32 Index, const GFXF32 *V4, GFXU32 NumberOf);
void GFXBufferVertIndex(GFXBVI *BufferVertIndex);
void *GFXBufferVertIndexMapV(GFXBVI *BufferVertIndex, GFXU32 VArrayIndex,
                             GFXU32 Offset, GFXU32 Length, GFXU64 Flags);
void GFXBufferVertIndexUnMapV(GFXBVI *BufferVertIndex, GFXU32 VArrayIndex);
void *GFXBufferVertIndexMapI(GFXBVI *BufferVertIndex, GFXU32 Offset,
                             GFXU32 Length, GFXU64 Flags);
void GFXBufferVertIndexUnMapI(GFXBVI *BufferVertIndex);
void GFXBufferVertIndexDestroy(GFXBVI *BufferVertIndex);
void GFXRender(GFXU32 PrimType, const GFXBVI *BufferVertIndex,
               GFXS32 Instances);
void GFXRenderBegin(void);
void GFXRenderEnd(void);
void GFXLineWidth(GFXF32 Width);
void GFXCull(GFXU32 Mode);
void GFXBlend(GFXU32 BlendSrcRGB, GFXU32 BlendDstRGB, GFXU32 BlendSrcA,
              GFXU32 BlendDstA, GFXU32 ConstantRGBA);
void GFXZOptions(GFXU64 ZFlags);
void GFXTexDestroy(GFXTEXH *TexHandle);
void GFXTex(GFXU32 Stage, GFXTEXH TexHandle, GFXU64 Flags);
GFXTEXH GFXTexCreate(GFXU32 Type, GFXU32 Width, GFXU32 Height, void *Data,
                     GFXU32 DataPitch, GFXU64 Flags);
void GFXTexUpdate(const GFXTEXH Texture, GFXU32 Type, GFXU32 OX, GFXU32 OY,
                  GFXU32 Width, GFXU32 Height, void *Data, GFXU32 DataPitch,
                  GFXU64 Flags);
void *GFXTexMap(GFXTEXH *Texture, GFXU32 Type, GFXU32 OffsetX, GFXU32 OffsetY,
                GFXU32 Width, GFXU32 Height, GFXU64 Flags);
void GFXTexUnMap(GFXTEXH *Texture);
GFXTEXH GFXTGATexCreate(const GFXC8 *TGALoadFileNameOrMemory, GFXU64 Flags,
                        void *Arg, GFXU32 *Width, GFXU32 *h);
void GFXFrameBufferCreate(GFXU32 FBType, GFXTEXH *FBTex, GFXU32 Width,
                          GFXU32 Height, GFXU64 Flags);
void GFXFrameBufferDestroy(GFXTEXH *FBTex);
void GFXFrameBufferTarget(GFXTEXH *FBTex);
void GFXFrameBufferTargetScreen(void);
void GFXRGBAMask(GFXU32 RGBA);
#ifdef __cplusplus
}
#endif
#endif
