#!/bin/sh
rm ./Src/*.o;rm ./X/Xctbl;time make -j9 CC=tcc;./X/Xctbl
