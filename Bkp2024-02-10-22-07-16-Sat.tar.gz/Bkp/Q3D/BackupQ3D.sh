#!/bin/sh
D=$(date +"%Y-%m-%d-%T-%a")
rsync -rbvu --backup-dir=Q3DBkp$D ~/Q3D ~/Bkp
tar -czvf ../Bkp$D.tar.gz ../Bkp/
