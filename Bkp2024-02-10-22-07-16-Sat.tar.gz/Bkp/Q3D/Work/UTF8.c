#include "stdio.h"

int main() {

  char w[8 * 1024];
  for (int i = 0xc280; i < 0xdfbf; i++) {
    unsigned char *m = (unsigned char *)&w[0];
    //*m++ = (i>>16)&0xff;
    *m++ = (i >> 8) & 0xff;
    *m++ = (i & 0xff);
    *m++ = 0;
    printf("%s", w);
  }
  char s[] = "\0\0\0\0\0\0\0\0";
  printf("\n%s %x %x %x %x ... %x %x %x %x\n", s, s[0] & 0x1f, s[1] & 0x7f,
         s[2] & 0x7f, s[3], s[0], s[1], s[2], s[3]);
  return 0;
}
