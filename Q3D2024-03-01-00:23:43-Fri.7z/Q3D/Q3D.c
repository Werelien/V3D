/*
Copyright (c) 2024 G. Symons

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/

#include "GFX.h"
#include "SFX.h"
#include "SYS.h"
#include "math_3d.h"
#include <string.h>

typedef struct Q3TS {
  SysU64 ID;
  SysF64 x, y, z, dx, dy, dz, p;
} Q3TS;
Q3TS Q3T = {0, 0, 0, 0, 0, 0, 0, 0};
typedef struct Q3MS {
  SysU64 ID;
  SysF64 x, y, dx, dy, wx,wy;
  SysU64 b;
} Q3MS;
Q3MS Q3M = {0, 0, 0, 0, 0, 0, 0, 0};

SysF64 FPS(SysS32 PeriodSecs) {
  static SysF64 FPS = 0;
  static SysU64 FrameCount = 0, FPSFrameCount = 0, FPSS = 0;
  if (PeriodSecs <= 0)
    return FPS;
  SysF64 SysT = SysSec() - FPSS;
  if (SysT >= PeriodSecs) {
    FPS = (FrameCount - FPSFrameCount) / SysT;
    FPSFrameCount = FrameCount;
    FPSS = SysSec();
    SysODS("FPS:%f\n", FPS);
  }
  FrameCount++;
  return FPS;
}

void ShaderLoad(SysU32 Shader, SysC8 *VF, SysC8 *FF) {
  GFXShaderCreate(Shader, VF, FF, GFXFLAG_LOAD);
}

enum { Q3DIMGBASE = 100, HUDIMGBASE = 101, MAX_IMAGES = 256 };

GFXTEXH Image[MAX_IMAGES];

SysF64 FHash64(SysU64 h, SysF64 Low, SysF64 High) {
  SysF64 l = ((SysF64)(h & 0x7fffffffffffffff)) / (SysF64)0x7fffffffffffffff;
  return Low + (l * (High - Low));
}

static SysU64 RNGSeed[2] = {0, 0}, RNGRounds = 8, RNGIndex = 0;

SysF64 FRNG64(SysF64 Low, SysF64 High) {

  RNGIndex++;
  return FHash64(SysPRNG(RNGSeed[0], RNGSeed[1], RNGIndex, RNGRounds), Low,
                 High);
}

SysF32 *ScaleMatrix(SysF32 *M, SysF32 Scale) {
  int o = 0;
  for (int j = 0; j < 4; j++)
    for (int i = 0; i < 4; i++)
      M[o++] = ((i == j) * Scale);
  M[15] = 1;
  return M;
}

SysS32 PowOf2(SysS32 v) {
  SysS32 n = 0;
  while ((1 << n) < v)
    n++;
  return n;
}

mat4_t ProjM;
SysC8 *RXMI_GRID[4] = {
  /*  "7---9---E---1---3---5---7",
    "| 8 | T | 0 | 2 | 4 | 6 |",
    "0---2---4---6---8---T---0",
    "| 1 | 3 | 5 | 7 | 9 | E |",*/
  
    "g---a---b---\xc2---\xc2---f---g",
    "| X | X | C | D | E | X |",
    "c---d---e---\xc2---\xc2---\xc2---c",
    "| X | X | F | G | A | B |",
};

void RenderHud(GFXBVI *VB, int NumberOfQ, int s, SysF32 t, SysU32 RGBA,
               SysU32 UV, SysF32 XScl, SysF32 YScl, SysU32 CFG) {

  typedef struct Q3DMV {
    SysS8 X0, Y0, X1, Y1;
    SysS8 U0, V0, U1, V1;
    SysU32 RGBA;
    SysU8 C[4];
  } Q3DMV;

  enum {
    RXMI_LINES = 15,

    UI_FPS = 0,
    UI_QUADS,
    UI_MOUSE,
    UI_TOUCH,
    UI_RXMI,
    NO_OF_UI_LINES = UI_RXMI + RXMI_LINES,
  };
  enum {
    MAX_UI_LINES = 256,
    MAX_UI_LINE_QUADS = 256,
    MAX_UI_QUADS = NO_OF_UI_LINES * MAX_UI_LINE_QUADS
  };
  typedef struct hs {
    SysF32 x, y;
    SysU32 TexOffSclIndex;
    char *s;
  } hs;

  SysAssert(NO_OF_UI_LINES <= MAX_UI_LINES);
  static char UI_S[256][256];
  sprintf(UI_S[UI_FPS], "FPS:%.1F", FPS(1));
  sprintf(UI_S[UI_QUADS], "Q:%d", NumberOfQ);
  /*
  sprintf(UI_S[2],"M:(%.0f,%.0f W:%.0f,%.0f D:%.0f,%.0f) %llu",
  SysMouse->X,SysMouse->Y,SysMouse->WindowX,SysMouse->WindowY,SysMouse->DeltaX,SysMouse->DeltaY,SysMouse->Buttons);
  */
  sprintf(UI_S[UI_MOUSE], "M:%.0f,%.0f %.0f,%.0f %.0f,%0.f,0X%llx", Q3M.x, Q3M.y,
          Q3M.dx, Q3M.dy, Q3M.wx,Q3M.wy, Q3M.b);
  sprintf(UI_S[UI_TOUCH], "T:I:%llu L:%.3f,%.3f,%.3f D:%.3f,%.3f,%.3f P:%.3f",
          Q3T.ID, Q3T.x, Q3T.y, Q3T.z, Q3T.dx, Q3T.dy, Q3T.dz, Q3T.p);

  SysF32 sw = SysAspectRatio(0, 0);
  SysF32 hv[NO_OF_UI_LINES] = {FPS(1), NumberOfQ};
  hs h[NO_OF_UI_LINES] = {
      {-sw, -1.0f,0,UI_S[UI_FPS]},
      {-0.6f * sw, -1.0f,0,UI_S[UI_QUADS]},
      {0, -1.0f,0,UI_S[UI_MOUSE]},
      {-sw, 0.9f,0,UI_S[UI_TOUCH]},
  };
  for (int i = 0; i < RXMI_LINES; i++) {
    h[UI_RXMI + i] = (hs){-sw, 0.8f - i * 0.1f,1,RXMI_GRID[i & 3]};
  }

  if (!VB->Flags) {
    SysODS("\nCreating Hud...\n");

    Image[HUDIMGBASE] = GFXTexCreate(GFX_4XF32, NO_OF_UI_LINES * 4, 1, 0, 0, 0);

    SysAssert(NO_OF_UI_LINES < MAX_UI_LINES);

    VB->VNormalised = 0;

    VB->VType[0] = GFXV_4XS8;
    VB->VType[1] = GFXV_4XS8;
    VB->VType[2] = GFXV_4XU8;
    VB->VType[3] = GFXV_4XU8;

    VB->VN = 1;
    VB->VC = 4;
    VB->Flags = GFX_BVI_CREATE;
    GFXVS v0 = {0, GFX_BVI_DYNAMIC,
                4, sizeof(Q3DMV),
                1, sizeof(Q3DMV) * MAX_UI_QUADS,
                0, 0,
                0};
    VB->V[0] = v0;
    GFXIS ib = {0, GFX_BVI_NONE, 0, 0, 0, 0, 0};
    VB->I = ib;
    GFXBufferVertIndex(VB);
    SysODS("Hud Created\n\n");
  }

  Q3DMV *QHud = SysNew(Q3DMV, NO_OF_UI_LINES * MAX_UI_LINE_QUADS);
  SysF32 *m3d = SysNew(SysF32, NO_OF_UI_LINES * 16);

  RNGSeed[0] = s;
  RNGSeed[1] = s ^ -1;
  RNGIndex = 0;
  int nq = 0;
  for (int i = 0; i < NO_OF_UI_LINES; i++) {
    SysF32 x = h[i].x, y = h[i].y;
    mat4_t m;

    m = m4_translation(vec3(x, y, -1));
    SysF32 Scl = 0.045f;
    mat4_t sm = m4_scaling(vec3(Scl, Scl, 1));
    m = (m4_mul(m, sm));
    m = m4_transpose(m);
    memcpy(&(m3d[i * 16]), &m.m00, 3 * 4 * sizeof(SysF32));

    SysODS("%s\n", h[i].s);
    SysS32 hn = strlen(h[i].s);

    for (int j = 0; j < hn; j++) {
      SysS32 fgl = h[i].s[j] - 32, u = fgl & 31, v = (fgl >> 5);v&=7;
      if (!fgl)
        continue;
      QHud[nq].X0 = j;
      QHud[nq].Y0 = 1;
      QHud[nq].X1 = j + 1;
      QHud[nq].Y1 = 0;
      QHud[nq].U0 = u;
      QHud[nq].V0 = v;
      QHud[nq].U1 = 1;
      QHud[nq].V1 = 1;
      QHud[nq].RGBA = RGBA;
      QHud[nq].C[0] = (i & 0xff);
      QHud[nq].C[1] = (i >> 8);
      QHud[nq].C[2] = 0;
      QHud[nq].C[3] = h[i].TexOffSclIndex;
      nq++;
    }
  }
  VB->V[0].Data = &QHud[0];
  VB->V[0].ByteOffset = 0;
  VB->V[0].ByteLen = nq * sizeof(Q3DMV);
  VB->Flags = GFX_BVI_UPDATE;
  GFXBufferVertIndex(VB);

  GFXTexUpdate(Image[HUDIMGBASE], GFX_4XF32, 0, 0, NO_OF_UI_LINES * 4, 1,
               &(m3d[0]), 0, 0);

  SysDelete(m3d);
  SysDelete(QHud);

  SysF64 rgba[4] = {FRNG64(0, 1), FRNG64(0, 1), FRNG64(0, 1), FRNG64(0, 1)};
  GFXTex(0, Image[0], 0);
  GFXTex(GFXVTEXSTAGE | 0, Image[HUDIMGBASE], 0);
  GFXRender(GFX_TRIANGLE_STRIP, VB, nq);
}

enum { MAX_Q3D = 64 * 1024 };
SysU32 Paused = 0;
void RenderQuads(GFXBVI *VB, int n, int s, SysF32 t, SysU32 RGBA, SysU32 UV,
                 SysF32 XScl, SysF32 YScl, SysU32 CFG) {
  typedef struct Q3DMV {
    SysS8 X0, Y0, X1, Y1;
    SysS8 U0, V0, U1, V1;
    SysU32 RGBA;
    SysU8 C[4];
  } Q3DMV;

  if (n < 1)
    return;

  if (n > MAX_Q3D)
    n = MAX_Q3D;

  if (!VB->Flags) {

    SysODS("\nCreating Quads\n");

    Image[Q3DIMGBASE] = GFXTexCreate(GFX_4XF32, 256 * 4, 256, 0, 0, 0);

    VB->VNormalised = 0;
    VB->VType[0] = GFXV_4XS8;
    VB->VType[1] = GFXV_4XS8;
    VB->VType[2] = GFXV_4XU8;
    VB->VType[3] = GFXV_4XU8;

    VB->VN = 1;
    VB->VC = 4;
    VB->Flags = GFX_BVI_CREATE;
    GFXVS v0 = {0, GFX_BVI_DYNAMIC,         4, sizeof(Q3DMV),
                1, sizeof(Q3DMV) * MAX_Q3D, 0, 0,
                0};
    VB->V[0] = v0;
    GFXIS ib = {0, GFX_BVI_NONE, 0, 0, 0, 0, 0};
    VB->I = ib;
    VB->I = ib;
    GFXBufferVertIndex(VB);
    SysODS("Quads Created\n\n");
  }
  static int lastn = -1;
  if ((!Paused) || (lastn != n)) {
    RNGSeed[0] = s;
    RNGSeed[1] = 0;
    RNGIndex = 0;

    Q3DMV *Quad = SysNew(Q3DMV, n);
    SysF32 *m3d = SysNew(SysF32, n * 16);

    mat4_t mrt[256];
    for (int i = 0; i < 256; i++) {
      SysF32 xsr = 1 + cosf(t * 2 + FRNG64(0, 1)) * 0.25f;
      SysF32 ysr = 1 + sinf(t * 2 + FRNG64(0, 1)) * 0.25f;
      SysF32 a = FRNG64(-M_PI, M_PI) + t * 2 * M_PI * 0.5f;
      SysF32 sx = xsr * XScl, sy = ysr * YScl;
      mat4_t tm = m4_translation(vec3(0, 0, 0));
      mat4_t rm =
          m4_rotation(a, vec3(FRNG64(-1, 1), FRNG64(-1, 1), FRNG64(-1, 1)));
      mat4_t sm = m4_scaling(vec3(sx, sy, 1));
      mrt[i] = m4_transpose(m4_mul(m4_mul(tm, rm), sm));
    }

    lastn = n;
    for (int i = 0; i < n; i++) {
      int ReverseZOrder = 0;
      int zorder = (ReverseZOrder ? (n - 1 - i) : i);
      mat4_t m = mrt[i & 0xff];
      m.m03 = FRNG64(-8, 8);
      m.m13 = FRNG64(-8, 8);
      m.m23 = ((-64.0f * zorder) / n);

      memcpy(&(m3d[i << 4]), &m.m00, 3 * 4 * sizeof(SysF32));

      SysU32 fgl = FRNG64(0, 255);
      SysS32 u = fgl & 31, v = (fgl >> 5);v&=7;

      Quad[i].X0 = -1;
      Quad[i].Y0 = -1;
      Quad[i].X1 = 1;
      Quad[i].Y1 = 1;
      Quad[i].U0 = u;
      Quad[i].V0 = v;
      Quad[i].U1 = 1;
      Quad[i].V1 = 1;
      Quad[i].RGBA = RGBA;
      Quad[i].C[0] = (i & 0xff);
      Quad[i].C[1] = (i >> 8);
      Quad[i].C[2] =0;
      Quad[i].C[3] =0;
    }

    VB->V[0].Data = &Quad[0];
    VB->V[0].ByteOffset = 0;
    VB->V[0].ByteLen = n * sizeof(Q3DMV);
    VB->Flags = GFX_BVI_UPDATE;
    GFXBufferVertIndex(VB);
    GFXTexUpdate(Image[Q3DIMGBASE], GFX_4XF32, 0, 0, 256 * 4,
                 (((n - 1) >> 8) + 1), &(m3d[0]), 0, 0);

    SysDelete(m3d);
    SysDelete(Quad);
  }
  SysF64 rgba[4] = {FRNG64(0, 1), FRNG64(0, 1), FRNG64(0, 1), FRNG64(0, 1)};
  GFXTex(0, Image[0], 0);
  GFXTex(GFXVTEXSTAGE | 0, Image[Q3DIMGBASE], 0);
  GFXRender(GFX_TRIANGLE_STRIP, VB, n);
}

SysF32 GridMod(SysF32 a, SysF32 b) {
  a = fmodf(a, 2 * b);
  if (a > b) {
    a = -b + a - ((SysS32)(a / b)) * b;
  } else if (a < -b) {
    a = b + a - ((SysS32)(a / b)) * b;
  }
  return a;
}

SysU8 KActive[SYS_KEYS_MAX] = {[0 ... SYS_KEYS_MAX - 1] = 0};
SysU64 KPresses[SYS_KEYS_MAX] = {[0 ... SYS_KEYS_MAX - 1] = 0};
SysS32 KeyActive(SysU64 k) {
  SysAssert(k < SYS_KEYS_MAX);
  return KActive[k];
}
SysS32 KeyPressed(SysU64 k) {
  SysAssert(k < SYS_KEYS_MAX);
  if (KPresses[k])
    return KPresses[k]--;
  return 0;
}
SysS32 SysUserInput(const SYSINPUT si) {
  switch (si.ID[0]) {
  case SYSINPUT_TOUCHON:
    Q3T = (Q3TS){si.ID[1], si.WX, si.WY, 0, si.DX, si.DY, 0, si.P};
    break;
  case SYSINPUT_TOUCHOFF:
    Q3T = (Q3TS){si.ID[1], si.WX, si.WY, 0, si.DX, si.DY, 0, si.P};
    break;
  case SYSINPUT_TOUCHMOVE:
    Q3T = (Q3TS){si.ID[1], si.WX, si.WY, 0, si.DX, si.DY, 0, si.P};
    break;
  case SYSINPUT_KEYON:
    KActive[si.B] = 1;
    KPresses[si.B]++;
    break;
  case SYSINPUT_KEYOFF:
    KActive[si.B] = 0;
    break;
  case SYSINPUT_MOUSEON:
    Q3M = (Q3MS){si.ID[1], si.WX, si.WY, si.DX, si.DY, Q3M.wx,Q3M.wy, Q3M.b|(1<<(si.B-1))};
    break;
  case SYSINPUT_MOUSEOFF:
    Q3M = (Q3MS){si.ID[1], si.WX, si.WY, si.DX, si.DY, Q3M.wx,Q3M.wy, Q3M.b&~(1<<(si.B-1))};
    break;
  case SYSINPUT_MOUSEMOVE:
    Q3M = (Q3MS){si.ID[1], si.WX, si.WY, si.DX, si.DY, Q3M.wx,Q3M.wy, Q3M.b};
    break;
  case SYSINPUT_MOUSEWHEEL:
    Q3M = (Q3MS){si.ID[1], Q3M.x, Q3M.y, Q3M.dx, Q3M.dy, si.DX, si.DY, Q3M.b};
    break;
  }
  return 0;
}
SysU32 ScreenWidth, ScreenHeight;

void UpdateScreenWH(void) {
  SysU32 w, h;
  SysF32 a = SysAspectRatio(&w, &h);
  ProjM = m4_perspective(360.0f / 4, a, 1, 100.f);
  GFXViewPort(0, 0, w, h);
  GFXClip(0, 0, 0, 0);
  ScreenWidth = w;
  ScreenHeight = h;
}

enum {
  Q3D_SHADER = 0,
  Q3D_SHADER_2,
  FNT_SHADER,
  STANDARD_SHADER,
  RENDER_TARGET_SHADER
};

void LoadShaders(void) {
  ShaderLoad(Q3D_SHADER, "./Assets/Shaders/Q3DV.vert",
             "./Assets/Shaders/Q3DF.frag");
  ShaderLoad(Q3D_SHADER_2, "./Assets/Shaders/Q3DV2.vert",
             "./Assets/Shaders/Q3DF.frag");
  ShaderLoad(FNT_SHADER, "./Assets/Shaders/Q3DFntV.vert",
             "./Assets/Shaders/Q3DFNTF.frag");
  ShaderLoad(STANDARD_SHADER, "./Assets/Shaders/StandardV.vert",
             "./Assets/Shaders/StandardF.frag");
}

GFXTEXH TexLoad(SysC8 *TGAF, SysU32 Flags) {
  return GFXTGATexCreate(TGAF, Flags | GFXFLAG_LOAD);
}

void LoadAssets() {
  static int Loaded = 0;
  if (Loaded)
    return;
  else {
    Image[0] = TexLoad("./Assets/Images/RXMI-54.tga",
                       (/*GFXTGA_FLAGFLIPV |*/ GFX_4XU4 |
                        /*GFXTGA_TRANS0 | */ GFXTEX_FLAG_LINEAR |
                        GFXTEX_FLAG_MIPMAP | GFXTGA_ALPHAGEN));
    SysAssert(Image[0].ID);
    Loaded = 1;
  }
}

#define RENDER_TO_TEXTURE
GFXTEXH FBRenderTex = {0};
const SysU32 FBRenderWidth = 1024, FBRenderHeight = 768;
#ifdef RENDER_TO_TEXTURE
void CreateRenderTarget(void) {
  GFXFrameBufferCreate(GFX_4XU8, &FBRenderTex, FBRenderWidth, FBRenderHeight,
                       GFXTEX_FLAG_DEPTH | GFXTEX_FLAG_MIPMAP);
  ShaderLoad(RENDER_TARGET_SHADER, "./Assets/Shaders/RTV.vert",
             "./Assets/Shaders/RTF.frag");
}

void TextureRenderTarget(void) {
  GFXFrameBufferTarget(&FBRenderTex);
  GFXViewPort(0, 0, FBRenderWidth, FBRenderHeight);
  GFXClip(0, 0, FBRenderWidth, FBRenderHeight);
}

void ScreenRenderTarget(void) {
  GFXFrameBufferTargetScreen();
  GFXViewPort(0, 0, ScreenWidth, ScreenHeight);
  GFXClip(0, 0, ScreenWidth, ScreenHeight);
}

void RenderToScreen(SysU64 RGBA) {
  static GFXBVI VB = {0};
  if (!VB.Flags) {
    for (int i = 0; i < 16; i++) {
      VB.VNormalised = 0;
      VB.VType[i] = GFXV_4XS8;
    }
    typedef struct I6 {
      SysU16 v[4];
    } I6;

    SysS8 vv[32] = {-1, -1, 0, 1, 0, 0, 0, 0, 1, -1, 0, 1, 1, 0, 0, 0,
                    -1, 1,  0, 1, 0, 1, 0, 0, 1, 1,  0, 1, 1, 1, 0, 0};
    I6 ib = {0, 1, 2, 3};
    VB.VN = 1;
    VB.VC = 4;
    VB.Flags = GFX_BVI_CREATE;
    GFXVS v0 = {0, GFX_BVI_STATIC, 2,      2 * 4 * sizeof(SysS8),
                0, sizeof(vv),     &vv[0], 0,
                0};
    VB.V[0] = v0;
    GFXIS i0 = {0, GFX_BVI_STATIC, 4, sizeof(ib), &ib, 0, 0};
    VB.I = i0;
    GFXBufferVertIndex(&VB);
  }
  GFXBlend(GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, 0);
  GFXRGBAMask(0xffffffff);
  GFXCull(GFXCULL_NONE);
  GFXZOptions(GFXFLAG_Z_WRITE_OFF | GFXFLAG_Z_TEST_OFF);
  GFXClear(RGBA, 1);

  GFXShader(RENDER_TARGET_SHADER);

  const GFXF32 RGBAF[4] = {1.0f, 1.0f, 1.0f, 1.0f};
  mat4_t mt = m4_identity();
  GFXShaderM4(0, &mt.m00, 1);
  GFXShaderV4(0, &RGBAF[0], 1);
  GFXTex(0, FBRenderTex, GFXTEX_FLAG_MIPMAP);
  // GFXTex(0, Image[0]);
  GFXRender(GFX_TRIANGLE_STRIP, &VB, 1);
}

#else
void CreateRenderTarget(void) {}
void RenderToScreen(SysU64 RGBA) {}
void ScreenRenderTarget(void) {}
void TextureRenderTarget(void) {}
#endif

GFXS32 FileLoad(const GFXC8 *FileName, void *Buffer, GFXU32 BufferSize,
                const GFXC8 *SrcFileName, GFXU32 SrcLineNumber) {
  return SysLoad(0, FileName, 0, BufferSize, Buffer);
}

GFXS32 FileSize(const GFXC8 *FileName, const GFXC8 *SrcFileName,
                GFXU32 SrcLineNumber) {
  return SysLoad(0, FileName, 0, 0, 0);
}

SysS32 SysUserFrame(SysS32 Flags) {
  static GFXBVI BVI[3] = {{0}, {0}, {0}};
  static SysU32 Mode = 0;

  if (Mode) {
    if (Flags & SYSFRAME_GL_CREATE) {
      SysU32 w, h;
      SysAspectRatio(&w, &h);
      GFXOpen(w, h, SysDbgAlloc, SysDbgFree, FileLoad, FileSize);
    }
  }
  if (Flags & SYSFRAME_RESUME) {
  } else if (Flags & SYSFRAME_PAUSE) {
    return 0;
  }

  switch (Mode) {
  case 0: {

    BVI[0].Flags = BVI[1].Flags = BVI[2].Flags = 0;
    SysAspectRatio(&ScreenWidth, &ScreenHeight);
    GFXOpen(ScreenWidth, ScreenHeight, SysDbgAlloc, SysDbgFree, FileLoad,
            FileSize);
    // SysODS("AspectRatio: Sys:%f GFX:%f\n", SysAspectRatio(0, 0),
    // GFXAspectRatio(0, 0, 0));
    SysODS("AspectRatio: Sys:%f\n", SysAspectRatio(0, 0));

    // TxtInit("./Assets/Fonts/Mono.TTF", 256, 256, 16);
    LoadShaders();

    GFXCull(GFXCULL_NONE);
    GFXRenderBegin();
    GFXClear(0, 1);

    SysState(SYSSTATE_AUDIOON, 0);
    SysState(SYSSTATE_UDPON, 0);

    LoadAssets();
    CreateRenderTarget();

    Mode++;
    break;
  }
  case 1: {
    UpdateScreenWH();
    static SysU64 fc = 0, lastfc = 0;
    static SysF64 lastft = 0;
    static int NC = 256;
    const int NCA = 64;
    GFXRenderBegin();
    TextureRenderTarget();

    int ShiftOn = KeyActive(SYS_LSHIFT) | KeyActive(SYS_RSHIFT);
    int CtrlOn = KeyActive(SYS_LCTRL) | KeyActive(SYS_RCTRL);

    if (KeyActive('0')) {
      if (ShiftOn)
        SysMusicOff(5);
      else
        SysMusicOn("./Assets/Audio/test.ogg", 2, -1);
    }

    static SysF32 BlendFactor = 0.0f;
    if (KeyActive('1')) {
      if (ShiftOn)
        BlendFactor += 0.01f;
      else
        BlendFactor -= 0.01f;
      if (BlendFactor < 0)
        BlendFactor = 0;
      else if (BlendFactor > 1)
        BlendFactor = 1;
      SysODS("Blend Factor:%f FPS:%f\n", NC, BlendFactor, FPS(0));
    }

    if (KeyActive('2')) {
      if (ShiftOn)
        NC -= NCA;
      else
        NC += NCA;
      if (NC < 0)
        NC = 0;
      if (NC > MAX_Q3D)
        NC = MAX_Q3D;
      SysODS("Objects:%d Blend Factor:%f Line Width:%f FPS:%f\n", NC, FPS(0));
    }

    if (KeyPressed('3')) {
      static SysU32 fxcount = 0;
      static SysS32 FXHandleID[64] = {[0 ... 63] = -1};
      FXHandleID[fxcount & 63] = -1;
      FXHandleID[fxcount & 63] = FXPlay(FXHandleID[fxcount & 63], FXStart,
                                        FXThrust + (fxcount & 7), -1);
      fxcount++;
    }

    if (KeyActive('4')) {
      static SysF32 lw = 3;
      if (ShiftOn)
        lw += 0.1f;
      else
        lw -= 0.1f;
      SysF32 r[2];
      GFXLineWidthRange(r);
      if (lw < r[0])
        lw = r[0];
      else if (lw > r[1])
        lw = r[1];
      GFXLineWidth(lw);
      SysODS("Objects:%d Blend Factor:%f Line Width:%f FPS:%f\n", NC,
             BlendFactor, lw, FPS(0));
    }
    GFXBlend(GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, 0);
    GFXRGBAMask(0xffffffff);
    GFXCull(GFXCULL_NONE);
    GFXZOptions(GFXFLAG_Z_WRITE_ON | GFXFLAG_Z_TEST_ALWAYS);
    GFXClear(fc, 1);
    GFXZOptions(GFXFLAG_Z_WRITE_ON | GFXFLAG_Z_TEST_LE);

    if (KeyPressed(' ')) {
      Paused ^= 1;
    }

    SysF32 t = SysSec();
    SysF32 FragAlpha[4] = {0, 0, 0, 0};
    SysF32 VTexXY[2][4] = {{0, 0, 32.0f, 8.0f},{0, 0,32.0f, 8.0f}};

    mat4_t mt;

    GFXShader(Q3D_SHADER);
    mt = m4_transpose(ProjM);
    GFXShaderM4(0, &mt.m00, 1);
    FragAlpha[3] = BlendFactor;
    GFXShaderV4(0 | GFXFRAGV4, FragAlpha, 1);
    GFXShaderV4(0, VTexXY[0], 1);
    GFXShaderV4(0, VTexXY[1], 1);
    GFXBlend(GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, GFXBLEND_OFF, 0);
    GFXBlend(GFXBLEND_SRC_ALPHA, GFXBLEND_ONE_MINUS_SRC_ALPHA,
             GFXBLEND_SRC_ALPHA, GFXBLEND_ONE_MINUS_SRC_ALPHA, 0xffffffff);
    // GFXBlend(GFXBLEND_SRC_COLOR, GFXBLEND_ONE_MINUS_SRC_COLOR,
    // GFXBLEND_SRC_COLOR, GFXBLEND_ONE_MINUS_SRC_COLOR, 0xffffffff);
    RenderQuads(&BVI[0], NC, 1, t, 0x7f7f7f7f, 0x0000ffff, 1, 1, 0);

    GFXZOptions(GFXFLAG_Z_WRITE_OFF | GFXFLAG_Z_TEST_OFF);
    GFXShader(Q3D_SHADER);
    mt = m4_transpose(ProjM);
    GFXShaderM4(0, &mt.m00, 1);
    FragAlpha[3] = BlendFactor;
    GFXShaderV4(0, VTexXY[0], 1);
    GFXShaderV4(0, VTexXY[1], 1);
    GFXShaderV4(0 | GFXFRAGV4, FragAlpha, 1);
    GFXBlend(GFXBLEND_SRC_ALPHA, GFXBLEND_ONE_MINUS_SRC_ALPHA,
             GFXBLEND_SRC_ALPHA, GFXBLEND_ONE_MINUS_SRC_ALPHA, 0xffffffff);
    RenderHud(&BVI[2], NC, 3, t, 0x7f7f7f7f, 0x0000ffff, 1, 1, 0);
    ScreenRenderTarget();
    RenderToScreen(fc);
    fc++;
    break;
  }
  }

  FPS(5);

  GFXRenderEnd();

  if (0) {
    GFXClose();
  }

  return 0;
}
