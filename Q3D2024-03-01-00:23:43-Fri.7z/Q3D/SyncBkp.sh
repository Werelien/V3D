#!/bin/sh
rm Q3D
rm Q3DWeb/*.*
D=$(date +"%Y-%m-%d-%T-%a")
rsync -rbvu --backup-dir=Q3DBkp$D ~/Q3D ~/Bkp
tar -cJvf ../Bkp$D.tar.xz ../Bkp
