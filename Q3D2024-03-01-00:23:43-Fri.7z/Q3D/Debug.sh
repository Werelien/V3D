#!/bin/sh
rm Q3D
tcc -DSDL_DISABLE_IMMINTRIN_H -DSYS_DEBUG_ODS -DGFX_DEBUG_ODS  -g -oQ3D GFX.c Implementation.c SFX.c SysSDL.c Q3D.c -lGL -lSDL2 -lSDL2_mixer

